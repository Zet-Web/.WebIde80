#!/bin/bash
export mode="update"

./updateOrDeploy.sh

