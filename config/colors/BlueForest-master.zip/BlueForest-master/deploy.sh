#!/bin/bash
export mode="deploy"

./updateOrDeploy.sh
