<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN" "http://java.sun.com/products/javahelp/helpset_2_0.dtd">
<helpset version="1.0">
  <title>Compare Directory Help</title>
  <maps>
    <homeID>managingFiles.dirdiff</homeID>
    <mapref location="MapFile.xml"/>
  </maps>
  <view mergetype="javax.help.UniteAppendMerge">
    <name>TOC</name>
    <label>Table Of Contents</label>
    <type>javax.help.TOCView</type>
    <data>TOC.xml</data>
  </view>
  <view mergetype="javax.help.AppendMerge">
    <name>Index</name>
    <label>Index</label>
    <type>javax.help.IndexView</type>
    <data>index.xml</data>
  </view>
</helpset>