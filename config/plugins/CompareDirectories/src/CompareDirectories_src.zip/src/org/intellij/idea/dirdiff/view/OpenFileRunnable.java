/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.JComponent;

import com.intellij.openapi.fileEditor.FileEditor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.ClassFileTreeNode;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.JavaFieldTreeNode;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.intellij.idea.dirdiff.util.Commands;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 *
 */
class OpenFileRunnable implements Runnable {
    @NonNls static final String ANCESTOR_PROPERTY    = "ancestor";
    @NonNls static final String UPDATE_COMPARED_NODE = "updateComparedNode";

    private final Project                 project;
    private final ReadableFile            file;
    private final ComparedTreeNode        node;
    private final CompareDirectoryManager compareDirectoryManager;
    private final ICompareDirectoryPanel  panel;

    public OpenFileRunnable(@NotNull CompareDirectoryManager compareDirectoryManager,
                            @NotNull ICompareDirectoryPanel  panel,
                            @NotNull Project                 project,
                            @NotNull ReadableFile            file,
                            @NotNull ComparedTreeNode        node) {
        this.compareDirectoryManager = compareDirectoryManager;
        this.panel                   = panel;
        this.project                 = project;
        this.file                    = file;
        this.node                    = node;
    }

    public void run() {
        try {
            final MyClassVisitorContext  classVisitorContext = this.panel.getManager().getClassVisitorContext();
            final VirtualFile            virtualFile;
            final File                   binaryViewFile;

            // If file is a class or a Java class member, create a textual view of it on disk.
            if (this.node instanceof ClassFileTreeNode) {
                final ClassFileTreeNode classNode = (ClassFileTreeNode) this.node;

                if (ensureClassTextExists(classNode, classVisitorContext)) {
                    this.panel.refreshTree(false);
                }
                binaryViewFile  = Files.getComparableJavaClassFile(classNode.getLeftClassDesc().getText());
                virtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(binaryViewFile);

            } else if (this.node instanceof JavaFieldTreeNode) {
                final JavaFieldTreeNode fieldNode        = (JavaFieldTreeNode) this.node;
                final JavaFieldTreeNode updatedFieldNode = ensureClassTextExists(fieldNode, classVisitorContext);

                if (fieldNode != updatedFieldNode) {
                    this.panel.refreshTree(false);
                }

                binaryViewFile  = Files.getComparableJavaClassFile(updatedFieldNode.getLeftMember().getText());
                virtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(binaryViewFile);

            } else if (this.file.getFileType().equals(StdFileTypes.CLASS)) {
                binaryViewFile  = Files.getComparableJavaClassFile(Files.getJavaClassDesc(this.file, true, false, classVisitorContext).getText());
                virtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(binaryViewFile);

            } else {
                virtualFile     = this.file.getVirtualFile();
            }

            // Check the file still exists on disk
            if (virtualFile == null) {
                Commands.showErrorDialog(this.project,
                                         CompareDirectoryBundle.message("error.open-no-more-file", this.file.getPath()),
                                         CompareDirectoryBundle.message("error.title"));
                return;
            }

            // Open the file in the editor
            final FileEditorManager fileEditorManager = FileEditorManager.getInstance(this.project);
            final FileEditor[]      fileEditors       = fileEditorManager.openFile(virtualFile, true);

            // Prepare refresh of the node whose file is edited
            final JComponent focusedComponent = ((fileEditors.length == 0) ? null : fileEditors[0].getPreferredFocusedComponent());

            if (focusedComponent != null) {
                focusedComponent.addPropertyChangeListener(ANCESTOR_PROPERTY, new PropertyChangeListener() {
                        public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
                            // Remove the temporary file type association
                            final CompareDirectoryPlugin plugin = CompareDirectoryPlugin.getInstance(OpenFileRunnable.this.project);

                            if (plugin != null) {
                                plugin.unregisterUnknownExtension(OpenFileRunnable.this.file,
                                                                  OpenFileRunnable.this.file.getExtension());
                            }

                            // Save modified files and update related nodes.
                            final Runnable updateTask = new Runnable() {
                                    public void run() {
                                        OpenFileRunnable.this.compareDirectoryManager.saveFilesAndRefreshStates(OpenFileRunnable.this.node);
                                    }
                                };

                            Commands.runWriteCommand(OpenFileRunnable.this.project, updateTask, UPDATE_COMPARED_NODE,
                                                     CompareDirectoryPlugin.ACTION_GROUP_ID);
                        }
                    });
            }
        } catch (Throwable t) {
            Commands.showErrorDialog(this.project, CompareDirectoryBundle.message("error.open-file", this.file.getPath()),
                                     CompareDirectoryBundle.message("error.title"));
            CompareDirectoryPlugin.getLogger().error(t);
        }
    }

    private static boolean ensureClassTextExists(@NotNull ClassFileTreeNode classNode,
                                                 MyClassVisitorContext      context) {
        // Analyze class and retrieve its textual representation.
        if (classNode.getLeftClassDesc()  != null && classNode.getLeftClassDesc() .getText() != null &&
            classNode.getRightClassDesc() != null && classNode.getRightClassDesc().getText() != null) {
            return false;
        }

        classNode.analyze(context, true, true);
        classNode.getModel().reapplyNodeMerging(classNode);
        return true;
    }

    private static JavaFieldTreeNode ensureClassTextExists(@NotNull JavaFieldTreeNode fieldNode,
                                                           MyClassVisitorContext      context) {
        final ClassFileTreeNode classNode = fieldNode.getSelfOrAncestor(ClassFileTreeNode.class);

        if (classNode != null && ensureClassTextExists(classNode, context)) {
            // Field node under the analyzed class node has changed => replace the input field node accordingly.
            final JavaFieldTreeNode newNode = findRebuiltJavaField(fieldNode, classNode);

            if (newNode != null) {
                return newNode;
            }
        }

        return fieldNode;
    }

    private static JavaFieldTreeNode findRebuiltJavaField(JavaFieldTreeNode oldField,
                                                          ComparedTreeNode  classNode) {
        final Iterable<ComparedTreeNode> children = classNode.getChildren();

        if (children != null) {
            JavaFieldTreeNode fieldChild;

            for (ComparedTreeNode child : children) {
                if (child instanceof JavaFieldTreeNode) {
                    fieldChild = (JavaFieldTreeNode) child;

                    if (oldField.getUserObject().equals(fieldChild.getUserObject())) {
                        return fieldChild;
                    }
                }

                if (child.hasChildren()) {
                    fieldChild = OpenFileRunnable.findRebuiltJavaField(oldField, child);
                    if (fieldChild != null) {
                        return fieldChild;
                    }
                }
            }
        }

        return null;
    }
}
