/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

/**
 */
public class TreeStatistics {
    private int     numIdenticalLeaves;
    private int     numDifferentLeaves;
    private int     numDifferentInBlanksLeaves;
    private int     numNonSignificantlyDifferentLeaves;
    private int     numLeftOnlyLeaves;
    private int     numRightOnlyLeaves;
    private int     numLeftRightLeaves;
    private int     numUncheckedLeaves;
    private int     numDirectories;
    private int     numJavaFieldsMethods;
    private int     numMergedNodes;
    private boolean done;

    public void reset() {
        this.numIdenticalLeaves                 = 0;
        this.numDifferentLeaves                 = 0;
        this.numDifferentInBlanksLeaves         = 0;
        this.numNonSignificantlyDifferentLeaves = 0;
        this.numLeftOnlyLeaves                  = 0;
        this.numRightOnlyLeaves                 = 0;
        this.numLeftRightLeaves                 = 0;
        this.numUncheckedLeaves                 = 0;
        this.numDirectories                     = 0;
        this.numJavaFieldsMethods               = 0;
        this.numMergedNodes                     = 0;
        this.done                               = false;
    }

    public int getNumIdenticalLeaves() {
        return this.numIdenticalLeaves;
    }

    public int getNumDifferentLeaves() {
        return this.numDifferentLeaves;
    }

    public int getNumDifferentInBlanksLeaves() {
        return this.numDifferentInBlanksLeaves;
    }

    public int getNumNonSignificantlyDifferentLeaves() {
        return this.numNonSignificantlyDifferentLeaves;
    }

    public int getNumLeftOnlyLeaves() {
        return this.numLeftOnlyLeaves;
    }

    public int getNumRightOnlyLeaves() {
        return this.numRightOnlyLeaves;
    }

    public int getNumLeftRightLeaves() {
        return this.numLeftRightLeaves;
    }

    public int getNumUncheckedLeaves() {
        return this.numUncheckedLeaves;
    }

    public int getNumDirectories() {
        return this.numDirectories;
    }

    public int getNumJavaFieldsMethods() {
        return this.numJavaFieldsMethods;
    }

    public int getNumMergedNodes() {
        return this.numMergedNodes;
    }

    public boolean isDone() {
        return this.done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public void addNode(ComparedTreeNode node) {
        if (node.hasChildren() && node.getParent() != null && node instanceof FileTreeNode) {
            this.numDirectories++;
        } else if (node instanceof JavaFieldTreeNode) {
            if (!node.hasChildren()) {
                this.numJavaFieldsMethods++;
            }
        } else {
            switch (node.getState()) {
                case LEFT_ONLY:                 this.numLeftOnlyLeaves++;                  break;
                case RIGHT_ONLY:                this.numRightOnlyLeaves++;                 break;
                case DIFFERENT:                 this.numDifferentLeaves++;                 this.numLeftRightLeaves++; break;
                case DIFFERENT_IN_BLANKS:       this.numDifferentInBlanksLeaves++;         this.numLeftRightLeaves++; break;
                case DIFFERENT_NON_SIGNIFICANT: this.numNonSignificantlyDifferentLeaves++; this.numLeftRightLeaves++; break;
                case IDENTICAL:                 this.numIdenticalLeaves++;                 this.numLeftRightLeaves++; break;
                case MOST_PROBABLY_IDENTICAL:
                case PROBABLY_DIFFERENT:
                case PROBABLY_IDENTICAL:        this.numUncheckedLeaves++;                 this.numLeftRightLeaves++; break;
                case PSI_ELEMENT:               break;
                case DIFFERENT_IN_COMMENTS:     break;
            }
        }

        if (node.getParent() != null && node.isMerged()) {
            this.numMergedNodes++;
        }
    }
}
