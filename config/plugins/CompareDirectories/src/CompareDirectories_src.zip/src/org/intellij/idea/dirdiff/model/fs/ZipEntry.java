/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

import java.io.InputStream;
import java.io.IOException;

import com.intellij.openapi.vfs.VirtualFileSystem;
import com.intellij.openapi.vfs.JarFileSystem;

/* Please add the ant.jar file to the IDEA JDK configuration to have every class properly imported. */

/**
 * This class represents en entry of an archive file (ZIP, JAR, EAR, WAR...) to be compared.
 * Note that this class relies on classes defined in the ANT library files,
 * which should be added to the IDEA JDK configuration.
 */
public class ZipEntry implements ArchiveFileEntry {

    private final org.apache.tools.zip.ZipFile  zipFile;
    private final org.apache.tools.zip.ZipEntry zipEntry;

    public ZipEntry(org.apache.tools.zip.ZipFile zipFile, org.apache.tools.zip.ZipEntry entry) {
        this.zipFile  = zipFile;
        this.zipEntry = entry;
    }

    public String getName() {
        return this.zipEntry.getName();
    }

    public boolean isDirectory() {
        return (this.zipEntry == null || this.zipEntry.isDirectory());
    }

    public long getTime() {
        return (this.zipEntry == null) ? 0 : this.zipEntry.getTime();
    }

    public long getSize() {
        return (this.zipEntry == null) ? 0 : this.zipEntry.getSize();
    }

    public boolean hasCrc() {
        return (this.zipEntry != null);
    }

    public long getCrc() {
        return (this.zipEntry == null) ? 0 : this.zipEntry.getCrc();
    }

    public VirtualFileSystem getVirtualFileSystem() {
        return JarFileSystem.getInstance();
    }

    public InputStream getInputStream() throws IOException {
        return this.zipFile.getInputStream(this.zipEntry);
    }

    @Override public String toString() {
        return this.zipEntry.toString();
    }
}
