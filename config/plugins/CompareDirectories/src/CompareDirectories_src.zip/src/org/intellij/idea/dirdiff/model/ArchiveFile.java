/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.intellij.idea.dirdiff.model.fs.AbstractArchiveFile;
import org.intellij.idea.dirdiff.model.fs.ArchiveFileEntry;
import org.intellij.idea.dirdiff.model.fs.TarFile;
import org.intellij.idea.dirdiff.model.fs.ZipFile;

/**
 * This class represents an archive file (ZIP, JAR, EAR, WAR, ...) to be compared.
 * Note that this class relies on classes defined in the ANT library files,
 * which should be added to the IDEA JDK configuration. 
 */
public class ArchiveFile {
    private final String        name;
    private final File          file;
    private AbstractArchiveFile zipFile;
    private boolean             closedEarly;
    private int                 numReferencingEntries;

    public ArchiveFile(String pathname) throws IOException {
        this(new File(pathname));
    }

    public ArchiveFile(File file) throws IOException {
        this.name    = file.getPath();
        this.file    = file;
        this.zipFile = this.createZipFile();
    }

    private void reopenIfClosedEarly() throws IOException {
        if (this.closedEarly) {
            this.zipFile     = this.createZipFile();
            this.closedEarly = false;
        }
    }

    private AbstractArchiveFile<? extends ArchiveFileEntry> createZipFile() throws IOException {
        return (isTarFileExtension(this.name) ? new TarFile(this.file)
                                              : new ZipFile(this.file));
    }

    public static boolean isTarFileExtension(String name) {
        return (name.endsWith(".tar") ||
                name.endsWith(".gz")  ||
                name.endsWith(".tgz"));
    }

    public String getName() {
        return this.name;
    }

    public File getFile() {
        return this.file;
    }

    public AbstractArchiveFile<? extends ArchiveFileEntry> getZipFile() throws IOException {
        this.reopenIfClosedEarly();
        return this.zipFile;
    }

    @SuppressWarnings({"unchecked"})
    public Iterable<? extends ArchiveFileEntry> entries() throws IOException {
        this.reopenIfClosedEarly();
        return this.zipFile.getEntries();
    }

    public ArchiveFileEntry getEntry(String entryName) throws IOException {
        this.reopenIfClosedEarly();
        if (this.zipFile == null) {
            return null;
        }
        this.numReferencingEntries++;
        return this.zipFile.getEntry(entryName);
    }

    public InputStream getInputStream(ArchiveFileEntry zipEntry) throws IOException {
        this.reopenIfClosedEarly();
        return this.zipFile.getInputStream(zipEntry);
    }

    public void close() throws IOException {
        if (this.zipFile != null) {
            this.numReferencingEntries--;

            if (this.numReferencingEntries <= 0) {
                this.zipFile.close();
                this.zipFile = null;
                this.closedEarly = true;
            }
        }
    }
}
