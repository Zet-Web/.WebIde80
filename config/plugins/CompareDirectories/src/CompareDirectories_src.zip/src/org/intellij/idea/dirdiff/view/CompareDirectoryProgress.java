/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.text.MessageFormat;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import org.intellij.idea.dirdiff.util.Commands;

/**
 * Holds and manages information about the progress of a comparison.
 * Note: most of this information is displayed asynchronously in a progressbar:
 * we hold it there so that a progress bar change may not be completed because
 * a more recent one is to be completed instead.
 */
public class CompareDirectoryProgress {
    private boolean       indeterminate;
    private int           minValue;
    private int           maxValue;
    private int           value;
    private MessageFormat progressFormat;
    private Object[]      progressFormatArguments;
    private boolean       visible;

    private final JProgressBar progressBar;
    private final JPanel       progressPanel;
    private final JLabel       progressLabel;

    private boolean progressTextChanged;
    private boolean indeterminationChanged;
    private boolean minValueChanged;
    private boolean maxValueChanged;

    private volatile Runnable updateCommand;

    private long lastUpdateTimestamp;

    public CompareDirectoryProgress(JProgressBar progressBar, JPanel progressPanel, JLabel progressLabel) {
        this.progressBar   = progressBar;
        this.progressPanel = progressPanel;
        this.progressLabel = progressLabel;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isIndeterminate() {
        return this.indeterminate;
    }

    public void setIndeterminate(boolean indeterminate) {
        this.indeterminate = indeterminate;
        this.indeterminationChanged = true;
    }

    public int getMinValue() {
        return this.minValue;
    }

    public void setMinValue(int minValue) {
        this.minValue = minValue;
        this.minValueChanged = true;
    }

    public int getMaxValue() {
        return this.maxValue;
    }

    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
        this.maxValueChanged = true;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void incrementValue() {
        this.value++;
    }

    public void setValueToMinimum() {
        this.value = this.minValue;
    }

    public void setValueToMaximum() {
        this.value = this.maxValue;
    }

    public String getProgressFormat() {
        return this.progressFormat.toPattern();
    }

    public void setProgressText(String progressText) {
        this.progressTextChanged = true;
        this.progressFormat      = new MessageFormat(progressText);
    }

    public void setProgressTextArguments(Object... progressTextArguments) {
        this.progressTextChanged     = true;
        this.progressFormatArguments = progressTextArguments;
    }

    private String getProgressText() {
        return this.progressFormat.format(this.progressFormatArguments);
    }

    public void updateBar(final boolean forceRefresh) {
        if (this.updateCommand == null) {
            this.updateCommand = new ProgressRunnable();
        }

        final long timestamp = System.currentTimeMillis();

        if (forceRefresh || timestamp - this.lastUpdateTimestamp > 1000L) {
            final Runnable updateCommand = this.updateCommand;

            this.lastUpdateTimestamp = timestamp;
            this.updateCommand       = null;
            Commands.invoke(updateCommand);
        }
    }

    private class ProgressRunnable implements Runnable {
        public void run() {
            final CompareDirectoryProgress progress    = CompareDirectoryProgress.this;
            final JProgressBar             progressBar = progress.progressBar;

            progress.progressPanel.setVisible(progress.visible);

            if (progress.indeterminationChanged) {
                progress.indeterminationChanged = false;
                progressBar.setIndeterminate(progress.indeterminate);
            }

            if (progress.progressTextChanged) {
                progress.progressTextChanged = false;
                progress.progressLabel.setText(progress.getProgressText());
            }

            if (progress.minValueChanged) {
                progress.minValueChanged = false;
                progressBar.setMinimum(progress.minValue);
            }

            if (progress.maxValueChanged) {
                progress.maxValueChanged = false;
                progressBar.setMaximum(progress.maxValue);
            }

            progressBar.setValue(progress.value);
        }
    }
}
