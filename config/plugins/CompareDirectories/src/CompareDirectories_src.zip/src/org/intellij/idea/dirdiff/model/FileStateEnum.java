/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;

/**
 */
public enum FileStateEnum {
    IDENTICAL                ('=', CompareDirectoryBundle.message("state.identical")),
    DIFFERENT                ('#', CompareDirectoryBundle.message("state.different")),
    DIFFERENT_IN_BLANKS      ('-', CompareDirectoryBundle.message("state.different-blanks")),
    DIFFERENT_IN_COMMENTS    ('~', CompareDirectoryBundle.message("state.different-non-significant")),
    DIFFERENT_NON_SIGNIFICANT('~', CompareDirectoryBundle.message("state.different-non-significant")),
    LEFT_ONLY                ('<', CompareDirectoryBundle.message("state.left-only")),
    RIGHT_ONLY               ('>', CompareDirectoryBundle.message("state.right-only")),
    PROBABLY_DIFFERENT       ('.', CompareDirectoryBundle.message("state.probably-different")),
    PROBABLY_IDENTICAL       ('.', CompareDirectoryBundle.message("state.probably-identical")),
    MOST_PROBABLY_IDENTICAL  ('.', CompareDirectoryBundle.message("state.most-probably-identical")),
    PSI_ELEMENT              ('*', CompareDirectoryBundle.message("state.psi-element"));

    private final char   symbol;
    private final String text;

    private FileStateEnum(char symbol, String text) {
        this.symbol = symbol;
        this.text   = text;
    }

    public char getSymbol() {
        return this.symbol;
    }

    public String getText() {
        return this.text;
    }

    public boolean isInitial() {
        return (this == PROBABLY_DIFFERENT ||
                this == PROBABLY_IDENTICAL ||
                this == MOST_PROBABLY_IDENTICAL);
    }

    public boolean isDifferent() {
        return (this == DIFFERENT                 ||
                this == DIFFERENT_IN_COMMENTS     ||
                this == DIFFERENT_NON_SIGNIFICANT ||
                this == LEFT_ONLY                 ||
                this == RIGHT_ONLY);
    }

    public boolean isDifferentInBlanksOrMore() {
        return (this == DIFFERENT                 ||
                this == DIFFERENT_IN_BLANKS       ||
                this == DIFFERENT_IN_COMMENTS     ||
                this == DIFFERENT_NON_SIGNIFICANT ||
                this == PROBABLY_IDENTICAL        ||
                this == PROBABLY_DIFFERENT);
    }

    public boolean isSideOnly() {
        return (this == LEFT_ONLY ||
                this == RIGHT_ONLY);
    }

    public boolean isProbablyOrSurelyIdentical() {
        return (this == IDENTICAL ||
                this == PROBABLY_IDENTICAL ||
                this == MOST_PROBABLY_IDENTICAL);
    }
}
