/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

/* Please add the ant.jar file to the IDEA JDK configuration to have every class properly imported. */

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.fs.AbstractArchiveFile;
import org.intellij.idea.dirdiff.model.fs.ArchiveFileEntry;

import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFile;

/**
 * This class represents an entry of a ZIP archive file (ZIP, JAR, EAR, WAR...)
 * to be compared.
 * Note that this class relies on classes defined in the ANT library files,
 * which should be added to the IDEA JDK configuration.
 */
public class ZipEntryFile extends File implements ReadableFile {

    public  static final char   PATH_SEPARATOR_CHAR       = '/';
    public  static final String PATH_SEPARATOR            = new String(new char[] { PATH_SEPARATOR_CHAR });
    public  static final int    PATH_SEPARATOR_LENGTH     = 1;
    public  static final String ZIP_PATH_SEPARATOR        = Files.denormalizeFilePath(JarFileSystem.JAR_SEPARATOR);
    public  static final int    ZIP_PATH_SEPARATOR_LENGTH = ZIP_PATH_SEPARATOR.length();

    private ArchiveFile         archiveFile;
    private String              absolutePath;
    private AbstractArchiveFile zipFile;
    private ArchiveFileEntry    zipEntry;
    private String              zipEntryPath;
    private File                extractedFile;
    private String              virtualFilePath;
    private boolean             binary;

    public ZipEntryFile(String pathname) throws IOException {
        super(pathname);

        final int separatorIndex = pathname.indexOf(ZIP_PATH_SEPARATOR);

        if (separatorIndex < 0) {
            throw new WrongZipEntryPathException(pathname);
        }
        this.archiveFile     = new ArchiveFile(pathname.substring(0, separatorIndex));
        this.zipFile         = this.archiveFile.getZipFile();
        this.zipEntryPath    = pathname.substring(separatorIndex + ZIP_PATH_SEPARATOR.length());
        this.zipEntry        = this.archiveFile.getEntry(this.zipEntryPath);
        this.absolutePath    = pathname;
        this.virtualFilePath = Files.normalizeFilePath(pathname);
    }

    public ZipEntryFile(String parent, String child) throws IOException {
        this(new LocalFileSystemFile(parent), child);
    }

    public ZipEntryFile(ReadableFile parent, String child) throws IOException {
        this(parent, new ArchiveFile(parent.getRealFile()), child);
    }

    public ZipEntryFile(ReadableFile parent, ArchiveFile archiveFile, String child) throws IOException {
        super((parent.isCompressedFile() || !parent.isInCompressedFile()
                     ? parent.getRealFile()
                     : new File(((ZipEntryFile) parent).archiveFile.getName())),
              child);

        this.archiveFile     = archiveFile;
        this.zipFile         = archiveFile.getZipFile();
        this.zipEntryPath    = child;
        this.zipEntry        = archiveFile.getEntry(child);
        this.absolutePath    = (parent.isCompressedFile() || !parent.isInCompressedFile()
                                       ? parent.getPath()
                                       : ((ZipEntryFile) parent).archiveFile.getName()) +
                               ZIP_PATH_SEPARATOR + Files.denormalizeFilePath(child);

        final String virtualPath = (parent.isCompressedFile() || !parent.isInCompressedFile())
                                       ? parent.getRealFile().getAbsolutePath()
                                       : ((ZipEntryFile) parent).archiveFile.getName();
        this.virtualFilePath = Files.normalizeFilePath(virtualPath + JarFileSystem.JAR_SEPARATOR + child);
    }

    public ZipEntryFile(ReadableFile parent, ArchiveFile archiveFile, ArchiveFileEntry child) throws IOException {
        super((parent.isCompressedFile() || !parent.isInCompressedFile()
                     ? parent.getRealFile()
                     : new File(((ZipEntryFile) parent).archiveFile.getName())),
              child.getName());

        this.archiveFile     = archiveFile;
        this.zipFile         = archiveFile.getZipFile();
        this.zipEntryPath    = child.getName();
        this.zipEntry        = child;
        this.absolutePath    = (parent.isCompressedFile() || !parent.isInCompressedFile()
                                       ? parent.getPath()
                                       : ((ZipEntryFile) parent).archiveFile.getName()) +
                               ZIP_PATH_SEPARATOR + Files.denormalizeFilePath(this.zipEntryPath);

        final String virtualPath = (parent.isCompressedFile() || !parent.isInCompressedFile())
                                        ? parent.getRealFile().getAbsolutePath()
                                        : ((ZipEntryFile) parent).archiveFile.getName();
        this.virtualFilePath = Files.normalizeFilePath(virtualPath + JarFileSystem.JAR_SEPARATOR + child.getName());
    }

    public ZipEntryFile(ArchiveFile archiveFile, String pathname) throws IOException {
        super(pathname);

        int separatorIndex  = pathname.indexOf(ZIP_PATH_SEPARATOR);

        if (separatorIndex < 0) {
            separatorIndex = pathname.indexOf(JarFileSystem.JAR_SEPARATOR);
        }
        if (separatorIndex < 0) {
            throw new WrongZipEntryPathException(pathname);
        }
        this.archiveFile  = archiveFile;
        this.zipFile      = archiveFile.getZipFile();
        this.zipEntryPath = pathname.substring(separatorIndex + ZIP_PATH_SEPARATOR.length());
        this.zipEntry     = archiveFile.getEntry(this.zipEntryPath);
        this.absolutePath = pathname;
    }

    public ArchiveFile getArchiveFile() {
        return this.archiveFile;
    }

    @Override public boolean isDirectory() {
        return (this.zipEntry == null || this.zipEntry.isDirectory());
    }

    @Override public long lastModified() {
        return ((this.zipEntry == null) ? 0 : this.zipEntry.getTime());
    }

    @Override public long length() {
        return ((this.zipEntry == null) ? 0 : this.zipEntry.getSize());
    }

    public boolean hasCrc() {
        return (this.zipEntry != null && this.zipEntry.hasCrc());
    }

    public long getCrc() {
        return ((this.zipEntry == null) ? 0 : this.zipEntry.getCrc());
    }

    @Override public boolean exists() {
        return (this.zipEntry != null);
    }

    @Override public String getPath() {
        return this.absolutePath;
    }

    @Override public File getAbsoluteFile() {
        return new File(this.getAbsolutePath());
    }

    public VirtualFile getVirtualFile() {
        return (this.zipEntry == null || this.virtualFilePath == null)
                    ? null
                    : this.zipEntry.getVirtualFileSystem().findFileByPath(this.virtualFilePath);
    }

    public String getExtension() {
        final String name  = this.getName();
        final int    index = name.lastIndexOf('.') + 1;

        return ((index == 0) ? "" : name.substring(index, name.length()));
    }

    public FileType getFileType() {
        return FileTypeManager.getInstance().getFileTypeByFileName(this.absolutePath);
    }

    public String getParentPath() {
        final String path                   = this.getPath();
        final int    index                  = path.length() - this.getName().length();
        final int    zipPathSeparatorLength = ZIP_PATH_SEPARATOR.length();

        return (path.regionMatches(index - zipPathSeparatorLength, ZIP_PATH_SEPARATOR,          0, zipPathSeparatorLength) ||
                path.regionMatches(index - zipPathSeparatorLength, JarFileSystem.JAR_SEPARATOR, 0, zipPathSeparatorLength))
                     ? path.substring(0, index - zipPathSeparatorLength)
                     : path.substring(0, index - File.separator.length());
    }

    public InputStream getInputStream() throws IOException {
        // If the ZIP file has been closed then reopened, ZIP entry has to be recreated
        if (this.zipFile != this.archiveFile.getZipFile()) {
            this.zipFile  = this.archiveFile.getZipFile();
            this.zipEntry = this.archiveFile.getEntry(this.zipEntryPath);
        }
        return this.archiveFile.getInputStream(this.zipEntry);
    }

    public ReadableFile getAncestor(int subPathLength) {
        // Parent does not exist yet => create it
        try {
            final String pathname = this.absolutePath.substring(0, this.absolutePath.length() - subPathLength);

            return new ZipEntryFile(this.archiveFile, Files.normalizeFilePath(pathname));
        } catch (IOException e) {
            return null;
        }
    }

    public boolean isCompressedFile() {
        return this.getFileType().equals(StdFileTypes.ARCHIVE);
    }

    public boolean isInCompressedFile() {
        return true;
    }

    public File getRealFile() {
        return ((this.extractedFile == null) ? this : this.extractedFile);
    }

    public void finalizeIt() {
        this.close();
        this.zipFile.finalizeIt();
    }

    public boolean extractEntry() {
        try {
            this.extractedFile = Files.extractTempFile(this.getInputStream());
            return (this.extractedFile != null);
        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            return false;
        }
    }

    @SuppressWarnings({ "SimplifiableIfStatement" })
    public boolean hasDescendant(String path, boolean strict) {
        if (path == null) {
            return false;
        }

        final int offset        = this.virtualFilePath.lastIndexOf(JarFileSystem.JAR_SEPARATOR) +
                                  JarFileSystem.JAR_SEPARATOR.length();
        final int subPathLength = this.virtualFilePath.length() - offset;

        if (!path.regionMatches(0, this.virtualFilePath, offset, subPathLength)) {
            return false;
        } else if (strict && path.length() == subPathLength) {
            return false;
        } else if (!(this.virtualFilePath.endsWith(ZipEntryFile.PATH_SEPARATOR)  ||
                     path.startsWith(ZipEntryFile.PATH_SEPARATOR, subPathLength) ||
                     ZipEntryFile.PATH_SEPARATOR.startsWith(path, subPathLength) ||
                     JarFileSystem.JAR_SEPARATOR.startsWith(path, subPathLength))) {
            return false;
        } else {
            return (!path.substring(subPathLength).equals(ZipEntryFile.PATH_SEPARATOR));
        }
    }

    public boolean isBinary() {
        return this.binary;
    }

    public void setBinary(boolean binary) {
        this.binary = binary;
    }

    public void releaseLock() {
        if (this.archiveFile != null) {
            try {
                this.archiveFile.close();
            } catch (IOException e) {
                // Ignore
            }
        }
    }

    public void close() {
        this.zipEntry = null;

        if (this.extractedFile != null) {
            if (this.extractedFile.delete()) {
                this.extractedFile = null;
            } else {
                CompareDirectoryPlugin.getLogger().warn("Could not delete temp file " + this.extractedFile.getAbsolutePath());
            }
        }

        if (this.archiveFile != null) {
            try {
                this.archiveFile.close();
            } catch (IOException e) {
                // Ignore
            }
        }
    }

    private static final class WrongZipEntryPathException extends IOException {
        @SuppressWarnings({"HardCodedStringLiteral"})
        public WrongZipEntryPathException(String pathname) {
            super(pathname + " is not a zip entry path");
        }
    }
}
