/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.actiondelegate.AbstractToggleActionDelegate;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.CompareDirectoryView;
import org.intellij.idea.dirdiff.view.IconUtil;
import org.jetbrains.annotations.NonNls;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataKeys;
import com.intellij.openapi.actionSystem.ToggleAction;
import com.intellij.openapi.project.Project;

/**
 */
public class CompareDirectoryToggleAction extends ToggleAction implements ACompareDirectoryAction {

    private CompareDirectoryPanel        panel;
    private AbstractToggleActionDelegate actionDelegate;

    public CompareDirectoryToggleAction() {}

    public CompareDirectoryToggleAction(final CompareDirectoryPanel        panel,
                                        @NonNls final String               actionKey,
                                        final AbstractToggleActionDelegate actionDelegate) {
        super(CompareDirectoryBundle.message("title." + actionKey),
              CompareDirectoryBundle.message("text."  + actionKey),
              IconUtil.createIconWithKey    ("icon."  + actionKey));
        this.panel          = panel;
        this.actionDelegate = actionDelegate;
    }

    protected static Project getProject(AnActionEvent event) {
        return DataKeys.PROJECT.getData(event.getDataContext());
    }

    public CompareDirectoryPanel getPanel(AnActionEvent event) {
        final Project              project              = getProject(event);
        final CompareDirectoryView compareDirectoryView = CompareDirectoryPlugin.getView(project);

        if (compareDirectoryView != null) {
            this.panel = compareDirectoryView.getCurrentPanel();
            return this.panel;
        }

        // Try to recover...
        return ((project != null && this.panel != null && project.equals(this.panel.getView().getProject())) ? this.panel : null);
    }

    public AbstractToggleActionDelegate getActionDelegate() {
        return this.actionDelegate;
    }

    public boolean isVisible(ICompareDirectoryPanel panel) {
        return this.actionDelegate.isVisible(panel, null);
    }

    @Override public boolean isSelected(AnActionEvent event) {
        return (this.actionDelegate != null &&
                this.actionDelegate.isSelected(this.getPanel(event)));
    }

    @Override public void setSelected(AnActionEvent event, boolean state) {
        if (this.actionDelegate != null) {
            this.actionDelegate.setSelected(state, this.getPanel(event));
        }
    }
}
