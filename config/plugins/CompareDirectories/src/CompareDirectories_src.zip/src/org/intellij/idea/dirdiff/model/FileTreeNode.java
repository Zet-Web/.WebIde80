/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.File;
import java.io.IOException;
import java.util.Comparator;

import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.vfs.JarFileSystem;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.model.disassemble.AsmUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 */
public class FileTreeNode extends ComparedTreeNode implements Finalizable {

    private ReadableFile  leftFile;
    private ReadableFile  rightFile;
    private FileType      fileType;

    public static final Comparator<? super ReadableFile> pathComparator =
        new Comparator<ReadableFile>() {
            public int compare(ReadableFile o1, ReadableFile o2) {
                return o1.getPath().compareTo(o2.getPath());
            }
        };

    /**
     * Creates a new file tree node.
     * @param name      the node name
     * @param parent    the node parent
     * @param model     the tree model
     * @param leftFile  the left file of this node
     * @param rightFile the right file of this node
     */
    public FileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model,
                        ReadableFile leftFile, ReadableFile rightFile) {
        this(name, parent, model, leftFile, rightFile, getInitialState(leftFile, rightFile));
    }

    /**
     * Creates a new side-only file tree node.
     * @param name      the node name
     * @param parent    the node parent
     * @param model     the tree model
     * @param file      the left-only or right-only file of this node
     * @param state     the state of this node.
     */
    private FileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model,
                         ReadableFile file, FileStateEnum state) {
        this(name, parent, model, file, file, state);
    }

    /**
     * Creates a new file tree node.
     * @param name      the node name
     * @param parent    the node parent
     * @param model     the tree model
     * @param leftFile  the left file of this node
     * @param rightFile the right file of this node
     * @param state     the state of this node.
     */
    public FileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model,
                        ReadableFile leftFile, ReadableFile rightFile, FileStateEnum state) {
        super(name, parent, model, state);
        this.leftFile  = leftFile;
        this.rightFile = rightFile;
        this.fileType  = leftFile.getFileType();
        this.setState(state);  // Update "notFiltered" field
    }

    /**
     * Constructor used for unit test purpose only
     * @param name the node name
     * @param parent the node parent
     */
    FileTreeNode(String name, ComparedTreeNode parent) {
        super(name, parent);
    }

    /**
     * Creates a new file tree node or a new file tree node hierarchy.
     * @param parent    the node parent
     * @param model     the tree model
     * @param leftFile  the left file of this node
     * @param rightFile the right file of this node
     * @param isClass   <code>true</code> if the files are compiled Java classes, <code>false</code> otherwise
     * @return the newly created node, or <tt>null</tt> if a subnode of an existing node has been created
     */
    public static FileTreeNode getFileTreeNode(FileTreeNode parent, FileTreeModel model,
                                               ReadableFile leftFile, ReadableFile rightFile, boolean isClass) {
        FileTreeNode  parent1            = parent;
        String        relativePath       = parent1.getDescendantRelativePath(leftFile, true);
        final boolean isDirectoryPath    = leftFile.getPath().endsWith(File.separator);
        int           fileSeparatorIndex = relativePath.indexOf(File.separatorChar);
        FileTreeNode  node               = null;

        while (fileSeparatorIndex >= 0) {
            final boolean isCompressed    = (fileSeparatorIndex > 0  &&
                                             relativePath.startsWith(ZipEntryFile.ZIP_PATH_SEPARATOR, fileSeparatorIndex - ZipEntryFile.ZIP_PATH_SEPARATOR.length() + 1));
            final int     separatorLength = (isCompressed ? ZipEntryFile.ZIP_PATH_SEPARATOR.length() : 1);
            final String  name            = relativePath.substring(0, fileSeparatorIndex + 1 - separatorLength);
            final int     childIndex      = parent1.indexOf(name);

            if (childIndex < 0) {
                final int          ancestorPathLength = relativePath.length() - name.length() + separatorLength - (isDirectoryPath ? 2 : 1);
                final ReadableFile leftElement        = leftFile .getAncestor(ancestorPathLength);
                final ReadableFile rightElement       = rightFile.getAncestor(ancestorPathLength);

                parent1 = new FileTreeNode(name, parent1, model, leftElement, rightElement);
                parent1.getParent().addChildNode(parent1);
            } else {
                parent1 = (FileTreeNode) parent1.getChildAt(childIndex);
            }

            if (node == null) {
                node = parent1;
            }
            relativePath = relativePath.substring(fileSeparatorIndex + 1);
            fileSeparatorIndex = relativePath.indexOf(File.separatorChar);
        }

        parent1 = (isClass ? new ClassFileTreeNode(relativePath, parent1, model, leftFile, rightFile)
                           : new FileTreeNode     (relativePath, parent1, model, leftFile, rightFile));
        if (node != null) {
            final ComparedTreeNode grandParent = parent1.getParent();

            grandParent.addChildNode(parent1);
            if (grandParent.getState().isSideOnly() && !parent1.getState().isSideOnly()) {
                propagateStateToRoot(grandParent, grandParent.getState(), parent1.getState());
            }
        }
        model.incrementNumFiles(parent1.getState());
        return ((node == null) ? parent1 : null);
    }

    /**
     * Creates a new side-only file tree node.
     * @param parent    the node parent
     * @param model     the tree model
     * @param file      the left-only or right-only file of this node
     * @param isClass   <code>true</code> if the file is a compiled Java class, <code>false</code> otherwise
     * @param state     the state of this node.
     * @return the newly created node, or <tt>null</tt> if a subnode of an existing node has been created
     */
    public static FileTreeNode getFileTreeNode(FileTreeNode parent, FileTreeModel model,
                                               ReadableFile file, boolean isClass, FileStateEnum state) {
        FileTreeNode parent1            = parent;
        String       relativePath       = parent1.getDescendantRelativePath(file, (state == FileStateEnum.LEFT_ONLY));
        int          fileSeparatorIndex = relativePath.indexOf(File.separatorChar);
        FileTreeNode node               = null;

        while (fileSeparatorIndex >= 0) {
            final boolean isCompressed    = (fileSeparatorIndex > 0 &&
                                             relativePath.startsWith(ZipEntryFile.ZIP_PATH_SEPARATOR, fileSeparatorIndex - ZipEntryFile.ZIP_PATH_SEPARATOR.length() + 1));
            final int     separatorLength = (isCompressed ? ZipEntryFile.ZIP_PATH_SEPARATOR.length() : 1);
            final String  name            = relativePath.substring(0, fileSeparatorIndex + 1 - separatorLength);
            final int     childIndex      = parent1.indexOf(name);

            if (childIndex < 0) {
                final ReadableFile fileElement = file.getAncestor(relativePath.length() - name.length());

                parent1 = new FileTreeNode(name, parent1, model, fileElement, state);
            } else {
                parent1 = (FileTreeNode) parent1.getChildAt(childIndex);
            }

            if (node == null) {
                node = parent1;
            } else if (childIndex < 0) {
                parent1.addChildNode(node);
            }
            relativePath = relativePath.substring(fileSeparatorIndex + 1);
            fileSeparatorIndex = relativePath.indexOf(File.separatorChar);
        }

        parent1 = (isClass ? new ClassFileTreeNode(relativePath, parent1, model, file, state)
                           : new FileTreeNode     (relativePath, parent1, model, file, state));
        if (node != null) {
            parent1.getParent().addChildNode(parent1);
        }
        model.incrementNumFiles(state);
        return ((node == null) ? parent1 : null);
    }

    public String getDescendantRelativePath(ReadableFile file, boolean isLeft) {
        final ReadableFile parentFile     = (isLeft ? this.getLeftFile() : this.getRightFile());
        final String       parentPath     = parentFile.getPath();
        final String       filePath       = file.getPath();
        final int          filePathLength = filePath.length();

        final int pathEndIndex   = filePathLength - (filePath.endsWith(File.separator) ? File.separator.length() : 0);
        final int pathStartIndex = (parentPath.length() +
                                    (parentPath.endsWith(File.separator)                           ? 0 :
                                     file.isInCompressedFile() && !parentFile.isInCompressedFile() ? ZipEntryFile.ZIP_PATH_SEPARATOR.length()
                                                                                                   : 1));

        return ((pathStartIndex >= filePathLength) ? "" : filePath.substring(pathStartIndex, pathEndIndex));
    }

    public static File getFile(String filePath, ArchiveFile archiveFile, boolean isZipped) {
        try {
            return (isZipped ? new ZipEntryFile(archiveFile, filePath)
                             : new File(filePath));
        } catch (IOException e) {
            return new File(filePath);
        }
    }

    public FileType getFileType() {
        return this.fileType;
    }

    public final ReadableFile getSideFile(boolean isSideLeft) {
        if (!this.state.isSideOnly()) {
            return (isSideLeft ? this.leftFile : this.rightFile);
        }

        final ReadableFile file            = this.leftFile; // leftFile == rightFile since file node is side-only
        final boolean      isRightOnlyNode = (this.state == FileStateEnum.RIGHT_ONLY);

        if (isSideLeft ^ isRightOnlyNode) {
            return file;
        }

        final FileTreeNode rootNode      = (FileTreeNode) this.getRoot();
        final ReadableFile fileRoot      = (isRightOnlyNode ? rootNode.rightFile : rootNode.leftFile);
        final ReadableFile otherFileRoot = (isRightOnlyNode ? rootNode.leftFile  : rootNode.rightFile);
        final int          index         = fileRoot.getPath().length() +
                                           (fileRoot.isCompressedFile() && !otherFileRoot.isCompressedFile() ? 1 : 0);

        return FileTreeNode.getReadableFile(otherFileRoot, file.getPath().substring(index));
    }

    public final ReadableFile getOtherSideFile(boolean isSideLeft) {
        return this.getSideFile(!isSideLeft);
    }

    /**
     * Returns <code>true</code> if this node should be ignored, <code>false</code> otherwise.
     * A node should be ignored if IDEA ignores it or if it matches user-defined ignoring file
     * patterns directories or if it is a directory that contains only ignored or hidden children.
     * @return <code>true</code> if this node should be ignored, <code>false</code> otherwise.
     */
    public boolean isIgnored() {
        return (FileTypeManager.getInstance().isFileIgnored(this.getName()) ||
                this.getModel().isAnyMatchWithExcludedFileMasks(this.leftFile.getPath(), this.rightFile.getPath()) ||
                (this.hasChildren() && !this.hasFilteredChildren()));
    }

    @SuppressWarnings({ "ConditionalExpressionWithNegatedCondition" })
    public static FileStateEnum getInitialState(ReadableFile leftFile, ReadableFile rightFile) {
        if (leftFile.isDirectory()) {
            return (!rightFile.isDirectory()                            ? FileStateEnum.DIFFERENT :
                    leftFile.lastModified() != rightFile.lastModified() ? FileStateEnum.PROBABLY_IDENTICAL
                                                                        : FileStateEnum.MOST_PROBABLY_IDENTICAL);
        } else {
            return (rightFile.isDirectory()                             ? FileStateEnum.DIFFERENT          :
                    leftFile.length()       != rightFile.length()       ? FileStateEnum.PROBABLY_DIFFERENT :
                    leftFile.lastModified() != rightFile.lastModified() ? FileStateEnum.PROBABLY_IDENTICAL
                                                                        : FileStateEnum.MOST_PROBABLY_IDENTICAL);
        }
    }

    public FileStateEnum updateInitialState() {
        final Iterable<ComparedTreeNode> children = this.getChildren();

        if (children != null) {
            final boolean notInitiallyDifferent            = (!this.getState().isDifferent());
            boolean       different                        = false;
            boolean       allChildrenMostProbablyIdentical = true;

            for (ComparedTreeNode childNode : children) {
                final FileStateEnum childNodeState = childNode.updateInitialState();

                if (notInitiallyDifferent && !different) {
                    if (childNodeState != FileStateEnum.MOST_PROBABLY_IDENTICAL) {
                        allChildrenMostProbablyIdentical = false;
                    }

                    if (childNodeState == FileStateEnum.DIFFERENT ||
                        childNodeState == FileStateEnum.LEFT_ONLY ||
                        childNodeState == FileStateEnum.RIGHT_ONLY) {
                        different = true;
                    }
                }
            }

            if (notInitiallyDifferent) {
                if (different) {
                    this.setState(FileStateEnum.DIFFERENT);
                } else if (allChildrenMostProbablyIdentical) {
                    this.setState(FileStateEnum.MOST_PROBABLY_IDENTICAL);
                }
            }
        }

        return this.state;
    }

    private static void propagateStateToRoot(ComparedTreeNode node, FileStateEnum oldState, FileStateEnum newState) {
        ComparedTreeNode parent = node;

        while (parent != null && parent.getState() == oldState) {
            parent.setState(newState);
            parent = parent.getParent();
        }
    }

    public void moveInnerClassNodes() {
        final ComparedTreeNode[] children = (this.children == null) ? new ComparedTreeNode[0]
                                                                    : (ComparedTreeNode[]) this.children.toArray(new ComparedTreeNode[this.children.size()]);

        for (ComparedTreeNode child : children) {
            final String name = child.getName();

            if (child instanceof ClassFileTreeNode && AsmUtil.isInnerClass(name)) {
                final int    newParentNodeIndex = this.indexOf(AsmUtil.getOuterClass((String) child.getUserObject()));
                final Object foundNode          = (newParentNodeIndex < 0) ? null : this.children.get(newParentNodeIndex);

                if (foundNode instanceof ClassFileTreeNode) {
                    final ClassFileTreeNode newParentNode = (ClassFileTreeNode) foundNode;

                    this.remove(child);
                    child.setParent(newParentNode);
                    newParentNode.addChildNode(child, name, FileTreeModel.childNameComparator);
                    if (AsmUtil.isInnerClass(AsmUtil.getInnerClass(name))) {
                        newParentNode.moveInnerClassNodes();
                    }
                }
            } else if (child instanceof FileTreeNode && child.hasChildren()) {
                ((FileTreeNode) child).moveInnerClassNodes();
            }
        }
    }

    public ReadableFile getLeftFile() {
        return this.leftFile;
    }

    public void setLeftFile(ReadableFile leftFile) {
        this.leftFile = leftFile;
    }

    public ReadableFile getRightFile() {
        return this.rightFile;
    }

    public void setRightFile(ReadableFile rightFile) {
        this.rightFile = rightFile;
    }

    public ComparedTreeNode mergeWithNode(ComparedTreeNode rightNode) {
        if (this     .getState() != FileStateEnum.LEFT_ONLY  ||
            rightNode.getState() != FileStateEnum.RIGHT_ONLY ||
            !this.getClass().equals(rightNode.getClass())) {
            return null;
        }

        // Destroy every subnode of this and the right nodes but do not finalize this
        // and the right node, because future left and right files must not be closed.
        this     .closeChildrenFiles();
        this     .removeAllChildren();
        rightNode.closeChildrenFiles();
        rightNode.removeAllChildren();

        this.getParent().remove(rightNode);

        this.rightFile  = ((FileTreeNode) rightNode).rightFile;
        this.setState(FileStateEnum.PROBABLY_DIFFERENT);
        this.userObject = CompareDirectoryBundle.message("node.vs", this.leftFile.getName(), this.rightFile.getName());

        return this;
    }

    public boolean isMerged() {
        return (!this.leftFile.getName().equals(this.rightFile.getName()));
    }

    public ComparedTreeNode[] split() {
        final ComparedTreeNode parentNode = this.getParent();

        if (parentNode == null ||
            this.leftFile.getName().equals(this.rightFile.getName()) ||
            parentNode.indexOf(this.rightFile.getName()) >= 0) {

            return new ComparedTreeNode[0];
        }

        return new ComparedTreeNode[] { this, this.split(parentNode) };
    }

    @NotNull
    @Override protected ComparedTreeNode split(ComparedTreeNode parentNode) {
        final ComparedTreeNode splitNode = super.split(parentNode);

        if (splitNode != null) {
            return splitNode;
        }

        final boolean          isClass        = StdFileTypes.CLASS.equals(this.rightFile.getFileType());
        final ComparedTreeNode rightChildNode = (isClass ? new ClassFileTreeNode(this.rightFile.getName(), parentNode, this.getModel(),
                                                                                 this.rightFile, FileStateEnum.RIGHT_ONLY)
                                                         : new FileTreeNode     (this.rightFile.getName(), parentNode, this.getModel(),
                                                                                 this.rightFile, FileStateEnum.RIGHT_ONLY));

        parentNode.addChildNode(rightChildNode);
        this.rightFile  = this.leftFile;
        this.userObject = this.leftFile.getName();
        this.setState(FileStateEnum.LEFT_ONLY);

        this          .setNotFiltered(TreeNodeFilters.isNotFiltered(this,           this.getModel().getFilters()));
        rightChildNode.setNotFiltered(TreeNodeFilters.isNotFiltered(rightChildNode, this.getModel().getFilters()));

        this.splitChildrenNodes(rightChildNode);

        return rightChildNode;
    }

    @NotNull public FileStateEnum computeState(Interruptible interruptible) {
        if (this.hasChildren()) {
            return this.state;
        }

        // Optimisation: if node files are archive entry files which are probably
        // or most-probably identical, then use Zip file CRC to check whether
        // exhaustive file contents comparison is really needed: if CRCs are
        // identical, then file contents are assumed identical.
        if (this.state.isProbablyOrSurelyIdentical() && Files.haveSameCrc(this.getLeftFile(), this.getRightFile())) {
            return FileStateEnum.IDENTICAL;
        }

        return Files.checkNodeFiles(this, interruptible);
    }

    public void releaseFileLocks() {
        this.getLeftFile() .releaseLock();
        this.getRightFile().releaseLock();
        super.releaseFileLocks();
    }

    public void finalizeIt() {
        this.getLeftFile() .finalizeIt();
        this.getRightFile().finalizeIt();
        this.closeChildrenFiles();
        this.removeAllChildren();
    }

    @SuppressWarnings({"unchecked"})
    protected void swapThisLeftRight() {
        final ReadableFile tmpFile = this.leftFile;

        this.leftFile  = this.rightFile;
        this.rightFile = tmpFile;
        if (this.isMerged()) {
            this.userObject = CompareDirectoryBundle.message("node.vs", this.leftFile.getName(), this.rightFile.getName());
        }

        if (this.state == FileStateEnum.LEFT_ONLY) {
            this.setState(FileStateEnum.RIGHT_ONLY);
        } else if (this.state == FileStateEnum.RIGHT_ONLY) {
            this.setState(FileStateEnum.LEFT_ONLY);
        }
    }

    @SuppressWarnings({"unchecked"})
    public void refreshThisCacheFiles(boolean asynchronous) {
        Files.refreshNodeFiles(this, asynchronous);
    }

    public FileTreeNode findNodeWithRelativePath(String relativePath, boolean isLeftFile) {
        final int     fileSeparatorIndex = relativePath.indexOf(File.separatorChar);
        final boolean isCompressed       = (fileSeparatorIndex > 0 &&
                                            relativePath.startsWith(ZipEntryFile.ZIP_PATH_SEPARATOR, fileSeparatorIndex - ZipEntryFile.ZIP_PATH_SEPARATOR.length() + 1));
        final int     separatorLength    = (isCompressed ? ZipEntryFile.ZIP_PATH_SEPARATOR.length() : 1);
        final String  name               = ((fileSeparatorIndex < 0) ? relativePath : relativePath.substring(0, fileSeparatorIndex + 1 - separatorLength));
        final int     childIndex         = (isLeftFile ? this.leftIndexOf(name) : this.rightIndexOf(name));

        if (childIndex < 0) {
            return null;
        }

        final FileTreeNode node = (FileTreeNode) this.getChildAt(childIndex);

        return ((fileSeparatorIndex < 0) ? node : node.findNodeWithRelativePath(relativePath.substring(fileSeparatorIndex + 1), isLeftFile));
    }

    @NotNull public static ReadableFile getReadableFile(@Nullable String pathname) {
        if (pathname != null) {
            try {
                final int[]  archiveFileSignIndex = { pathname.indexOf(JarFileSystem.JAR_SEPARATOR),
                                                      pathname.indexOf(ZipEntryFile.ZIP_PATH_SEPARATOR) };

                for (int index : archiveFileSignIndex) {
                    if (index >= 0) {
                        // In ZIP files, directory names MUST end with a '/' or they cannot be found...
                        // So we add one.
                        final String archiveFilePath = pathname.substring(0, index);
                        final String childPath       = pathname.substring(index + JarFileSystem.JAR_SEPARATOR.length()) +
                                                       ZipEntryFile.PATH_SEPARATOR_CHAR;
                        return new ZipEntryFile(archiveFilePath, childPath);
                    }
                }
            } catch (IOException e) {
                // Ignore it and treat as local file system file
            }
        }

        return new LocalFileSystemFile(pathname);
    }

    @NotNull public static ReadableFile getReadableFile(@NotNull File file) {
        return FileTreeNode.getReadableFile(file.getAbsolutePath());
    }

    @NotNull public static ReadableFile getReadableFile(@NotNull ReadableFile ancestorFile,
                                                        @NotNull String       childSubPath) {
        return FileTreeNode.getReadableFile(ancestorFile.getPath() + File.separatorChar + childSubPath);
    }

    @Override public int compareTimestamps() {
        final long left  = (this.leftFile  == null) ? 0 : this.leftFile .lastModified();
        final long right = (this.rightFile == null) ? 0 : this.rightFile.lastModified();

        return (left == right ?  0 :
                left <  right ? -1
                              : +1);
    }
}
