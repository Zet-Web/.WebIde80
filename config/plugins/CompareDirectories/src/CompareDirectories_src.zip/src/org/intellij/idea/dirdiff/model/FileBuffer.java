/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.BufferedInputStream;
import java.io.IOException;

/**
 * Encapsulation of a byte file stream read through a buffered stream.
 */
class FileBuffer {
    private static final int BINARY_THRESHOLD = 75;

    private BufferedInputStream inputStream;
    private final byte[]        byteBuffer;
    private final int           bufferSize;
    private int                 index;
    private int                 numBytesRead;
    private boolean             markEnabled;
    private int                 markIndex;
    private StringBuilder       markedText;

    public FileBuffer(int bufferSize) {
        this.bufferSize = bufferSize;
        this.byteBuffer = new byte[bufferSize];
    }

    public void openStream(ReadableFile file) throws IOException {
        this.inputStream = new BufferedInputStream(file.getInputStream(), this.bufferSize);
        this.readStream();
        this.resetMark();
    }

    void readStream() throws IOException {
        this.numBytesRead = this.inputStream.read(this.byteBuffer);
        this.index = 0;
    }

    public boolean hasBytes() {
        return (this.numBytesRead >= 0);
    }

    public byte getByte() {
        if (this.numBytesRead < 0) {
            throw new IndexOutOfBoundsException(Integer.toString(this.index));
        }
        return this.byteBuffer[this.index];
    }

    public void goToNextByte() throws IOException {
        this.index++;
        if (this.index >= this.numBytesRead) {
            if (this.markEnabled && this.markIndex >= 0) {
                if (this.markedText == null) {
                    this.markedText = new StringBuilder(this.bufferSize);
                }
                this.markedText.append(new String(this.byteBuffer, this.markIndex, this.index - this.markIndex));
                this.markIndex = 0;
            }

            this.readStream();
        }
    }

    int getNumBytesRead() {
        return this.numBytesRead;
    }

    byte[] getByteBuffer() {
        return this.byteBuffer;
    }

    public void enableMark(boolean enabled) {
        this.markEnabled = enabled;
    }

    public boolean isMarkEnabled() {
        return this.markEnabled;
    }

    void resetMark() {
        this.markIndex  = 0;
        this.markedText = null;
    }

    public void setMark() {
        if (this.markEnabled) {
            this.markIndex  = this.index;
            this.markedText = null;
        }
    }

    public String getTextFromMark() {
        if (!this.markEnabled) {
            return "";
        } else if (this.markedText == null) {
            return new String(this.byteBuffer, this.markIndex, this.index - this.markIndex);
        } else {
            this.markedText.append(new String(this.byteBuffer, this.markIndex, this.index - this.markIndex));
            return this.markedText.toString();
        }
    }

    /**
     * Skips characters as long as they are white spaces.
     * @throws IOException
     */
    public void skipWhiteSpaceBytes() throws IOException {
        do {
            this.goToNextByte();
        } while (this.hasBytes() && Character.isWhitespace(this.byteBuffer[this.index]));
    }

    /**
     * Skips characters until the first found end-of-line, including this end-of-line character.
     * @throws IOException
     */
    public void skipUntilEndOfLine() throws IOException {
        do {
            this.goToNextByte();
        } while (this.hasBytes() && !isEndOfLineCharacter(this.byteBuffer[this.index]));

        if (this.hasBytes()) { // Skip end-of-line character
            this.goToNextByte();
        }
    }

    /**
     * Skips characters until the first found end-of-line, detecting non-white-space
     * characters.
     * @return <code>true</code> if a non-white-space character is detected among the
     *         skipped characters, <code>false</code> otherwise
     * @throws IOException
     */
    public boolean skipUntilEndOfLineDetectingNonWhiteSpaces() throws IOException {
        boolean onlyWhitespaces = true;

        do {
            onlyWhitespaces &= Character.isWhitespace(this.getByte());
            this.goToNextByte();
        } while (this.hasBytes() && !isEndOfLineCharacter(this.byteBuffer[this.index]));
        return !onlyWhitespaces;
    }

    /**
     * Skips bytes until this byte sequence is found (this byte sequence
     * is also skipped).
     * @param bytes the byte sequence to be found
     * @throws IOException
     */
    public void skipUntilByteSequence(byte[] bytes) throws IOException {
        final int numBytes  = bytes.length;
        int       byteIndex = 0;

        do {
            this.goToNextByte();
            if (!this.hasBytes()) {
                break;
            }

            if (bytes[byteIndex] == this.byteBuffer[this.index]) {
                byteIndex++;
            } else {
                byteIndex = 0;
            }
        } while (byteIndex < numBytes);

        if (this.hasBytes()) {
            this.goToNextByte();
        }
    }

    /**
     * Returns <code>true</code> if this character is an end-of-line character,
     *         <code>false</code> otherwise.
     * @return <code>true</code> if this character is an end-of-line character,
     *         <code>false</code> otherwise
     */
    public static boolean isEndOfLineCharacter(byte b) {
        return (b == 0x0D || b == 0x0A);
    }

    public void closeStream() throws IOException {
        this.inputStream.close();
        this.resetMark();
    }

    /**
     * Checks whether file contents are binary.<br>
     * The algorithm is based on the following heuristics:
     * if less than 75% of the bytes of the beginning of the file are
     * alphanumeric or space characters, the file is considered binary.
     *
     * @param file  the file to be checked or whose binary property
     *              is to be set
     * @return <tt>true</tt> if the file is considered binary,
     *         <tt>false</tt> otherwise.
     */
    public boolean checkBinary(ReadableFile file) {
        final int threshold = this.numBytesRead * BINARY_THRESHOLD / 100;
        int       count     = 0;
        int       index     = 0;

        while (index < this.numBytesRead && count < threshold) {
            final byte codePoint = this.byteBuffer[index];

            if (Character.isLetterOrDigit(codePoint) ||
                Character.isWhitespace   (codePoint) ||
                codePoint == '<' || codePoint == '>' || codePoint == '/' ||   // For a better support of HTML/XML files
                codePoint == '-' || codePoint == '*' || codePoint == '+' ||   // For a better support of source files
                codePoint == '#' ||
                codePoint == '(' || codePoint == '[' || codePoint == '{' ||
                codePoint == ')' || codePoint == ']' || codePoint == '}') {
                count++;
            }
            index++;
        }

        final boolean binary = (count < threshold);

        file.setBinary(binary);
        return binary;
    }
}
