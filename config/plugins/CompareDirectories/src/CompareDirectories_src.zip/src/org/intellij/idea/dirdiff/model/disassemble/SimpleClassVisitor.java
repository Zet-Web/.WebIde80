/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.asm4.AnnotationVisitor;
import org.jetbrains.asm4.Attribute;
import org.jetbrains.asm4.FieldVisitor;
import org.jetbrains.asm4.MethodVisitor;
import org.jetbrains.asm4.Type;
import org.jetbrains.asm4.signature.SignatureReader;

/**
 * Class visitor, which either gathers field and method signatures without
 * parsing code, or gathers them and parses code and write it into a byte
 * array (through a byte vector).
 * <p/>Note: Writing parsed code into strings makes diffs viewable, but
 * it's about 3 times slower than writing it into bytes.
 * @see MyMethodVisitor
 */
public class SimpleClassVisitor extends MyClassVisitor {

    private String                      className;
    private String                      simpleClassName;
    private String                      superClassName;
    private int                         javaVersion;
    private final JavaClassDesc         classDesc;
    private final MyClassVisitorContext context;
    private final boolean               parseCode;

    public SimpleClassVisitor(@NotNull MyClassVisitorContext context, boolean parseCode) {
        this.classDesc = new JavaClassDesc();
        this.context   = context;
        this.parseCode = parseCode;
    }

    public String getClassName() {
        return this.className;
    }

    public JavaClassDesc getClassDesc() {
        return this.classDesc;
    }

    public String getSimpleClassName() {
        return this.simpleClassName;
    }

    public String getSuperClassName() {
        return this.superClassName;
    }

    @Override public void visit(int      version,
                                int      accessFlags,
                                String   name,
                                String   signature,
                                String   superName,
                                String[] interfaces) {
        this.superClassName  = AsmUtil.getQualified      ((superName == null) ? name : superName);  // superName == null if name = "java/lang/Object"
        this.className       = AsmUtil.getQualified      (name);
        this.simpleClassName = AsmUtil.getSimpleClassName(this.className);
        this.javaVersion     = AsmUtil.getVersion        (version);

        this.classDesc.setAccessFlags(accessFlags);
        this.classDesc.setClassName  (this.simpleClassName);
    }

    @Override public FieldVisitor visitField(int    accessFlags,
                                             String name,
                                             String desc,
                                             String signature,
                                             Object value) {
        String typeName = this.context.getClassName(Type.getType(desc));

        // Handling synthetic fields
        if (AsmUtil.isSynthetic(accessFlags)) {
            // Skip assertion synthetic field
            if (this.javaVersion >= 14 && "$assertionsDisabled".equals(name)) {
                return null;
            }
            // Skip enum synthetic field (array containing every enum value)
            if (this.classDesc.isEnum() && "$VALUES".equals(name)) {
                return null;
            }
            // Skip synthetic private static final Class<?> fields.
            if (AsmUtil.isPrivateConstant(accessFlags) && name.startsWith("class$") && AsmUtil.isClassClass(typeName)) {
                return null;
            }
        }

        final JavaClassMemberDesc javaField = this.classDesc.addMember(name, JavaClassMemberDesc.Type.FIELD, accessFlags, 0);

        typeName = (signature != null) ? FieldSignatureVisitor.getTypeName(signature, this.context)
                                       : AsmUtil.getSimpleClassName(typeName);

        javaField.setSignature(javaField.getSignature() + ": " + typeName);
        return null;
    }

    @Override public MethodVisitor visitMethod(int      accessFlags,
                                               String   name,
                                               String   desc,
                                               String   signature,
                                               String[] exceptions) {
        final Type[]              argumentTypes = Type.getArgumentTypes(desc);
        final int                 numArguments  = argumentTypes.length;
        final JavaClassMemberDesc javaMethod;

        if (AsmUtil.isStaticInitializer(name)) {
            // Special case of the static initializer of the class
            javaMethod = this.classDesc.addMember(name, JavaClassMemberDesc.Type.SPECIAL, accessFlags, 0);
            javaMethod.setSignature("static class initializer");
        } else {
            // Skip out enum synthetic methods
            if (this.classDesc.isEnum()) {
                // Skip synthetic method "values()" returning an array of enum instances.
                if (AsmUtil.isStatic(accessFlags) && numArguments == 0 && "values".equals(name)) {
                    return null;
                }
                // Skip synthetic method "valueOf(String name)" returning an enum instance.
                if (AsmUtil.isStatic(accessFlags) && numArguments == 1 &&
                    "valueOf".equals(name) && AsmUtil.isStringType(argumentTypes[0])) {
                    return null;
                }
            }

            // Prints out the method signature
            javaMethod = this.classDesc.addMember(name, JavaClassMemberDesc.Type.METHOD, accessFlags, 0);

            this.appendMethodSignature(javaMethod, name, desc, signature, exceptions, argumentTypes);
        }

        return (this.parseCode ? new BinaryMethodParser(javaMethod, this, this.context) : null);
    }

    protected void appendMethodSignature(@NotNull JavaClassMemberDesc javaMethodDesc,
                                         String                       name,
                                         String                       desc,
                                         String                       signature,
                                         String[]                     exceptions,
                                         Type[]                       argumentTypes) {

        MethodSignatureDecoder methodSignatureDecoder = null;
        if (signature != null) {
            methodSignatureDecoder = new MethodSignatureDecoder(null, argumentTypes.length, exceptions, this.context);
            new SignatureReader(signature).accept(methodSignatureDecoder);
        }

        final String returnTypeName;

        if (AsmUtil.isConstructor(name)) {
            returnTypeName = null;
            // Prints out the constructor
            javaMethodDesc.setSignature(this.simpleClassName);
        } else {
            // Prints out the method return type and name
            returnTypeName = (signature == null) ? AsmUtil.getSimpleClassName(this.context.getClassName(Type.getReturnType(desc)))
                                                 : methodSignatureDecoder.getReturnType();
        }

        // Prints out the method argument type list
        final StringBuilder javaMethodSignatureText = this.context.allocateBuilder();
        final int           lastIndex               = argumentTypes.length - 1;

        javaMethodSignatureText.append(javaMethodDesc.getSignature())
                               .append('(');

        for (int i = 0; i <= lastIndex; i++) {
            final boolean isLast = (i == lastIndex);
            String        argumentType;

            // Specific case of the enum constructors (the 2 first parameters are hidden in signature but not in desc)
            if (this.classDesc.isEnum() && AsmUtil.isConstructor(name)) {
                argumentType = (signature == null || i <= 2) ? AsmUtil.getSimpleClassName(this.context.getClassName(argumentTypes[i]))
                                                             : methodSignatureDecoder.getParameterType(i - 2);
            } else {
                argumentType = (signature == null) ? AsmUtil.getSimpleClassName(this.context.getClassName(argumentTypes[i]))
                                                   : methodSignatureDecoder.getParameterType(i);
            }

            // Var-args handling
            if (isLast && javaMethodDesc.isVarArgs() && AsmUtil.isArrayType(argumentType)) {
                argumentType = argumentType.substring(0, argumentType.length() - 2) + "...";
            }

            javaMethodSignatureText.append(argumentType);

            if (!isLast) {
                javaMethodSignatureText.append(", ");
            }
        }
        if (returnTypeName == null) {
            javaMethodSignatureText.append(')');
        } else {
            javaMethodSignatureText.append("): ")
                                   .append(returnTypeName);
        }

        javaMethodDesc.setSignature(javaMethodSignatureText.toString());

        this.context.disposeBuilder(javaMethodSignatureText);
        if (methodSignatureDecoder != null) {
            methodSignatureDecoder.dispose();
        }
    }

    @Override public void visitEnd() {
        this.classDesc.sortMembers();
    }

    @Override public void visitSource    (String source, String debug)                                 {}
    @Override public void visitOuterClass(String owner, String name, String desc)                      {}
    @Override public void visitAttribute (Attribute attr)                                              {}
    @Override public void visitInnerClass(String name, String outerName, String innerName, int access) {}

    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) { return null; }
}