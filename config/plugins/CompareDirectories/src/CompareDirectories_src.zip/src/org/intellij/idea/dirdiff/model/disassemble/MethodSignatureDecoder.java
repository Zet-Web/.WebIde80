/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import com.intellij.openapi.Disposable;
import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.signature.SignatureVisitor;

/**
 *
 */
class MethodSignatureDecoder extends SignatureVisitor implements Disposable {

    private final FullClassVisitor      classVisitor;
    private final MyClassVisitorContext context;
    private       StringBuilder         classBound;
    private final StringBuilder[]       parameterTypes;
    private final StringBuilder         returnType;
    private final StringBuilder[]       exceptionTypes;
    private       int                   parameterIndex;
    private       int                   exceptionIndex;
    private       boolean               unboundedFormalTypeParameter;
    private       boolean               firstFormalTypeParameter;

    public MethodSignatureDecoder(FullClassVisitor classVisitor, int numParameters, String[] exceptions, @NotNull MyClassVisitorContext context) {
        super(Opcodes.ASM4);
        this.context        = context;
        this.classVisitor   = classVisitor;
        this.parameterTypes = createStringBufferArray(classVisitor, context, numParameters, null);
        this.exceptionTypes = createStringBufferArray(classVisitor, context, (exceptions == null) ? 0 : exceptions.length, exceptions);
        this.returnType     = context.allocateBuilder();
    }

    private static StringBuilder[] createStringBufferArray(FullClassVisitor fullClassVisitor, MyClassVisitorContext context, int numBuffers, String[] initialBufferValues) {
        final StringBuilder[] array = new StringBuilder[numBuffers];

        for (int index = 0; index < numBuffers; index++) {
            array[index] = context.allocateBuilder();

            if (initialBufferValues != null) {
                String className = AsmUtil.getQualified(initialBufferValues[index]);

                if (fullClassVisitor != null) {
                    className = fullClassVisitor.ensureClassImported(className);
                }
                array[index].append(className);
            }
        }
        return array;
    }

    public String getParameterType(int index) {
        return this.parameterTypes[index].toString();
    }

    public String getReturnType() {
        return this.returnType.toString();
    }

    public String getExceptionType(int index) {
        return this.exceptionTypes[index].toString();
    }

    @Override public SignatureVisitor visitParameterType() {
        return new FieldSignatureVisitor(this.classVisitor, this.context, false, false, this.parameterTypes[this.parameterIndex++]);
    }

    @Override public SignatureVisitor visitReturnType() {
        return new FieldSignatureVisitor(this.classVisitor, this.context, false, false, this.returnType);
    }

    @Override public SignatureVisitor visitExceptionType() {
        this.exceptionTypes[this.exceptionIndex].setLength(0);
        return new FieldSignatureVisitor(this.classVisitor, this.context, false, false, this.exceptionTypes[this.exceptionIndex++]);
    }

    @Override public void visitFormalTypeParameter(String name) {
        this.firstFormalTypeParameter = (this.classBound == null);

        if (this.firstFormalTypeParameter) {
            this.classBound = this.context.allocateBuilder();
        } else {
            final int classBoundLength = this.classBound.length();

            if (this.classVisitor != null) {
                final Printer classPrinter             = this.classVisitor.getPrinter();
                final int     classPrinterBufferLength = classPrinter.length();

                // If this is not the first formal type parameter, then try to remove the formal type parameters
                // that has already been added to the class printer, then replace the ending '>' by a comma.
                if (classPrinter.endsWith(classPrinterBufferLength - 1, this.classBound)) {
                    classPrinter.truncate(classPrinterBufferLength - classBoundLength - 1);
                }
            }
            this.classBound.replace(classBoundLength - 1, classBoundLength, ", ");
        }
        this.classBound.append(name);
        this.unboundedFormalTypeParameter = false;
    }

    @Override public SignatureVisitor visitClassBound() {
        this.classBound.append(this.unboundedFormalTypeParameter ? ", " : " extends ");
        this.unboundedFormalTypeParameter = true;
        return new FieldSignatureVisitor(this.classVisitor, this.context, true, this.firstFormalTypeParameter, this.classBound);
    }

    @Override public SignatureVisitor visitInterfaceBound() {
        return this.visitClassBound();
    }

    @Override public void visitBaseType           (char   descriptor) {}
    @Override public void visitTypeVariable       (String name)       {}
    @Override public void visitClassType          (String name)       {}
    @Override public void visitInnerClassType     (String name)       {}
    @Override public void visitTypeArgument       ()                  {}
    @Override public void visitEnd                ()                  {}

    @Override public SignatureVisitor visitSuperclass    ()              { return null; }
    @Override public SignatureVisitor visitInterface     ()              { return null; }
    @Override public SignatureVisitor visitArrayType     ()              { return null; }
    @Override public SignatureVisitor visitTypeArgument  (char wildcard) { return null; }

    public void dispose() {
        final MyClassVisitorContext context = this.context;

        if (this.classBound != null) {
            context.disposeBuilder(this.classBound);
        }
        context.disposeBuilder(this.returnType);
        for (StringBuilder builder : this.exceptionTypes) {
            context.disposeBuilder(builder);
        }
        for (StringBuilder builder : this.parameterTypes) {
            context.disposeBuilder(builder);
        }
    }
}
