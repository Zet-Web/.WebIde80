/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import java.io.File;

import javax.swing.JFrame;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.view.HtmlDocumentViewer;
import org.intellij.idea.dirdiff.view.IconUtil;
import org.jetbrains.annotations.NonNls;

import com.intellij.ide.actions.ContextHelpAction;
import com.intellij.ide.plugins.HelpSetPath;
import com.intellij.ide.plugins.IdeaPluginDescriptor;
import com.intellij.ide.plugins.PluginManager;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.application.ApplicationInfo;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.extensions.PluginId;
import com.intellij.openapi.help.HelpManager;

/**
 */
public class HelpAction extends ContextHelpAction {

    private static final String[] PAGE_LIST = {
            "Compare Directories",
            "    Launching 'Compare Directories'",
            "    Panel",
            "    Context menu",
            "    Tools"
        };
    private static final String[] FILE_LIST  = {
            "index.html",
            "launch.html",
            "panel.html",
            "context_menu.html",
            "toolbar.html"
        };

    private static final boolean  IS_IDEA_HELP_OFFLINE;
    private static final String[] PAGE_URL_LIST;

    static {
        boolean isIdeaHelpOffline = false;

        try {
            final String ideaMajorVersion = ApplicationInfo.getInstance().getMajorVersion();
            isIdeaHelpOffline = (Integer.parseInt(ideaMajorVersion) <= 8);
        } catch (NumberFormatException e) {
            // Ignore
        }
        IS_IDEA_HELP_OFFLINE = isIdeaHelpOffline;
        PAGE_URL_LIST        = getPageUrlList(FILE_LIST, getHelpBaseUrl());
    }

    private String actionKey;

    public HelpAction() {}

    public HelpAction(@NonNls final String actionKey) {
        this.actionKey = actionKey;
    }

    @Override public void update(AnActionEvent event) {
        super.update(event);

        final Presentation presentation = event.getPresentation();

        presentation.setText       (CompareDirectoryBundle.message("title." + this.actionKey));
        presentation.setDescription(CompareDirectoryBundle.message("text."  + this.actionKey));
    }

    @Override public void actionPerformed(AnActionEvent event) {
        if (IS_IDEA_HELP_OFFLINE) {
            HelpManager.getInstance().invokeHelp(CompareDirectoryPlugin.COMPARE_DIRECTORY_HELP_ID);
            return;
        }

        // IDEA help is online => Displays the plugin bundled help pages in a dedicated popup window
        final HtmlDocumentViewer helpViewer  = new HtmlDocumentViewer(PAGE_LIST, PAGE_URL_LIST);

        helpViewer.setSize(715, 600);
        helpViewer.setTitle("Compare Directory Plugin Help");
        helpViewer.setIconImage(IconUtil.createIconWithKey("icon.tool-window").getImage());
        helpViewer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        helpViewer.loadNewPage(PAGE_URL_LIST[0]);
        helpViewer.setVisible(true);
    }

    private static String[] getPageUrlList(String[] fileList, String helpBaseUrl) {
        final String[] pageUrlList = new String[fileList.length];

        for (int index = 0; index < fileList.length; index++) {
            pageUrlList[index] = helpBaseUrl + fileList[index];
        }
        return pageUrlList;
    }

    private static String getHelpBaseUrl() {
        final IdeaPluginDescriptor pluginDescriptor = PluginManager.getPlugin(PluginId.getId(CompareDirectoryPlugin.COMPARE_DIRECTORY_PLUGIN_ID));

        if (pluginDescriptor != null) {
            final File          pluginDir    = pluginDescriptor.getPath();
            final HelpSetPath[] helpSetPaths = pluginDescriptor.getHelpSets();

            return "jar:file:///" + Files.normalizeFilePath(pluginDir.getPath()) + "/help/" + helpSetPaths[0].getFile() + "!/";
        }
        return null;
    }
}
