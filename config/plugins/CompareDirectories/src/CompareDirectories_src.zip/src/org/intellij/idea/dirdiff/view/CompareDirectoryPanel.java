/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.ActionPlaces;
import com.intellij.openapi.actionSystem.ActionPopupMenu;
import com.intellij.openapi.actionSystem.ActionToolbar;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataKeys;
import com.intellij.openapi.actionSystem.DataProvider;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.openapi.actionSystem.KeyboardShortcut;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.actionSystem.Shortcut;
import com.intellij.openapi.actionSystem.ShortcutSet;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Disposer;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.ui.AutoScrollFromSourceHandler;
import com.intellij.ui.TreeSpeedSearch;
import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.treeStructure.Tree;
import com.intellij.util.containers.Convertor;
import com.intellij.util.ui.UIUtil;
import com.intellij.util.ui.tree.TreeUtil;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.action.CompareDirectoryToggleAction;
import org.intellij.idea.dirdiff.action.CopyAsAction;
import org.intellij.idea.dirdiff.action.EditSettingsAction;
import org.intellij.idea.dirdiff.action.HelpAction;
import org.intellij.idea.dirdiff.action.PopupMenuAction;
import org.intellij.idea.dirdiff.action.TextFileExportAction;
import org.intellij.idea.dirdiff.actiondelegate.AbstractToggleActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.AutoExcludeHiddenToggleActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CloseComparisonPanelActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CollapseAllActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CollapseAllSubTreeActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CompareLeftRightNodesActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CopyLeftAsRightActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.CopyRightAsLeftActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ExcludeActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ExcludeAllHiddenActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ExpandAllActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ExpandAllSubTreeActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.IncludeActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.MergeNodesActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.OpenDiffActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.OpenLeftActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.OpenRightActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.PerformByteComparisonActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.PerformClassAnalysisActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.RebuildNodeActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.RefreshNodeStateActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.RerunComparisonActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ShowComparisonInfoActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.ShowFilterToggleActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.SplitNodesActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.StopComparisonActionDelegate;
import org.intellij.idea.dirdiff.actiondelegate.SwapLeftRightActionDelegate;
import org.intellij.idea.dirdiff.model.CompareThread;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.ComparisonParameters;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeModel;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryManager;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.Interruptible;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.model.TreeNodeFilter;
import org.intellij.idea.dirdiff.model.TreeNodeFilters;
import org.intellij.idea.dirdiff.util.Commands;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

//import com.intellij.ui.TreeToolTipHandler;

/**
 * A compare-directory panel.
 */
public class CompareDirectoryPanel extends JPanel implements ICompareDirectoryPanel, Disposable {

    @NonNls public  static final String INCLUDE_ACTION_ID    = "DirectoryCompare_IncludeNode";
    @NonNls public  static final String EXCLUDE_ACTION_ID    = "DirectoryCompare_ExcludeNode";

    private final CompareDirectoryAbstractView  view;
    private final MyAutoScrollFromSourceHandler autoScrollFromSourceHandler;
    private final PanelConfiguration            configuration;
    private JTree                               tree;
    private FileTreeModel                       treeModel;
    private CompareDirectoryProgress            progress;
    private CompareThread                       compareThread;
    private ReadableFile                        leftFile;
    private ReadableFile                        rightFile;
    private boolean                             comparisonOver;
    private JPopupMenu                          popupMenu;
    private final ComparisonParameters          parameters;
    private final CompareDirectoryManager       manager;

    public CompareDirectoryPanel(CompareDirectoryAbstractView view,
                                 PanelConfiguration           configuration,
                                 ComparisonParameters         parameters) {
        this.view          = view;
        this.configuration = configuration;
        this.parameters    = parameters;
        this.manager       = new CompareDirectoryManager(view.getProject(), this);

        this.autoScrollFromSourceHandler = new MyAutoScrollFromSourceHandler(this, view.getProject());
        this.autoScrollFromSourceHandler.install();
        Disposer.register(this, this.autoScrollFromSourceHandler);
        this.autoScrollFromSourceHandler.setAutoScrollMode(configuration.isAutoScrollFromSource());

        UI.createUI(this);
    }

    public AutoScrollFromSourceHandler getAutoScrollFromSourceHandler() {
        return this.autoScrollFromSourceHandler;
    }

    public JTree getTree() {
        return this.tree;
    }

    public FileTreeModel getTreeModel() {
        return this.treeModel;
    }

    public PanelConfiguration getConfiguration() {
        return this.configuration;
    }

    public ComparisonParameters getComparisonParameters() {
        return this.parameters;
    }

    public JComponent getComponentToFocus() {
        return this.tree;
    }

    public void refreshTree(final boolean refreshTreeStructureAlso) {
        Commands.invoke(new Runnable() {
                public void run() {
                    CompareDirectoryPanel.this.doRefreshTree(refreshTreeStructureAlso);
                }
            });
    }

    public void addComparisonPanel(ReadableFile leftFile, ReadableFile rightFile, ComparisonParameters parameters) {
        final ToolWindow toolWindow = this.view.getToolWindow();

        if (toolWindow != null) {
            final CompareDirectoryPanel secondPanel = this.view.addPanel(parameters);
            final FileTreeNode          treeRoot    = this.getTreeModel().createRootNode(leftFile, rightFile);

            if (treeRoot != null) {
                secondPanel.setCurrentTree(treeRoot, parameters);
                secondPanel.getView().setLastPanelTitle(treeRoot.getName());

                toolWindow.setAvailable(true, null);
                if (toolWindow.isActive()) {
                    toolWindow.show(this.getView());
                } else {
                    toolWindow.activate(this.getView());
                }
            }
        }
    }

    public void openFile(ComparedTreeNode node, ReadableFile file) {
        this.manager.doOpenFile(this.getView().getProject(), node, file);
    }

    public void openFileDiffs(ComparedTreeNode[] nodes, ReadableFile leftFile, ReadableFile rightFile) {
        this.manager.doOpenFileDiffs(this.getView().getProject(), nodes, leftFile, rightFile);
    }

    private synchronized void doRefreshTree(boolean refreshTreeStructureAlso) {
        try {
            if (refreshTreeStructureAlso) {
                this.treeModel.treeChanged();
            }
            this.tree.updateUI();
        } catch (Throwable t) {
            this.manager.showErrorMessage(CompareDirectoryBundle.message("error.refresh"),
                                          CompareDirectoryBundle.message("error.title"));
            CompareDirectoryPlugin.getLogger().error(t);
        }
    }

    public Thread getCompareThread() {
        return this.compareThread;
    }

    public void refreshProgressBar(int additionalFoundLeft, int additionalFoundRight) {
        if (this.progress.isIndeterminate()) {
            final FileTreeModel model = this.getTreeModel();
            this.progress.setProgressTextArguments(model.getNumLeftFiles()  + additionalFoundLeft,
                                                   model.getNumRightFiles() + additionalFoundRight);
        } else {
            this.progress.setProgressTextArguments(this.progress.getValue(), this.progress.getMaxValue());
        }

        this.progress.updateBar(false);
    }

    public void incrementProgressBar(boolean refresh, boolean forceRefresh) {
        this.progress.incrementValue();
        if (refresh) {
            this.refreshProgressBar(0, 0);
            this.progress.updateBar(forceRefresh);
        }
    }

    public int getProgressBarValue() {
        return this.progress.getValue();
    }

    public void setProgressBarMaximum(final int maxValue, final String messageKey) {
        if (maxValue < 0) {
            this.progress.setIndeterminate(true);
        } else {
            this.progress.setIndeterminate(false);
            this.progress.setMaxValue(maxValue);
        }

        final ProgressIndicator ideaProgressIndicator = ProgressManager.getInstance().getProgressIndicator();

        this.progress.setValueToMinimum();
        this.progress.setProgressText(CompareDirectoryBundle.message(messageKey.concat(".1")));
        if (ideaProgressIndicator != null) {
            ideaProgressIndicator.setText(CompareDirectoryBundle.message(messageKey.concat(".2")));
        }

        this.refreshProgressBar(0, 0);

        this.progress.setVisible(true);
        this.progress.updateBar(true);
    }

    public ReadableFile getLeftFile() {
        return this.leftFile;
    }

    public ReadableFile getRightFile() {
        return this.rightFile;
    }

    public CompareDirectoryAbstractView getView() {
        return this.view;
    }

    public void setCurrentTree(FileTreeNode treeRoot, ComparisonParameters parameters) {
        this.treeModel.setRoot(treeRoot);
        this.tree.setRootVisible(treeRoot != null);
        this.refreshSubTree(treeRoot, true, true, parameters);
    }

    public void refreshSubTree(final FileTreeNode         node,
                               final boolean              rebuildTreeStructure,
                               final boolean              asynchronously,
                               final ComparisonParameters parameters) {
        final ComparedTreeNode treeRoot        = this.treeModel.getRoot();
        final boolean          startComparison = (node != null && treeRoot instanceof FileTreeNode);

        if (node == treeRoot) {
            this.leftFile  = (startComparison ? node.getLeftFile()  : null);
            this.rightFile = (startComparison ? node.getRightFile() : null);
        }

        this.progress.setVisible      (startComparison);
        this.progress.setIndeterminate(startComparison);

        this.comparisonOver = (!startComparison);

        if (startComparison) {
            ApplicationManager.getApplication().executeOnPooledThread(new TreeUpdateThread());

            // TODO a refresh may be requested while the previous comparison isn't over yet!
            this.compareThread = new CompareThread(CompareDirectoryPanel.this, (FileTreeNode) treeRoot, node, rebuildTreeStructure, parameters);
            this.compareThread.addInterruptible(new Interruptible() {
                    public boolean hasBeenInterrupted() {
                        try {
                            ProgressManager.checkCanceled();
                        } catch (ProcessCanceledException e) {
                            return true;
                        }
                        return false;
                    }
                });

            if (asynchronously) {
                final String ideaProgressIndicatorText = CompareDirectoryBundle.message("progress.2");

                new Task.Backgroundable(this.view.getProject(), ideaProgressIndicatorText, true) {
                        public void run(@NotNull ProgressIndicator indicator) {
                            try {
                                indicator.setFraction(0);
                                CompareDirectoryPanel.this.compareThread.run();
                            } finally {
                                indicator.setFraction(1.0);
                                indicator.stop();
                            }
                        }
                    }.setCancelText(CompareDirectoryBundle.message("text.action.stop")).queue();
            } else {
                CompareDirectoryPanel.this.compareThread.run();
            }
        }
    }

    public void recomputeAncestorsState(ComparedTreeNode node) {
        ComparedTreeNode ancestorNode = ((node == null) ? null : node.getParent());
        FileStateEnum    newState     = null;
        FileStateEnum    oldState     = ((ancestorNode == null) ? newState : ancestorNode.getState());

        while (oldState != newState) {
            newState = this.recomputeNodeState(ancestorNode);

            if (oldState != newState) {
                this.autoExcludeNode(ancestorNode);
                ancestorNode = ancestorNode.getParent();
                oldState     = ((ancestorNode == null) ? newState : ancestorNode.getState());
            }
        }
    }

    public FileStateEnum recomputeNodeState(ComparedTreeNode node) {
        final FileStateEnum fileState;

        this.comparisonOver = false;
        fileState = this.compareThread.computeNodeState(node, true);
        this.comparisonOver = true;

        return fileState;
    }

    public void autoExcludeNode(ComparedTreeNode node) {
        if (this.configuration.isAutoExcludeHidden()) {
            final boolean notExcluded = (!node.isExcluded());

            if (notExcluded ^ this.configuration.isVisible(node.getState())) {
                node.setExcluded(notExcluded);
            }
        }
    }

    public void applyFilters(ComparedTreeNode rootNode) {
        final FileTreeModel        model        = this.getTreeModel();
        final List<TreeNodeFilter> filters      = model.getFilters();
        final boolean              hasNoFilters = model.hasNoFilters();

        for (ComparedTreeNode node : rootNode.getDescendentNodes(false, true)) {
            node.setNotFiltered(hasNoFilters || TreeNodeFilters.isNotFiltered(node, filters));
        }
    }

    public void redrawNode(ComparedTreeNode node) {
        try {
            this.getTreeModel().valueForPathChanged(node.getTreePath(), node.getName());
        } catch (Exception e) {
            // Temporary concurrency issue: log and ignore exception (it is just about redrawing)
            CompareDirectoryPlugin.getLogger().error(e);
        }
    }

    public void swapLeftRight() {
        this.treeModel.swapLeftRight();
        this.view.setCurrentPanelTitle(this.treeModel.getRoot().getName());
    }

    public void stopComparison() {
        this.comparisonOver = true;

        this.progress.setIndeterminate(false);
        this.progress.setValueToMaximum();
        this.progress.setVisible(false);
        this.progress.updateBar(true);

        this.treeModel.getRoot().releaseFileLocks();
    }

    public boolean isComparisonOver() {
        return this.comparisonOver;
    }

    public void collapseAllTree() {
        TreeUtil.collapseAll(this.tree, 1);
        this.selectNode((ComparedTreeNode) this.tree.getModel().getRoot());
    }

    public void collapseAllSubTree(@NotNull ComparedTreeNode selectedNode) {
        final TreePath leadSelectionPath = this.tree.getLeadSelectionPath();

        final ComparedTreeNode parentNode = selectedNode.getParent();
        final int          selectedNodeRow;
        final ComparedTreeNode siblingNode;

        if (parentNode == null) {
            selectedNodeRow = 0;
            siblingNode     = null;
        } else {
            selectedNodeRow = this.tree.getRowForPath(selectedNode.getTreePath());
            siblingNode     = this.treeModel.getChild(parentNode, 1 + this.treeModel.getIndexOfChild(parentNode, selectedNode));
        }

        final TreePath  siblingNodePath = (siblingNode == null) ? null : siblingNode.getTreePath();
        int             siblingRow      = (siblingNode == null) ? this.tree.getRowCount()
                                                                : this.tree.getRowForPath(siblingNodePath);

        // Collapse all
        while (siblingRow >= selectedNodeRow) {
            this.tree.collapseRow(siblingRow);
            siblingRow--;
        }

        if (leadSelectionPath != null) {
            this.selectTreePath(leadSelectionPath);
        }
    }

    public void expandAllSubTree(@NotNull ComparedTreeNode selectedNode) {
        final TreePath[] selectionPaths    = this.tree.getSelectionPaths();
        final TreePath   leadSelectionPath = this.tree.getLeadSelectionPath();

        this.expandTree(selectedNode);

        if (selectionPaths != null) {
            this.tree.setSelectionPaths(selectionPaths);
        }
        if (leadSelectionPath != null) {
            this.tree.scrollPathToVisible(leadSelectionPath);
        }
    }

    private void expandTree(@NotNull ComparedTreeNode selectedNode) {
        final ComparedTreeNode parentNode = selectedNode.getParent();
        final int          selectedNodeRow;
        final ComparedTreeNode siblingNode;

        if (parentNode == null) {
            selectedNodeRow = 0;
            siblingNode     = null;
        } else {
            selectedNodeRow = this.tree.getRowForPath(selectedNode.getTreePath());
            siblingNode     = this.treeModel.getChild(parentNode, 1 + this.treeModel.getIndexOfChild(parentNode, selectedNode));
        }

        final TreePath  siblingNodePath = (siblingNode == null) ? null : siblingNode.getTreePath();
        int             prevSiblingRow  = -1;
        int             siblingRow      = (siblingNode == null) ? this.tree.getRowCount()
                                                                : this.tree.getRowForPath(siblingNodePath);

        while (prevSiblingRow != siblingRow) {
            for (int index = selectedNodeRow; index < siblingRow; index++) {
                this.tree.expandRow(index);
            }

            prevSiblingRow = siblingRow;
            siblingRow     = (siblingNode == null) ? this.tree.getRowCount()
                                                   : this.tree.getRowForPath(siblingNodePath);
        }
    }

    public void selectNode(@NotNull ComparedTreeNode node) {
        this.selectTreePath(node.getTreePath());
    }

    private void selectTreePath(@NotNull TreePath treePath) {
        this.tree.expandPath(treePath);
        TreeUtil.selectPath(this.tree, treePath, true);
    }

    private static boolean isTreePathSelected(TreePath nodePath, TreePath[] selectedPaths) {
        if (nodePath != null && selectedPaths != null) {
            final Object lastPathComponent = nodePath.getLastPathComponent();

            for (int index = selectedPaths.length; --index >= 0; ) {
                if (selectedPaths[index].getLastPathComponent() == lastPathComponent) {
                    return true;
                }
            }
        }

        return false;
    }

    public void finalizeIt() {
        // Stops compare thread if still active.
        this.stopComparison();

        // Finalizes nodes.
        this.treeModel.getRoot().finalizeIt();
    }

    public void close() {
        this.view.closeCurrentTabbedPane();
    }

    public void dispose() {
        this.close();
    }

    public ICompareDirectoryManager getManager() {
        return this.manager;
    }

    private static class HelpedTree extends Tree implements DataProvider {
        @Nullable public Object getData(String dataId) {
            return (dataId.equals(DataKeys.HELP_ID.getName()) ? CompareDirectoryPlugin.COMPARE_DIRECTORY_HELP_ID : null);
        }
    }

    private class TreeUpdateThread extends Thread {
        @Override public void run() {
            CompareDirectoryPanel.this.refreshTree(true);
            while (!CompareDirectoryPanel.this.comparisonOver) {
                try {
                    synchronized (this) {
                        this.wait(1500L);
                    }
                } catch (InterruptedException e) {
                    // Ignore.
                }
                CompareDirectoryPanel.this.refreshTree(true);
            }
        }
    }

    private static class UI {
        @NonNls private static final String HELVETICA_FONT_NAME = "Helv";

        private static final Shortcut INCLUDE_ACTION_KEYSTROKE           = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_INSERT,   0), null);
        private static final Shortcut EXCLUDE_ACTION_KEYSTROKE           = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE,   0), null);
        private static final Shortcut EXCLUDE_HIDDEN_ACTION_KEYSTROKE    = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE,   InputEvent.CTRL_DOWN_MASK), null);
        private static final Shortcut RERUN_ACTION_KEYSTROKE             = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_F5,       InputEvent.CTRL_DOWN_MASK), null);
        private static final Shortcut STOP_ACTION_KEYSTROKE              = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_F5,       InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), null);
        private static final Shortcut CLOSE_ACTION_KEYSTROKE             = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_F4,       InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), null);
        private static final Shortcut COLLAPSE_ALL_ACTION_KEYSTROKE      = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_SUBTRACT, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), null);
        private static final Shortcut COLLAPSE_ALL_NODE_ACTION_KEYSTROKE = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_SUBTRACT, InputEvent.CTRL_DOWN_MASK), null);
        private static final Shortcut EXPAND_ALL_ACTION_KEYSTROKE        = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_ADD,      InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK), null);
        private static final Shortcut EXPAND_ALL_NODE_ACTION_KEYSTROKE   = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_ADD,      InputEvent.CTRL_DOWN_MASK), null);
        private static final Shortcut EXPORT_ACTION_KEYSTROKE            = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_O,        InputEvent.ALT_DOWN_MASK),  null);
        private static final Shortcut HELP_ACTION_KEYSTROKE              = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_F1,       0), null);

        private UI() {}

        static void createUI(CompareDirectoryPanel panel) {
            final JLabel       progressLabel = new JLabel(CompareDirectoryBundle.message("progress.parsing.1", 0, 0));
            final JProgressBar progressBar   = new JProgressBar(JProgressBar.HORIZONTAL, 0, 1);

            panel.tree      = new HelpedTree();
            panel.treeModel = new FileTreeModel(panel.getConfiguration());

            progressLabel.setFont(new Font(HELVETICA_FONT_NAME, Font.PLAIN, 9));
            panel.tree.setModel(panel.treeModel);
            panel.tree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
            panel.tree.setRootVisible(false);
            panel.tree.setShowsRootHandles(true);
            new TreeSpeedSearch((Tree) panel.tree, new Convertor<TreePath, String>() {
                    public String convert(TreePath treePath) {
                        return treePath.getLastPathComponent().toString();
                    }
                }, true);
            UIUtil.setLineStyleAngled(panel.tree);
            TreeUtil.installActions(panel.tree);
            panel.tree.expandRow(0);
            panel.tree.setCellRenderer(new FileNodeRenderer());
            panel.tree.addTreeExpansionListener(new TreeAutoExpander());
            panel.tree.addMouseListener(new MouseAdapter(panel));

            panel.popupMenu = getTreeNodePopupMenu(panel).getComponent();

            final JPanel progressPanel = new JPanel(new BorderLayout());
            progressPanel.add(progressBar,   BorderLayout.CENTER);
            progressPanel.add(progressLabel, BorderLayout.EAST);

            panel.setLayout(new BorderLayout());
            panel.add(createButtonToolbar(panel).getComponent(), BorderLayout.NORTH);
            panel.add(new JBScrollPane(panel.tree),              BorderLayout.CENTER);
            panel.add(progressPanel,                             BorderLayout.SOUTH);

            panel.progress = new CompareDirectoryProgress(progressBar, progressPanel, progressLabel);
        }

        private static ActionPopupMenu getTreeNodePopupMenu(CompareDirectoryPanel panel) {
            final ActionManager      actionManager       = ActionManager.getInstance();
            final DefaultActionGroup actionGroup         = new DefaultActionGroup(CompareDirectoryPlugin.ACTION_GROUP_ID, true);
            final DefaultActionGroup mergeActionGroup    = new DefaultActionGroup(CompareDirectoryBundle.message("title.action.node.file-copy"), true);
            final AnAction           collapseAllAction   = new PopupMenuAction(panel, "action.node.collapse-all",   new CollapseAllSubTreeActionDelegate());
            final AnAction           expandAllAction     = new PopupMenuAction(panel, "action.node.expand-all",     new ExpandAllSubTreeActionDelegate());
            final AnAction           includeAction       = new PopupMenuAction(panel, "action.node.include",        new IncludeActionDelegate());
            final AnAction           excludeAction       = new PopupMenuAction(panel, "action.node.exclude",        new ExcludeActionDelegate());
            final AnAction           excludeHiddenAction = new PopupMenuAction(panel, "action.node.exclude-hidden", new ExcludeAllHiddenActionDelegate());

            mergeActionGroup.add(new CopyAsAction(panel, "action.node.copy-as.right", "action.node.delete.right", new CopyLeftAsRightActionDelegate(), true));
            mergeActionGroup.add(new CopyAsAction(panel, "action.node.copy-as.left",  "action.node.delete.left",  new CopyRightAsLeftActionDelegate(), false));

            actionGroup.add(new PopupMenuAction(panel, "action.node.open.diff",          new OpenDiffActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.open.left",          new OpenLeftActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.open.right",         new OpenRightActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.compare.left-right", new CompareLeftRightNodesActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.merge",              new MergeNodesActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.split",              new SplitNodesActionDelegate()));
            actionGroup.add(mergeActionGroup);
            actionGroup.addSeparator();
            actionGroup.add(new PopupMenuAction(panel, "action.node.compare.bytes",      new PerformByteComparisonActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.compare.class",      new PerformClassAnalysisActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.refresh.state",      new RefreshNodeStateActionDelegate()));
            actionGroup.add(new PopupMenuAction(panel, "action.node.rebuild",            new RebuildNodeActionDelegate()));
            actionGroup.addSeparator();
            actionGroup.add(includeAction);
            actionGroup.add(excludeAction);
            actionGroup.add(excludeHiddenAction);
            actionGroup.addSeparator();
            actionGroup.add(expandAllAction);
            actionGroup.add(collapseAllAction);

            // Unregister/re-register the actions to have them get a proper reference to the panel
            registerActionAgain(actionManager, INCLUDE_ACTION_ID, includeAction);
            registerActionAgain(actionManager, EXCLUDE_ACTION_ID, excludeAction);

            // Register key strokes.
            registerActionKeyStroke(panel, expandAllAction,     EXPAND_ALL_NODE_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, collapseAllAction,   COLLAPSE_ALL_NODE_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, includeAction,       INCLUDE_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, excludeAction,       EXCLUDE_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, excludeHiddenAction, EXCLUDE_HIDDEN_ACTION_KEYSTROKE);

            return actionManager.createActionPopupMenu(CompareDirectoryPlugin.ACTION_POPUP_ID, actionGroup);
        }

        private static void registerActionAgain(ActionManager actionManager, String id, AnAction action) {
            if (actionManager.getAction(id) != null) {
                actionManager.unregisterAction(id);
            }
            actionManager.registerAction(id, action);
        }

        private static void registerActionKeyStroke(JComponent                 panel,
                                                    AnAction                   action,
                                                    @NotNull final Shortcut... shortcuts) {
            action.registerCustomShortcutSet(new ShortcutSet() {
                    @NotNull public Shortcut[] getShortcuts() {
                        return shortcuts;
                    }
                }, panel);
        }

        private static ActionToolbar createButtonToolbar(CompareDirectoryPanel panel) {
            final ActionManager      actionManager     = ActionManager.getInstance();
            final DefaultActionGroup actionGroup       = new DefaultActionGroup(CompareDirectoryPlugin.ACTION_GROUP_ID, false);
            final AnAction           rerunAction       = new PopupMenuAction(panel, "action.rerun",        new RerunComparisonActionDelegate());
            final AnAction           stopAction        = new PopupMenuAction(panel, "action.stop",         new StopComparisonActionDelegate());
            final AnAction           closeAction       = new PopupMenuAction(panel, "action.close",        new CloseComparisonPanelActionDelegate());
            final AnAction           collapseAllAction = new PopupMenuAction(panel, "action.collapse-all", new CollapseAllActionDelegate());
            final AnAction           expandAllAction   = new PopupMenuAction(panel, "action.expand-all",   new ExpandAllActionDelegate());
            final AnAction           exportAction      = new TextFileExportAction  ("action.export",       new TextFileExporter(panel));
            final AnAction           helpAction        = new HelpAction            ("action.help");
            final AnAction  autoScrollFromSourceAction = panel.getAutoScrollFromSourceHandler().createToggleAction();

            actionGroup.add(rerunAction);
            actionGroup.add(stopAction);
            actionGroup.add(closeAction);
            actionGroup.addSeparator();
            actionGroup.add(collapseAllAction);
            actionGroup.add(expandAllAction);
            actionGroup.add(new PopupMenuAction(panel, "action.swap", new SwapLeftRightActionDelegate()));
            if (autoScrollFromSourceAction != null) {
                actionGroup.add(autoScrollFromSourceAction);
            }
            actionGroup.addSeparator();
            actionGroup.add(new CompareDirectoryToggleAction(panel, "action.auto-exclude-hidden", new AutoExcludeHiddenToggleActionDelegate()));
            actionGroup.add(new EditSettingsAction(panel, "action.settings"));
            actionGroup.add(createFilterPopupToolbar(panel));
            actionGroup.addSeparator();
            actionGroup.add(new PopupMenuAction(panel, "action.show.info", new ShowComparisonInfoActionDelegate()));
            actionGroup.addSeparator();
            actionGroup.add(exportAction);
            actionGroup.add(helpAction);

            // Register key strokes.
            registerActionKeyStroke(panel, rerunAction,       RERUN_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, stopAction,        STOP_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, closeAction,       CLOSE_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, collapseAllAction, COLLAPSE_ALL_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, expandAllAction,   EXPAND_ALL_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, exportAction,      EXPORT_ACTION_KEYSTROKE);
            registerActionKeyStroke(panel, helpAction,        HELP_ACTION_KEYSTROKE);

            return actionManager.createActionToolbar(ActionPlaces.UNKNOWN, actionGroup, true);
        }

        private static AnAction createFilterPopupToolbar(CompareDirectoryPanel panel) {
            final String             filterPopupToolbarTitle = CompareDirectoryBundle.message("title.action.show.popup");
            final DefaultActionGroup filterActionGroup       = new DefaultActionGroup(filterPopupToolbarTitle, true) {
                public void update(AnActionEvent event) {
                    super.update(event);

                    final Presentation presentation = event.getPresentation();
                    presentation.setDescription(filterPopupToolbarTitle);
                    presentation.setIcon(IconUtil.createIconWithKey("icon.action.show.popup"));
                }
            };

            filterActionGroup.setDefaultIcon(false);

            addFilter(filterActionGroup, panel, "action.show.identical",                 TreeNodeFilters.identical);
            addFilter(filterActionGroup, panel, "action.show.different",                 TreeNodeFilters.different);
            addFilter(filterActionGroup, panel, "action.show.different-blanks",          TreeNodeFilters.differentInBlanks);
            addFilter(filterActionGroup, panel, "action.show.different-non-significant", TreeNodeFilters.differentNonSignificant);
            addFilter(filterActionGroup, panel, "action.show.left-only",                 TreeNodeFilters.leftOnly);
            addFilter(filterActionGroup, panel, "action.show.right-only",                TreeNodeFilters.rightOnly);
            addFilter(filterActionGroup, panel, "action.show.java",                      TreeNodeFilters.javaStructure);

            filterActionGroup.addSeparator();

            addFilter(filterActionGroup, panel, "action.show.most-probably-identical",  TreeNodeFilters.mostProbablyIdentical);
            addFilter(filterActionGroup, panel, "action.show.probably-identical.left",  TreeNodeFilters.probablyIdenticalAndLeftNewer);
            addFilter(filterActionGroup, panel, "action.show.probably-identical.right", TreeNodeFilters.probablyIdenticalAndRightNewer);
            addFilter(filterActionGroup, panel, "action.show.probably-different.left",  TreeNodeFilters.probablyDifferentAndLeftNewer);
            addFilter(filterActionGroup, panel, "action.show.probably-different.right", TreeNodeFilters.probablyDifferentAndRightNewer);

            return new PopupToolbarActionGroup("action.show.popup", filterActionGroup, true);
        }

        private static void addFilter(DefaultActionGroup     actionGroup,
                                      CompareDirectoryPanel  panel,
                                      @NonNls final String   actionKey,
                                      final TreeNodeFilter   filter) {
            if (!(panel.getComparisonParameters().isByteComparison() && filter.checkInitialState())) {
                final AbstractToggleActionDelegate actionDelegate = new ShowFilterToggleActionDelegate(filter);
                final CompareDirectoryToggleAction action         = new CompareDirectoryToggleAction(panel, actionKey, actionDelegate);

                action.getActionDelegate().setSelected(panel.getConfiguration().isFilterVisible(filter), panel);
                actionGroup.add(action);
            }
        }

        private static class MouseAdapter implements MouseListener {
            private final CompareDirectoryPanel panel;

            public MouseAdapter(CompareDirectoryPanel panel) {
                this.panel = panel;
            }

            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    final ComparedTreeNode node    = (ComparedTreeNode) this.panel.tree.getLastSelectedPathComponent();
                    final Project          project = this.panel.view.getProject();

                    if (node != null && project != null) {
                        final ReadableFile leftFile = node.getLeftFile();

                        if (leftFile == node.getRightFile() || node.getState() == FileStateEnum.IDENTICAL ||
                            leftFile.isBinary()) {
                            this.panel.openFile(node, leftFile);
                        } else {
                            this.panel.openFileDiffs(new ComparedTreeNode[] { node, node }, node.getLeftFile(), node.getRightFile());
                        }
                    }
                }
            }

            public void mousePressed(MouseEvent event) {
                if (event.isPopupTrigger() && event.getComponent() == this.panel.tree) {
                    final TreePath selectedLocation = this.panel.tree.getClosestPathForLocation(event.getX(), event.getY());

                    if (!isTreePathSelected(selectedLocation, this.panel.tree.getSelectionPaths())) {
                        this.panel.tree.setSelectionPath(selectedLocation);
                    }
                    this.panel.popupMenu.show(this.panel.tree, event.getX(), event.getY());
                }
            }

            public void mouseReleased(MouseEvent event) {
                this.mousePressed(event);
            }

            public void mouseEntered (MouseEvent event) {}
            public void mouseExited  (MouseEvent event) {}
        }

        private static class TreeAutoExpander implements TreeExpansionListener {
            public void treeExpanded(TreeExpansionEvent event) {
                final ComparedTreeNode expandedNode = (ComparedTreeNode) event.getPath().getLastPathComponent();

                if (expandedNode.getFilteredChildCount() == 1) {
                    final JTree            tree = (JTree) event.getSource();
                    final ComparedTreeNode node = expandedNode.getFilteredChildAt(0);

                    tree.expandPath(event.getPath().pathByAddingChild(node));
                }
            }

            public void treeCollapsed(TreeExpansionEvent event) {}
        }
    }
}
