/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A class allowing depth-first through a tree of nodes.
 * Internal nodes may be ignored ("<tt>leaf-only</tt>"). If not,
 * nodes may be iterated BEFORE or AFTER their sub-nodes
 * ("<tt>childrenBefore</tt>").
 */
class DescendentNodeIterator implements Iterator<ComparedTreeNode> {

    private ComparedTreeNode    localNode;
    private final IntegerStack  childIndexStack;
    private final boolean       noChild;
    private final boolean       leafOnly;
    private final boolean       childrenBefore;

    public DescendentNodeIterator(ComparedTreeNode rootNode,
                                  boolean  leafOnly) {
        this(rootNode, leafOnly, false);
    }

    public DescendentNodeIterator(ComparedTreeNode rootNode,
                                  boolean  leafOnly,
                                  boolean  childrenBefore) {
        this.localNode       = rootNode;
        this.leafOnly        = leafOnly;
        this.noChild         = (!rootNode.hasChildren());
        this.childrenBefore  = (!leafOnly && childrenBefore); // If leafOnly is true, childrenBefore is always false
        this.childIndexStack = new IntegerStack();

        if (childrenBefore) {
            this.findFirstLeaf();
        } else if (leafOnly && rootNode.hasChildren()) {
            this.findNextNode();
        }
    }

    private void findFirstLeaf() {
        assert (this.childrenBefore);

        while (this.localNode.hasChildren()) {
            this.localNode = (ComparedTreeNode) this.localNode.getChildAt(0);
            this.childIndexStack.push(0);
        }
    }

    private void findNextNode() {
        do {
            if (this.localNode.hasChildren() && !this.childrenBefore) {
                this.localNode = (ComparedTreeNode) this.localNode.getChildAt(0);
                this.childIndexStack.push(0);
            } else {
                boolean goUp = false;

                if (!this.childIndexStack.isEmpty()) {
                    do {
                        final ComparedTreeNode localParent = this.localNode.getParent();
                        final int              index       = this.childIndexStack.incrementTop();

                        goUp = (index >= localParent.getChildCount());
                        if (goUp) {
                            this.childIndexStack.pop();
                            this.localNode = localParent;
                        } else {
                            this.localNode = (ComparedTreeNode) localParent.getChildAt(index);
                            if (this.childrenBefore) {
                                this.findFirstLeaf();
                            }
                        }
                    } while (goUp && !(this.childrenBefore || this.childIndexStack.isEmpty()));
                }

                // End of iteration.
                if (this.childIndexStack.isEmpty() && (this.noChild || (goUp ^ this.childrenBefore))) {
                    this.localNode = null;
                }
            }
        } while (this.localNode != null && this.leafOnly && this.localNode.hasChildren());
    }

    public boolean hasNext() {
        return (this.localNode != null);
    }

    public ComparedTreeNode next() {
        final ComparedTreeNode node = this.localNode;

        if (node == null) {
            throw new NoSuchElementException();
        }
        this.findNextNode();
        return node;
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }

    /** An optimized stack of integer numbers. */
    private static class IntegerStack {
        private int[] stack;
        private int   length;

        public IntegerStack() {
            this(10);
        }

        public IntegerStack(int initialSize) {
            this.stack = new int[initialSize];
        }

        public void push(int value) {
            if (this.length == this.stack.length) {
                final int[] newStack = new int[this.length * 3 / 2 + 1];

                System.arraycopy(this.stack, 0, newStack, 0, this.length);
                this.stack = newStack;
            }

            this.stack[this.length++] = value;
        }

        public int peek() {
            this.checkNotEmpty();
            return this.stack[this.length - 1];
        }

        private void checkNotEmpty() {
            if (this.length <= 0) {
                throw new EmptyStackException();
            }
        }

        public int pop() {
            this.checkNotEmpty();
            return this.stack[--this.length];
        }

        public void quickPop(int numValues) {
            this.checkNotEmpty();
            this.length -= numValues;
        }

        public void reset() {
            this.length = 0;
        }

        public void setTop(int value) {
            this.checkNotEmpty();
            this.stack[this.length - 1] = value;
        }

        public int incrementTop() {
            this.checkNotEmpty();
            return ++this.stack[this.length - 1];
        }

        public boolean isEmpty() {
            return (this.length == 0);
        }

        @Override public String toString() {
            if (this.length == 0) {
                return "[]";
            }

            final StringBuilder buf = new StringBuilder();

            buf.append('[')
               .append(this.stack[0]);

            for (int i = 1; i < this.length; i++) {
                buf.append(", ")
                   .append(this.stack[i]);
            }
            return buf.append(']').toString();
        }
    }

    /*********************************************************************/
    /*********************************************************************/
    /***********              U N I T   T E S T S              ***********/
    /*********************************************************************/
    /*********************************************************************/

    @SuppressWarnings({"HardCodedStringLiteral", "UseOfSystemOutOrSystemErr"})
    public static void main(String[] args) {
        final ComparedTreeNode root       = new FileTreeNode("root",     null    );
        final ComparedTreeNode leaf_0     = new FileTreeNode("0-Le",     root    );
        final ComparedTreeNode node_1     = new FileTreeNode("1-No",     root    );
        final ComparedTreeNode node_1_1   = new FileTreeNode("1.1-No",   node_1  );
        final ComparedTreeNode leaf_1_1_1 = new FileTreeNode("1.1.1-Le", node_1_1);
        final ComparedTreeNode leaf_1_1_2 = new FileTreeNode("1.1.2-Le", node_1_1);
        final ComparedTreeNode node_1_2   = new FileTreeNode("1.2-No",   node_1  );
        final ComparedTreeNode leaf_1_2_1 = new FileTreeNode("1.2.1-Le", node_1_2);
        final ComparedTreeNode leaf_1_3   = new FileTreeNode("1.3-Le",   node_1  );
        final ComparedTreeNode node_1_4   = new FileTreeNode("1.4-No",   node_1  );
        final ComparedTreeNode leaf_1_4_1 = new FileTreeNode("1.4.1-Le", node_1_4);
        final ComparedTreeNode leaf_1_4_2 = new FileTreeNode("1.4.2-Le", node_1_4);
        final ComparedTreeNode leaf_1_4_3 = new FileTreeNode("1.4.3-Le", node_1_4);
        final ComparedTreeNode leaf_2     = new FileTreeNode("2-Le",     root    );

        root.addChildNode(leaf_0);
        root.addChildNode(node_1);
        root.addChildNode(leaf_2);
        node_1.addChildNode(node_1_1);
        node_1.addChildNode(node_1_2);
        node_1.addChildNode(leaf_1_3);
        node_1.addChildNode(node_1_4);
        node_1_1.addChildNode(leaf_1_1_1);
        node_1_1.addChildNode(leaf_1_1_2);
        node_1_2.addChildNode(leaf_1_2_1);
        node_1_4.addChildNode(leaf_1_4_1);
        node_1_4.addChildNode(leaf_1_4_2);
        node_1_4.addChildNode(leaf_1_4_3);

        check(root,     false, false, "[root, 0-Le, 1-No, 1.1-No, 1.1.1-Le, 1.1.2-Le, 1.2-No, 1.2.1-Le, 1.3-Le, 1.4-No, 1.4.1-Le, 1.4.2-Le, 1.4.3-Le, 2-Le]");
        check(root,     false, true,  "[0-Le, 1.1.1-Le, 1.1.2-Le, 1.1-No, 1.2.1-Le, 1.2-No, 1.3-Le, 1.4.1-Le, 1.4.2-Le, 1.4.3-Le, 1.4-No, 1-No, 2-Le, root]");
        check(root,     true,  false, "[0-Le, 1.1.1-Le, 1.1.2-Le, 1.2.1-Le, 1.3-Le, 1.4.1-Le, 1.4.2-Le, 1.4.3-Le, 2-Le]");
        check(root,     true,  true,  "[0-Le, 1.1.1-Le, 1.1.2-Le, 1.2.1-Le, 1.3-Le, 1.4.1-Le, 1.4.2-Le, 1.4.3-Le, 2-Le]");
        check(leaf_2,   false, false, "[2-Le]");
        check(leaf_2,   false, true,  "[2-Le]");
        check(leaf_2,   true,  false, "[2-Le]");
        check(leaf_2,   true,  true,  "[2-Le]");
        check(node_1_1, false, false, "[1.1-No, 1.1.1-Le, 1.1.2-Le]");
        check(node_1_1, false, true,  "[1.1.1-Le, 1.1.2-Le, 1.1-No]");
        check(node_1_1, true,  false, "[1.1.1-Le, 1.1.2-Le]");
        check(node_1_1, true,  true,  "[1.1.1-Le, 1.1.2-Le]");
    }

    @SuppressWarnings({"HardCodedStringLiteral", "UseOfSystemOutOrSystemErr"})
    private static void check(ComparedTreeNode node, boolean leafOnly, boolean childrenBefore,
                              String referenceOutput) {
        final String output = getIterationOutput(node, leafOnly, childrenBefore);

        if (output.equals(referenceOutput)) {
            System.out.println('(' + node.getName() + ", " + leafOnly + ", " + childrenBefore + "): OK");
        } else {
            System.out.println('(' + node.getName() + ", " + leafOnly + ", " + childrenBefore + "): FAILED\n --> Output: " +
                               output + "\n --> Refer.: " + referenceOutput);
        }
    }

    private static String getIterationOutput(ComparedTreeNode root, boolean leafOnly, boolean childrenBefore) {
        final StringBuffer buffer = new StringBuffer("[");
        int i = 0;
        for (ComparedTreeNode node : root.getDescendentNodes(leafOnly, childrenBefore)) {
            if (i != 0) { buffer.append(", "); }
            buffer.append(node.getName());

            i++;
            // Prevent for-ever loop, which might be due to a bug in iteration algorithm (undetected yet)
            if (i > 200) { return buffer.toString(); }
        }
        return buffer.append(']').toString();
    }
}
