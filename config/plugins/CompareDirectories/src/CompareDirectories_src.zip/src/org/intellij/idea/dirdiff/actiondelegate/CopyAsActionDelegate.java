/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.swing.JOptionPane;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.util.Util;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Ancestor class for {@link CopyLeftAsRightActionDelegate} and {@link CopyRightAsLeftActionDelegate}
 */
public abstract class CopyAsActionDelegate extends AbstractActionDelegate {

    protected static boolean isEnabled(@Nullable ComparedTreeNode[] selectedNodes, boolean isLeftToRight) {
        if (selectedNodes != null) {
            for (final ComparedTreeNode selectedNode : selectedNodes) {
                if (selectedNode != null &&
                    (!(selectedNode instanceof FileTreeNode) ||
                     ((FileTreeNode) selectedNode).getOtherSideFile(isLeftToRight).isInCompressedFile())) {
                    return false;
                }
            }
        }

        return true;
    }

    protected static void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes, boolean isLeftToRight) {
        if (panel != null && selectedNodes != null) {
            final FileTreeNode[] selectedFileNodes = Util.ensureArrayType(selectedNodes, FileTreeNode.class);

            if (selectedFileNodes != null && isCopyConfirmed(panel, selectedFileNodes, isLeftToRight)) {
                final boolean      deleteTargetSideFiles = isTargetSideFileDeletionConfirmed(panel, selectedFileNodes, isLeftToRight);
                int                progressBarMaxValue   = 0;

                for (final ComparedTreeNode selectedNode : selectedNodes) {
                    progressBarMaxValue += selectedNode.getNumDescendentNodes();
                }
                panel.setProgressBarMaximum(progressBarMaxValue, "progress.copy");

                panel.getManager().execute(new CopyThread(panel, selectedFileNodes, isLeftToRight, deleteTargetSideFiles), true);
            }
        }
    }

    /**
     * If the nodes are neither left-side nor right-side, asks for a user confirmation
     * and returns it; otherwise always return <tt>true</tt>.
     *
     * @param panel         the comparison panel
     * @param selectedNodes the nodes, whose one file should be copied
     * @param isLeftToRight <tt>true</tt>  if the left- side file is to be copied to the right side;
     *                      <tt>false</tt> if the right-side file is to be copied to the left side
     * @return <tt>false</tt> if a confirmation has been asked and the user has answered NO;
     *         <tt>true</tt> otherwise.
     */
    private static boolean isCopyConfirmed(@NotNull ICompareDirectoryPanel panel,
                                           @NotNull FileTreeNode[]         selectedNodes,
                                           boolean                         isLeftToRight) {
        final FileStateEnum sourceState     = (isLeftToRight ? FileStateEnum.LEFT_ONLY  : FileStateEnum.RIGHT_ONLY);
        final FileStateEnum targetState     = (isLeftToRight ? FileStateEnum.RIGHT_ONLY : FileStateEnum.LEFT_ONLY);
        boolean             toBeConfirmed   = false;
        boolean             onlyTargetFiles = true;

        for (final FileTreeNode selectedNode : selectedNodes) {
            if (selectedNode != null) {
                final FileStateEnum state = selectedNode.getState();
                if (state != sourceState) {
                    toBeConfirmed = true;
                }
                if (state != targetState) {
                    onlyTargetFiles = false;
                }
            }
        }

        // If state is neither left-only nor right-only, ask for user confirmation
        // before actually doing the copy
        if (toBeConfirmed && selectedNodes.length > 0) {
            final ReadableFile   firstLeftFile = selectedNodes[0].getLeftFile();
            final boolean        plural        = (selectedNodes.length > 1 || firstLeftFile.isDirectory() ||
                                                  firstLeftFile.isCompressedFile());
            @NonNls final String titleKey      = "title.action.confirm." + (onlyTargetFiles ? "deletion" : "copy-as");
            @NonNls final String message;

            final FileTreeNode rootNode = (FileTreeNode) selectedNodes[0].getModel().getRoot();

            if (onlyTargetFiles) {
                final ReadableFile rootSideFile = (isLeftToRight ? rootNode.getRightFile() : rootNode.getLeftFile());

                message = CompareDirectoryBundle.message("text.action.confirm.deletion." + (isLeftToRight ? "right" : "left"),
                                                         rootSideFile.getPath());
            } else {
                message = CompareDirectoryBundle.message("text.action.confirm.copy-as." + (isLeftToRight ? "right." : "left.") + (plural ? 'n' : '1'),
                                                         rootNode.getLeftFile().getPath(), rootNode.getRightFile().getPath());
            }

            return panel.getManager().doesUserConfirm(message, CompareDirectoryBundle.message(titleKey));
        }

        return true;
    }

    /**
     * If there are some target-side file nodes and copy is confirmed, asks for a user confirmation
     * of their deletion and returns it; otherwise always return <tt>true</tt>.
     *
     * @param panel         the comparison panel
     * @param selectedNodes the nodes, whose one file should be copied
     * @param isLeftToRight <tt>true</tt>  if the left- side file is to be copied to the right side;
     *                      <tt>false</tt> if the right-side file is to be copied to the left side
     * @return <tt>false</tt> if a confirmation has been asked and the user has answered NO;
     *         <tt>true</tt> otherwise.
     */
    private static boolean isTargetSideFileDeletionConfirmed(@NotNull ICompareDirectoryPanel panel,
                                                             @NotNull FileTreeNode[]         selectedNodes,
                                                             boolean                         isLeftToRight) {
        final FileStateEnum            targetSideFileState    = (isLeftToRight ? FileStateEnum.RIGHT_ONLY : FileStateEnum.LEFT_ONLY);
        boolean                        isThereTargetSideFiles = false;
        boolean                        onlyTargetSideFiles    = true;
        final Collection<FileTreeNode> processedNodes         = new ArrayList<FileTreeNode>(selectedNodes.length);

        for (final FileTreeNode selectedNode : selectedNodes) {
            if (isNotYetProcessed(processedNodes, selectedNode)) {
                if (isTargetSideFileNode(selectedNode, targetSideFileState)) {
                    isThereTargetSideFiles = true;
                } else {
                    onlyTargetSideFiles = false;
                }
            }

            processedNodes.add(selectedNode);
        }

        // If state is neither left-only nor right-only, ask for user confirmation
        // before actually doing the copy
        if (isThereTargetSideFiles && !onlyTargetSideFiles && selectedNodes.length > 0) {
            @NonNls final String titleKey   = "title.action.confirm.copy-as.del";
            @NonNls final String messageKey = "text.action.confirm.copy-as." +
                                              (isLeftToRight ? "right" : "left") + ".del";
            final FileTreeNode rootNode     = (FileTreeNode) selectedNodes[0].getModel().getRoot();
            final ReadableFile rootSideFile = (isLeftToRight ? rootNode.getRightFile() : rootNode.getLeftFile());

            return panel.getManager().doesUserConfirm(CompareDirectoryBundle.message(messageKey, rootSideFile.getPath()),
                                                      CompareDirectoryBundle.message(titleKey));
        }

        return true;
    }

    /**
     * Returns <tt>true</tt> if this node and all its children nodes are
     * target-side only nodes, or <tt>false</tt> otherwise.
     *
     * @param node                 a node
     * @param targetSideFileState  the file state of a target-side only node
     * @return   <tt>true</tt> if this node or some of its children nodes are
     *           target-side only nodes, or <tt>false</tt> otherwise.
     */
    private static boolean isTargetSideFileNode(@Nullable FileTreeNode  node,
                                                @NotNull  FileStateEnum targetSideFileState) {
        if (node == null) {
            return false;
        }
        for (ComparedTreeNode treeNode : node.getDescendentLeaves()) {
            if (treeNode.getState() != targetSideFileState) {
                return false;
            }
        }
        return true;
    }

    private static boolean isNotYetProcessed(Iterable<FileTreeNode> nodeList,
                                             ComparedTreeNode       selectedNode) {
        for (ComparedTreeNode node : nodeList) {
            if (node.isSelfOrAncestor(selectedNode)) {
                return false;
            }
        }
        return true;
    }

    private static class ConfirmationInfo {
        public boolean alreadyAsked;
        public boolean confirmed;
    }

    private static class CopyStatus {
        public final ConfirmationInfo writeOverReadOnlyFile;
        public final ConfirmationInfo makeReadOnlyDirectoryWritable;
        public final ConfirmationInfo copyIgnoredFile;
        public boolean                writeOverReadOnlyFileError;
        public boolean                deletionError;

        public CopyStatus() {
            this.writeOverReadOnlyFile         = new ConfirmationInfo();
            this.makeReadOnlyDirectoryWritable = new ConfirmationInfo();
            this.copyIgnoredFile               = new ConfirmationInfo();
        }
    }

    private static class CopyThread implements Runnable {
        private final ICompareDirectoryPanel panel;
        private final FileTreeNode[]         selectedNodes;
        private final boolean                isLeftToRight;
        private final boolean                deleteTargetSideFiles;

        /** the list of nodes to be deleted after the file copy if
         *  target-side-only files are to be deleted. */
        private final List<FileTreeNode>     toBeDeletedNodes;

        /**
         * Creates a new separate thread for copying files.
         *
         * @param panel          the panel containing the progress bar.
         * @param selectedNodes  the nodes, whose one file should be copied
         * @param isLeftToRight  if <tt>true</tt>, copies the left-side file to the right side;
         *                       if <tt>false</tt>, copies the right-side file to the left side
         * @param deleteTargetSideFiles
         *                       if <tt>true</tt>, delete target-side-only files while copying.
         */
        public CopyThread(ICompareDirectoryPanel panel,
                          FileTreeNode[]         selectedNodes,
                          boolean                isLeftToRight,
                          boolean                deleteTargetSideFiles) {
            this.panel                 = panel;
            this.selectedNodes         = selectedNodes;
            this.isLeftToRight         = isLeftToRight;
            this.deleteTargetSideFiles = deleteTargetSideFiles;
            this.toBeDeletedNodes      = new ArrayList<FileTreeNode>();
        }

        public void run() {
            final CopyStatus copyStatus = new CopyStatus();

            try {
                synchronized (Files.COPY_BUFFER) {
                    for (final FileTreeNode selectedNode : this.selectedNodes) {
                        if (this.doCopyLeftRightFile(selectedNode, copyStatus)) {
                            for (int index = this.toBeDeletedNodes.size(); --index >= 0; ) {
                                final FileTreeNode node = this.toBeDeletedNodes.get(index);

                                if (!node.getLeftFile().getRealFile().delete()) {
                                    copyStatus.deletionError = true;
                                } else {
                                    node.getParent().remove(node);
                                }
                            }

                            this.toBeDeletedNodes.clear();
                            if (this.panel.getComparisonParameters().isByteComparison()) {
                                this.panel.recomputeAncestorsState(selectedNode);
                            }
                        }
                    }
                }
            } catch (Throwable t) {
                CompareDirectoryPlugin.getLogger().error(t);
                copyStatus.writeOverReadOnlyFileError = true;
            }

            if (copyStatus.deletionError || copyStatus.writeOverReadOnlyFileError) {
                final String message = (copyStatus.deletionError ? "error.copy-delete"
                                                                 : "error.copy-no-write");
                this.panel.getManager().showErrorMessage(CompareDirectoryBundle.message(message),
                                                         CompareDirectoryBundle.message("error.title"));
            }

            this.panel.stopComparison();
            this.panel.refreshTree(true);
        }

        /**
         * Copies the file of a side-only node to the other side.
         * @param node           the node, whose one file should be copied
         * @param copyStatus the user confirmation information
         * @return <tt>true</tt> if the copy was completed successfully, <tt>false</tt> otherwise.
         */
        private boolean doCopyLeftRightFile(FileTreeNode node, CopyStatus copyStatus) {
            final ReadableFile source          = node.getSideFile     (this.isLeftToRight);
            final ReadableFile target          = node.getOtherSideFile(this.isLeftToRight);
            final boolean      doesSourceExist = source.getRealFile().exists();
            final File         targetRealFile  = target.getRealFile();

            this.panel.incrementProgressBar(true, false);

            try {
                if (!node.isIgnored() || this.getConfirmation(copyStatus.copyIgnoredFile, source,
                              "action.confirm.copy.ignored") == JOptionPane.YES_OPTION) {

                    if (source.isDirectory() || (!doesSourceExist && target.isDirectory())) {
                        if (!(targetRealFile.exists() || targetRealFile.mkdirs())) {
                            throw new IOException(CompareDirectoryBundle.message("error.copy-dir", targetRealFile.getPath()));
                        }

                        if (!doesSourceExist && this.deleteTargetSideFiles) {
                            this.toBeDeletedNodes.add(node);
                        }

                        final Iterable<ComparedTreeNode> children = node.getChildren();

                        if (children != null) {
                            for (Object childNode : children) {
                                if (childNode instanceof FileTreeNode &&
                                    !this.doCopyLeftRightFile((FileTreeNode) childNode, copyStatus)) {
                                    return false;
                                }
                            }
                        }
                        node.setState(FileStateEnum.IDENTICAL);
                    } else {
                        final FileTreeNode parentNode       = (FileTreeNode) node.getParent();
                        final ReadableFile sourceParentFile = parentNode.getSideFile     (this.isLeftToRight);
                        final ReadableFile targetParentFile = parentNode.getOtherSideFile(this.isLeftToRight);

                        if (sourceParentFile != null && targetParentFile != null) {
                            if (doesSourceExist) {
                                final File targetParentRealFile = targetParentFile.getRealFile();

                                // If the target directory does not exist and cannot be created, throws an error
                                if (!(targetParentRealFile.exists() || targetParentRealFile.mkdirs())) {
                                    throw new IOException(CompareDirectoryBundle.message("error.copy-dir", targetParentRealFile.getPath()));
                                }

                                // If the target parent is a read-only system directory, asks a user confirmation
                                // If it does (or already did), makes the directory writable.
                                if (this.isFileUnableToBeMadeWritable(copyStatus, targetParentFile, targetParentRealFile)) {
                                    return false;
                                }

                                // If the target is a read-only system file, asks a user confirmation
                                // If it does (or already did), makes the file writable.
                                if (target instanceof File && targetRealFile.exists() &&
                                    this.isFileUnableToBeMadeWritable(copyStatus, target, targetRealFile)) {
                                    return false;
                                }

                                // If the file is writable, makes the copy.
                                final boolean isCopiable = (targetRealFile.exists() ? targetRealFile      .canWrite()
                                                                                    : targetParentRealFile.canWrite());

                                if (isCopiable) {
                                    Files.copyFile(source, targetRealFile);
                                    this.panel.getManager().refreshNode(node, false, true);
                                    node.setState(FileStateEnum.IDENTICAL);
                                } else {
                                    copyStatus.writeOverReadOnlyFileError = true;
                                }
                            } else if (this.deleteTargetSideFiles) {
                                this.toBeDeletedNodes.add(node);
                            }
                        }
                    }
                }

                return true;
            } catch (IOException e) {
                this.panel.getManager().showErrorMessage(CompareDirectoryBundle.message("error.copy"),
                                                         CompareDirectoryBundle.message("error.title"));
                CompareDirectoryPlugin.getLogger().error(e);
                return false;
            }
        }

        /**
         * Returns <tt>true</tt> if the file is read-only and the user refuses to write it over
         * (or already has), <tt>false</tt> otherwise.
         * @param copyStatus the user confirmation information
         * @param target         the side file to be written over
         * @param targetRealFile the system file to be written over
         * @return <tt>true</tt> if the file is read-only and the user refuses to write it over
         *         (or already has), <tt>false</tt> otherwise.
         */
        private boolean isFileUnableToBeMadeWritable(CopyStatus copyStatus, ReadableFile target, File targetRealFile) {
            if (!targetRealFile.canWrite()) {
                final ConfirmationInfo confirmation = (target.isDirectory() ? copyStatus.makeReadOnlyDirectoryWritable
                                                                            : copyStatus.writeOverReadOnlyFile);
                @NonNls final String   messageKey   = "action.confirm.copy.read-only." +
                                                      (target.isDirectory() ? "dir" : "file");
                final int              choice       = this.getConfirmation(confirmation, target, messageKey);

                if (choice == JOptionPane.YES_OPTION) {
                    ((File) target).setWritable(true);
                } else if (choice == JOptionPane.CANCEL_OPTION) {
                    return true;
                }
            }
            return false;
        }

        /**
         * Returns the confirmation response the user made of a question
         * @param confirmation   the user confirmation info
         * @param file           the readable file the confirmation is about
         * @param messageKeyBase the message key of the dialog box without the ".left" or ".right" end
         * @return either JOptionPane.YES_OPTION, JOptionPane.NO_OPTION or JOptionPane.CANCEL_OPTION
         */
        private int getConfirmation(ConfirmationInfo confirmation,
                                    ReadableFile     file,
                                    @NonNls String   messageKeyBase) {
            if (confirmation.alreadyAsked) {
                return (confirmation.confirmed ? JOptionPane.YES_OPTION
                                               : JOptionPane.NO_OPTION);
            }

            @NonNls final String titleKey   = "title." + messageKeyBase;
            @NonNls final String messageKey = "text." + messageKeyBase + (this.isLeftToRight ? ".left" : ".right");

            int choice = this.panel.getManager().doesUserConfirm2(CompareDirectoryBundle.message(messageKey, file.getPath()),
                                                                  CompareDirectoryBundle.message(titleKey));

            if (choice == 1 || choice == 3) { // YES_TO_ALL or NO_TO_ALL
                confirmation.alreadyAsked = true;
                confirmation.confirmed    = (choice == 1);
                choice--;  // YES_TO_ALL becomes YES; NO_TO_ALL becomes NO
            }

            return (choice >> 1);
        }
    }
}