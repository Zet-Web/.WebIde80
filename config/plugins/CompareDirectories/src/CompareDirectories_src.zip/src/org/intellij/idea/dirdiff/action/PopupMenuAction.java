/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTree;
import javax.swing.tree.TreePath;

import org.intellij.idea.dirdiff.actiondelegate.AbstractActionDelegate;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataKeys;
import com.intellij.openapi.actionSystem.Presentation;

/**
 * Action shown in a pop-up menu, whose real work is delegated.
 */
public class PopupMenuAction extends AbstractCompareDirectoryAction {

    protected final AbstractActionDelegate delegate;

    public PopupMenuAction() {
        this.delegate = new AbstractActionDelegate() {
            public void apply(ICompareDirectoryPanel panel, ComparedTreeNode[] selectedNodes) {}
        };
    }

    public PopupMenuAction(final CompareDirectoryPanel  panel,
                           @NonNls final String         actionKey,
                           final AbstractActionDelegate actionDelegate) {
        super(panel, actionKey);
        this.delegate = actionDelegate;
    }

    @Override public void update(AnActionEvent event) {
        final Presentation          presentation  = event.getPresentation();
        final CompareDirectoryPanel panel         = this.getPanel(event);
        final ComparedTreeNode[]    selectedNodes = getSelectedNodes(event);
        final boolean               visible       = this.delegate.isVisible(panel, selectedNodes);

        if (visible) {
            presentation.setVisible(true);
            presentation.setEnabled(this.delegate.isEnabled(panel, selectedNodes));
        } else {
            presentation.setVisible(false);
        }
    }

    @Override public void actionPerformed(AnActionEvent event) {
        this.delegate.apply(this.getPanel(event), getSelectedNodes(event));
    }

    @Nullable protected static JTree getContextTree(AnActionEvent event) {
        final Object contextComponent = DataKeys.CONTEXT_COMPONENT.getData(event.getDataContext());

        return (contextComponent == null || !(contextComponent instanceof JTree))
                    ? null
                    : (JTree) contextComponent;
    }

    @Nullable protected static ComparedTreeNode getClickedNode(AnActionEvent event) {
        final JTree  contextTree       = getContextTree(event);
        final Object lastPathComponent = (contextTree == null) ? null : contextTree.getLastSelectedPathComponent();

        return (lastPathComponent instanceof ComparedTreeNode) ? (ComparedTreeNode) lastPathComponent : null;
    }

    protected static int getNumSelectedNodes(AnActionEvent event) {
        final JTree contextTree = getContextTree(event);

        return (contextTree == null) ? 0 : contextTree.getSelectionPaths().length;
    }

    @Nullable protected static TreePath[] getSelectedTreePaths(AnActionEvent event) {
        final JTree contextTree = getContextTree(event);

        return (contextTree == null) ? null : contextTree.getSelectionPaths();
    }

    @NotNull protected static ComparedTreeNode[] getSelectedNodes(AnActionEvent event) {
        final TreePath[] selectionPaths = getSelectedTreePaths(event);

        if (selectionPaths == null || selectionPaths.length == 0) {
            return new ComparedTreeNode[0];
        }

        final List<ComparedTreeNode> selectedNodes  = new ArrayList<ComparedTreeNode>(selectionPaths.length);

        for (final TreePath path : selectionPaths) {
            final Object lastPathComponent = path.getLastPathComponent();

            if (lastPathComponent instanceof ComparedTreeNode) {
                selectedNodes.add((ComparedTreeNode) lastPathComponent);
            }
        }

        return selectedNodes.toArray(new ComparedTreeNode[selectedNodes.size()]);
    }
}
