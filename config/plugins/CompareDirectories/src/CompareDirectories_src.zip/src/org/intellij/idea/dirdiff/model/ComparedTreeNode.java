/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 */
public abstract class ComparedTreeNode extends DefaultMutableTreeNode implements Finalizable {

    protected FileStateEnum state;
    private   FileTreeModel model;
    private   boolean       excluded;
    private   boolean       notFiltered;

    /**
     * Private wrapper constructor to be called when a constructor is to call super().
     * Defined for factorization purpose.
     * @param name   the node name
     * @param parent the node parent
     * @param state  the node state
     */
    private ComparedTreeNode(Object name, MutableTreeNode parent, FileStateEnum state) {
        super(name);
        this.parent      = parent;
        this.state       = state;
        this.notFiltered = true;
    }

    /**
     * Creates a new tree node.
     * @param name   the node name
     * @param parent the node parent
     * @param model  the tree model
     * @param state  the state of this node.
     */
    protected ComparedTreeNode(String name, ComparedTreeNode parent, FileTreeModel model, FileStateEnum state) {
        this(name, parent, state);
        this.model       = model;
        this.notFiltered = (parent == null || TreeNodeFilters.isNotFiltered(this, model.getFilters()));
    }

    /**
     * Constructor used for unit test purpose only
     * @param name the node name
     * @param parent the node parent
     */
    ComparedTreeNode(String name, ComparedTreeNode parent) {
        this(name, parent, FileStateEnum.IDENTICAL);
    }

    public final boolean isSelfOrAncestor(ComparedTreeNode descendentNode) {
        ComparedTreeNode node = descendentNode;

        while (node != null) {
            if (node == this) {
                return true;
            }

            node = node.getParent();
        }

        return false;
    }

    @SuppressWarnings({"TypeMayBeWeakened"})
    @Nullable public final <T extends ComparedTreeNode> T getSelfOrAncestor(@NotNull Class<T> nodeClass) {
        ComparedTreeNode node = this;

        while (node != null) {
            if (node.getClass().equals(nodeClass)) {
                return (T) node;
            }

            node = node.getParent();
        }

        return null;
    }

    @Override public final ComparedTreeNode getParent() {
        return (ComparedTreeNode) this.parent;
    }

    public final FileTreeModel getModel() {
        return this.model;
    }

    public final String getName() {
        return (String) this.userObject;
    }

    public abstract ReadableFile getLeftFile();
    public abstract ReadableFile getRightFile();

    public final void setState(FileStateEnum state) {
        this.state       = state;
        this.notFiltered = (this.parent == null || TreeNodeFilters.isNotFiltered(this, this.model.getFilters()));
    }

    @SuppressWarnings({ "ConditionalExpressionWithNegatedCondition" })
    @NotNull public final FileStateEnum getState() {
        return (this.state != FileStateEnum.DIFFERENT_IN_COMMENTS  ? this.state :
                this.getModel().areDiffsInCommentsNonSignificant() ? FileStateEnum.DIFFERENT_NON_SIGNIFICANT
                                                                   : FileStateEnum.DIFFERENT);
    }

    @NotNull public abstract FileStateEnum computeState(Interruptible interruptible);

    public abstract boolean isIgnored();

    public final boolean isExcluded() {
        return this.excluded;
    }

    public final void setExcluded(boolean excluded) {
        this.setExcludedRecursively(excluded);
        if (this.parent != null) {
            ((ComparedTreeNode) this.parent).setExclusion();
        }
    }

    private void setExcludedRecursively(boolean excluded) {
        this.excluded = excluded;
        this.model.nodeChanged(this);

        for (int index = this.getChildCount(); --index >= 0; ) {
            ((ComparedTreeNode) this.children.get(index)).setExcludedRecursively(excluded);
        }
    }

    private void setExclusion() {
        boolean excluded = true;

        for (int index = this.getChildCount(); --index >= 0; ) {
            final ComparedTreeNode childNode = (ComparedTreeNode) this.children.get(index);

            if (!(childNode.isIgnored() || childNode.excluded)) {
                excluded = false;
                break;
            }
        }

        if (this.excluded != excluded) {
            this.excluded = excluded;
            this.model.nodeChanged(this);
            if (this.parent != null) {
                ((ComparedTreeNode) this.parent).setExclusion();
            }
        }
    }

    public final TreePath getTreePath() {
        return new TreePath(this.getPath());
    }

    @SuppressWarnings({"UseOfObsoleteCollectionType"})
    public final void initChildren(int numChildren) {
        this.children = new Vector(numChildren, 2);
    }

    @SuppressWarnings({"NonPrivateFieldAccessedInSynchronizedContext"})
    public final void appendChildNode(ComparedTreeNode child) {
        this.addChildNode(child, null, null);
    }

    @SuppressWarnings({"NonPrivateFieldAccessedInSynchronizedContext"})
    public final void addChildNode(ComparedTreeNode child) {
        if (child != null) {
            this.addChildNode(child, child.getName(), FileTreeModel.childNameComparator);
        }
    }

    protected final void addChildNode(ComparedTreeNode child, Object key, Comparator comparator) {
        if (child != null) {
            synchronized (this) {
                if (this.children == null) {
                    this.initChildren(2);
                }

                if (comparator == null) {
                    this.children.add(child);
                } else {
                    final int index = this.indexOf(key, comparator);

                    if (index < 0) {
                        this.children.add(-(index + 1), child);
                    }
                }
            }
        }
    }

    @SuppressWarnings({"unchecked"})
    @Nullable public final Iterable<ComparedTreeNode> getChildren() {
        return this.children;
    }

    @SuppressWarnings({"unchecked"})
    @NotNull public final Iterable<ComparedTreeNode> getFilteredChildren() {
        return new Iterable<ComparedTreeNode>() {
                @SuppressWarnings({"unchecked"})
                public Iterator<ComparedTreeNode> iterator() {
                    return new TreeNodeFilteringIterator(ComparedTreeNode.this.children);
                }
            };
    }

    public abstract FileStateEnum updateInitialState();

    public abstract ComparedTreeNode mergeWithNode(ComparedTreeNode rightNode);

    public abstract boolean isMerged();

    public abstract ComparedTreeNode[] split();

    protected ComparedTreeNode split(ComparedTreeNode parentNode) {
        // Remove node from merge node list in model if marked as merged
        // (prevent from future errors while reapplying node merging).
        if (this.isMerged()) {
            this.model.removeMergedNode(this);
        }

        if (this.state.isSideOnly()) {
            // There is nothing to do about LEFT_ONLY nodes.
            // RIGHT_ONLY nodes shall simply be moved to the other parent node.
            if (this.state == FileStateEnum.RIGHT_ONLY) {
                this.parent.remove(this);
                parentNode.addChildNode(this);
                this.parent      = parentNode;
                this.notFiltered = TreeNodeFilters.isNotFiltered(this, this.getModel().getFilters());
            }

            this.splitChildrenNodes(parentNode);
            return this;
        }
        return null;
    }

    /**
     * Split child nodes.
     * @param parentNode
     */
    protected final void splitChildrenNodes(ComparedTreeNode parentNode) {
        final Iterable<ComparedTreeNode> children = this.getChildren();

        if (children != null) {
            // Iterate on a copy of the collection of children to prevent from
            // a concurrent modification error while iterating
            for (ComparedTreeNode child : new ArrayList<ComparedTreeNode>((Collection<ComparedTreeNode>) children)) {
                child.split(parentNode);
            }
        }
    }

    public final int getNumDescendentNodes() {
        final int numChildren = this.getChildCount();
        int       count       = 1;

        for (int index = 0; index < numChildren; index++) {
            final ComparedTreeNode childNode = (ComparedTreeNode) this.getChildAt(index);

            count += childNode.getNumDescendentNodes();
        }
        return count;
    }

    @NotNull public final Iterable<ComparedTreeNode> getDescendentNodes() {
        return this.getDescendentNodes(false, true);
    }

    @NotNull public final Iterable<ComparedTreeNode> getDescendentLeaves() {
        return this.getDescendentNodes(true, false);
    }

    @NotNull public Iterable<ComparedTreeNode> getDescendentNodes(final boolean leafOnly, final boolean childrenBefore) {
        return new Iterable<ComparedTreeNode>() {
            public Iterator<ComparedTreeNode> iterator() {
                return new DescendentNodeIterator(ComparedTreeNode.this, leafOnly, childrenBefore);
            }
        };
    }

    public final void getStatistics(TreeStatistics statistics) {
        final int numChildren = this.getChildCount();

        statistics.addNode(this);
        for (int index = 0; index < numChildren; index++) {
            ((ComparedTreeNode) this.children.get(index)).getStatistics(statistics);
        }
    }

    public final boolean hasChildren() {
        return (this.children != null && !this.children.isEmpty());
    }

    public void releaseFileLocks() {
        this.releaseChildrenFileLocks();
    }

    public abstract void finalizeIt();

    public final void releaseChildrenFileLocks() {
        for (int index = this.getChildCount(); --index >= 0; ) {
            ((ComparedTreeNode) this.getChildAt(index)).releaseFileLocks();
        }
    }

    final void closeChildrenFiles() {
        for (int index = this.getChildCount(); --index >= 0; ) {
            ((Finalizable) this.getChildAt(index)).finalizeIt();
        }
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    protected final int indexOf(Object key, Comparator comparator) {
        return ((this.children == null) ? -1 : Collections.binarySearch(this.children, key, comparator));
    }

    public final int indexOf(String nodeName) {
        return this.indexOf(nodeName, FileTreeModel.childNameComparator);
    }

    public final int leftIndexOf(String nodeName) {
        return this.indexOf(nodeName, FileTreeModel.leftChildNameComparator);
    }

    public final int rightIndexOf(String nodeName) {
        return this.indexOf(nodeName, FileTreeModel.rightChildNameComparator);
    }

    @SuppressWarnings({"NonPrivateFieldAccessedInSynchronizedContext"})
    public boolean hasFilteredChildren() {
        if (this.children != null) {
            synchronized (this) {
                for (final ComparedTreeNode currentNode : (Vector<ComparedTreeNode>) this.children) {
                    if (currentNode.isNotFiltered() && !currentNode.isIgnored()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @SuppressWarnings({"unchecked","NonPrivateFieldAccessedInSynchronizedContext"})
    public final int getFilteredChildCount() {
        int count = 0;

        if (this.children != null) {
            synchronized (this) {
                for (final ComparedTreeNode currentNode : (Vector<ComparedTreeNode>) this.children) {
                    if (currentNode.isNotFiltered() && !currentNode.isIgnored()) {
                        count++;
                    }
                }
            }
        }

        return count;
    }

    @SuppressWarnings({"unchecked","NonPrivateFieldAccessedInSynchronizedContext"})
    @Nullable public final ComparedTreeNode getFilteredChildAt(int index) {
        int count = 0;

        if (this.children != null) {
            synchronized (this) {
                for (final ComparedTreeNode currentNode : (Vector<ComparedTreeNode>) this.children) {
                    if (currentNode.isNotFiltered() && !currentNode.isIgnored()) {
                        if (count == index) {
                            return currentNode;
                        }
                        count++;
                    }
                }
            }

            // When the model structure is being refreshed, it might happen that index >= count
            //return (ComparedTreeNode) this.children.lastElement();
        }

        return null;
    }

    public final void setNotFiltered(boolean notFiltered) {
        this.notFiltered = notFiltered;
    }

    public final boolean isNotFiltered() {
        return this.notFiltered;
    }

    @SuppressWarnings({"unchecked","NonPrivateFieldAccessedInSynchronizedContext"})
    public final int indexOfFiltered(ComparedTreeNode child) {
        if (this.children != null) {
            if (this.getModel().hasNoFilters()) {
                return this.children.indexOf(child);
            }

            int count = 0;

            if (child != null) {
                synchronized (this) {
                    for (final ComparedTreeNode currentNode : (Vector<ComparedTreeNode>) this.children) {
                        final boolean visible = (currentNode.isNotFiltered() && !currentNode.isIgnored());

                        if (child.equals(currentNode)) {
                            return (visible ? count : -1);
                        } else if (visible) {
                            count++;
                        }
                    }
                }
            }
        }

        return -1;
    }

    public final void swapLeftRight() {
        for (ComparedTreeNode node : this.getDescendentNodes()) {
            node.swapThisLeftRight();

            if (node.state == FileStateEnum.LEFT_ONLY) {
                node.setState(FileStateEnum.RIGHT_ONLY);
            } else if (node.state == FileStateEnum.RIGHT_ONLY) {
                node.setState(FileStateEnum.LEFT_ONLY);
            }
        }
    }

    protected void swapThisLeftRight() {}

    public final void refreshCacheFiles(boolean recursive, boolean asynchronous) {
        if (recursive) {
            for (ComparedTreeNode node : this.getDescendentNodes()) {
                node.refreshThisCacheFiles(asynchronous);
            }
        } else {
            this.refreshThisCacheFiles(asynchronous);
        }
    }

    public void refreshThisCacheFiles(boolean asynchronous) {}

    public abstract int compareTimestamps();
}