/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.ComparisonParameters;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryManager;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.jetbrains.annotations.Nullable;

/**
 */
public class PerformClassAnalysisActionDelegate extends AbstractActionDelegate {

    @Override public boolean isVisible(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        return !(panel == null || panel.getComparisonParameters().isClassAnalysis());
    }

    public void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        final ComparisonParameters parameters = getModifiedParameters(panel);

        if (parameters != null && selectedNodes != null) {
            final ICompareDirectoryManager manager = panel.getManager();

            manager.saveFiles(selectedNodes);
            for (ComparedTreeNode node : selectedNodes) {
                // Refreshes cached node files.
                manager.refreshCachedFiles(node, false);

                // Starts class structure comparison on node.
                panel.refreshSubTree((FileTreeNode) node, false, true, parameters);
            }
        }
    }

    @Nullable private static ComparisonParameters getModifiedParameters(@Nullable ICompareDirectoryPanel panel) {
        if (panel != null) {
            try {
                final ComparisonParameters parameters = panel.getComparisonParameters().clone();

                parameters.setClassAnalysis    (true);
                parameters.setClassAnalysisOnly(true);

                return parameters;
            } catch (CloneNotSupportedException e) {
                // Should never happen.
                CompareDirectoryPlugin.getLogger().error(e);
            }
        }

        return null;
    }
}