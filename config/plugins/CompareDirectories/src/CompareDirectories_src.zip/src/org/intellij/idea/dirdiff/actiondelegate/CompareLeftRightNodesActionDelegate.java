/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.fileTypes.StdFileTypes;

/**
 */
public class CompareLeftRightNodesActionDelegate extends AbstractActionDelegate {
    @Override
    public boolean isVisible(ICompareDirectoryPanel panel, ComparedTreeNode[] selectedNodes) {
        return (selectedNodes != null &&
                selectedNodes.length == 2 &&
                selectedNodes[0] != null &&
                selectedNodes[1] != null &&
                selectedNodes[0].getClass() == selectedNodes[1].getClass());
    }

    @Override
    public boolean isEnabled(ICompareDirectoryPanel panel, ComparedTreeNode[] selectedNodes) {
        if (!this.isVisible(panel, selectedNodes)) {
            return false;
        }

        final FileStateEnum[]  nodeStates          = { selectedNodes[0].getState(), selectedNodes[1].getState() };
        final boolean          isFirstNodeLeftOnly = (nodeStates[0] == FileStateEnum.LEFT_ONLY);
        final ComparedTreeNode leftNode            = (isFirstNodeLeftOnly ? selectedNodes[0] : selectedNodes[1]);
        final ComparedTreeNode rightNode           = (isFirstNodeLeftOnly ? selectedNodes[1] : selectedNodes[0]);
        final ReadableFile     leftFile            = leftNode .getLeftFile();
        final ReadableFile     rightFile           = rightNode.getRightFile();

        return (((nodeStates[0] == FileStateEnum.LEFT_ONLY  && nodeStates[1] == FileStateEnum.RIGHT_ONLY) ||
                 (nodeStates[0] == FileStateEnum.RIGHT_ONLY && nodeStates[1] == FileStateEnum.LEFT_ONLY))
                && (!leftFile.isBinary()  || leftFile .getFileType().equals(StdFileTypes.CLASS))
                && (!rightFile.isBinary() || rightFile.getFileType().equals(StdFileTypes.CLASS)));
    }

    public void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        if (this.isVisible(panel, selectedNodes) && panel != null) {
            final boolean          isFirstNodeLeftOnly = (selectedNodes[0].getState() == FileStateEnum.LEFT_ONLY);
            final ComparedTreeNode leftNode            = (isFirstNodeLeftOnly ? selectedNodes[0] : selectedNodes[1]);
            final ComparedTreeNode rightNode           = (isFirstNodeLeftOnly ? selectedNodes[1] : selectedNodes[0]);
            final ReadableFile     leftFile            = leftNode .getLeftFile();
            final ReadableFile     rightFile           = rightNode.getRightFile();

            if (leftNode instanceof FileTreeNode &&
                (leftFile .isDirectory() || leftFile .isCompressedFile() ||
                 rightFile.isDirectory() || rightFile.isCompressedFile())) {
                panel.addComparisonPanel(leftFile, rightFile, panel.getComparisonParameters());
            } else {
                panel.openFileDiffs(selectedNodes, leftFile, rightFile);
            }
        }
    }
}