/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.util;

import java.lang.reflect.Array;

import org.jetbrains.annotations.Nullable;

/**
 * Gathers miscellaneous general-purpose utility functions.
 */
public class Util {
    private Util() {
    }

    @SuppressWarnings({"TypeMayBeWeakened"})
    @Nullable
    public static <T> T[] ensureArrayType(@Nullable Object[] array, Class<T> clazz) {
        if (array == null) {
            return null;
        }

        for (Object o : array) {
            if (!clazz.isInstance(o)) {
                return null;
            }
        }

        final Object[] newArray = (Object[]) Array.newInstance(clazz, array.length);

        System.arraycopy(array, 0, newArray, 0, array.length);
        return (T[]) newArray;
    }
}
