/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.disassemble.FullClassVisitor;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassDesc;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitor;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.intellij.idea.dirdiff.model.disassemble.SimpleClassVisitor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.asm4.ClassReader;

import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.VirtualFile;

/**
 * Provides utility methods on files:<ul>
 * <li>copying files,</li>
 * <li>comparing bytes stored in two files,</li>
 * <li>extracting bytes from an input stream to a temporary file,</li>
 * <li>decompiling a Java class to a temporary file,</li>
 * <li>putting a binary file hex dump to a temporary file</li>
 * </ul>
 */
public class Files {
    @NonNls public  static final String UNKNOWN_FILE_TYPE_NAME    = StdFileTypes.UNKNOWN.getName();
    @NonNls public  static final String PLAIN_TEXT_FILE_TYPE_NAME = StdFileTypes.PLAIN_TEXT.getName();
    @NonNls private static final String DIR_TEMP_FILE_PREFIX      = "IDEA_comparedir_";
    @NonNls private static final String BINARY_TEMP_FILE_PREFIX   = "IDEA_comparebinary_";
    @NonNls private static final String CLASS_TEMP_FILE_PREFIX    = "IDEA_compareclass_";

    public  static final int        BUFFER_SIZE        = 8192;
    public  static final ByteBuffer COPY_BUFFER        = ByteBuffer.allocateDirect(BUFFER_SIZE);
    private static final FileBuffer LEFT_BUFFER        = new FileBuffer(BUFFER_SIZE);
    private static final FileBuffer RIGHT_BUFFER       = new FileBuffer(BUFFER_SIZE);
    private static final int        NUM_BYTES_PER_LINE = 16;

    /** Utility class constructor. */
    private Files() {}

    /**
     * Refreshes both left and right files of this node. If the node is a directory,
     * refreshes also its child node files.
     * @param node the comparison tree node
     * @param asynchronous <code>true</code> to invoke the refresh later,
     *   <code>false</code> to refresh files immediately.
     */
    public static void refreshNodeFiles(ComparedTreeNode node, boolean asynchronous) {
        final VirtualFile leftFile  = node.getLeftFile() .getVirtualFile();
        final VirtualFile rightFile = node.getRightFile().getVirtualFile();

        if (leftFile != null) {
            leftFile.refresh(asynchronous, true);
        }
        if (rightFile != null && leftFile != rightFile) {
            rightFile.refresh(asynchronous, true);
        }
    }

    /**
     * Returns <code>true</code> if these readable files both have a CRC and their
     * CRC is identical, <code>false</code> otherwise.
     * @return <code>true</code> if these readable files both have a CRC and their
     * CRC is identical, <code>false</code> otherwise.
     */
    public static boolean haveSameCrc(ReadableFile leftFile, ReadableFile rightFile) {
        return (leftFile.hasCrc() && rightFile.hasCrc() && leftFile.getCrc() == rightFile.getCrc());
    }

    /**
     * Completes the byte-to-byte comparison between the two files of this tree node.
     * @param node the node whose comparison state is to be evaluated
     * @param interruptible the object used to notify a "stop" user request
     * @return the comparison status of the node
     */
    public static FileStateEnum checkNodeFiles(FileTreeNode node, Interruptible interruptible) {
        final FileType leftFileType            = node.getFileType();
        boolean        blankDifference         = false;
        boolean        insignificantDifference = false;
        boolean        differenceInComment     = false;

        try {
            LEFT_BUFFER .openStream(node.getLeftFile());
            RIGHT_BUFFER.openStream(node.getRightFile());

            final boolean isLeftBinary  = LEFT_BUFFER .checkBinary(node.getLeftFile());
            final boolean isRightBinary = RIGHT_BUFFER.checkBinary(node.getRightFile());
            final boolean isBinary      = (leftFileType.isBinary() &&
                                           (!leftFileType.getName().equals(UNKNOWN_FILE_TYPE_NAME) ||
                                            isLeftBinary || isRightBinary));

            LEFT_BUFFER .enableMark(!isBinary);
            RIGHT_BUFFER.enableMark(!isBinary);

            final boolean       matchableAllowedDiff = (!isBinary && node.getModel().isMatchableAllowedDiff(node));
            final CommentMark[] commentMarks         = (isBinary ? null : getCommentMarks(leftFileType));
            final int[]         commentIndices       = (commentMarks == null) ? null : new int[commentMarks.length];
            int                 commentInProgress    = -1;  // Index in the above int array, -1 if none

            LEFT_BUFFER .enableMark(matchableAllowedDiff);
            RIGHT_BUFFER.enableMark(matchableAllowedDiff);

            while (LEFT_BUFFER.hasBytes() && RIGHT_BUFFER.hasBytes() && !interruptible.hasBeenInterrupted()) {
                final byte leftByte  = LEFT_BUFFER .getByte();
                final byte rightByte = RIGHT_BUFFER.getByte();

                if (matchableAllowedDiff && FileBuffer.isEndOfLineCharacter(leftByte)) {
                    LEFT_BUFFER .setMark();
                    RIGHT_BUFFER.setMark();
                }

                // Handles comments.
                if (commentIndices != null) {
                    if (commentInProgress >= 0) {
                        // Handles comment end marks
                        final byte[]  commentMarkEnd   = commentMarks[commentInProgress].end;
                        final boolean isNotMarkEndChar;

                        if (commentMarkEnd == null) {
                            isNotMarkEndChar = (!FileBuffer.isEndOfLineCharacter(leftByte) &&
                                                !FileBuffer.isEndOfLineCharacter(rightByte));
                        } else {
                            final byte commentMarkEndByte = commentMarkEnd[commentIndices[commentInProgress]];
                            isNotMarkEndChar = (commentMarkEndByte != leftByte && commentMarkEndByte != rightByte);
                        }

                        if (isNotMarkEndChar) {
                            commentIndices[commentInProgress] = 0;
                        } else {
                            commentIndices[commentInProgress]++;
                            if (commentIndices[commentInProgress] == commentMarks[commentInProgress].endLength) {
                                commentIndices[commentInProgress] = 0;
                                commentInProgress = -1;

                                // Prevent the end-of-line from being interpreted as blank, and the diff
                                // as "different" instead of "different in comments" or "different by blanks"
                                if (commentMarkEnd == null &&
                                        (FileBuffer.isEndOfLineCharacter(leftByte) ^ FileBuffer.isEndOfLineCharacter(rightByte))) {
                                    final FileBuffer bufferToBeSkipped = FileBuffer.isEndOfLineCharacter(leftByte) ? RIGHT_BUFFER : LEFT_BUFFER;

                                    if (bufferToBeSkipped.skipUntilEndOfLineDetectingNonWhiteSpaces()) {
                                        differenceInComment = true;
                                    } else {
                                        blankDifference = true;
                                    }
                                    continue;
                                }
                            }
                        }
                    } else {
                        // Handles comment start marks
                        for (int i = 0; i < commentMarks.length; i++) {
                            final byte[] commentMarkStart = commentMarks[i].start;

                            if (commentMarkStart[commentIndices[i]] == leftByte) {
                                commentIndices[i]++;
                                if (commentIndices[i] == commentMarkStart.length) {
                                    Arrays.fill(commentIndices, 0);

                                    if (differenceInComment) {
                                        // If a diff in a comment has already been found, don't search for differences in other comments
                                        if (commentMarks[i].end == null) {
                                            LEFT_BUFFER .skipUntilEndOfLine();
                                            RIGHT_BUFFER.skipUntilEndOfLine();
                                        } else {
                                            LEFT_BUFFER .skipUntilByteSequence(commentMarks[i].end);
                                            RIGHT_BUFFER.skipUntilByteSequence(commentMarks[i].end);
                                        }
                                    } else {
                                        commentInProgress = i;
                                    }
                                    break;
                                }
                            } else {
                                commentIndices[i] = 0;
                            }
                        }
                    }
                }

                if (leftByte == rightByte) {
                    LEFT_BUFFER .goToNextByte();
                    RIGHT_BUFFER.goToNextByte();

                } else if (isBinary) {
                    return FileStateEnum.DIFFERENT;

                } else if (Character.isWhitespace(leftByte)) {
                    blankDifference = true;
                    LEFT_BUFFER.skipWhiteSpaceBytes();

                } else if (Character.isWhitespace(rightByte)) {
                    blankDifference = true;
                    RIGHT_BUFFER.skipWhiteSpaceBytes();

                } else if (!matchableAllowedDiff) {
                    if (commentInProgress < 0) {
                        return FileStateEnum.DIFFERENT;
                    }

                    differenceInComment = true;
                    // A diff in a comment has been found => don't search for other differences in the comment
                    if (commentMarks[commentInProgress].end == null) {
                        LEFT_BUFFER .skipUntilEndOfLine();
                        RIGHT_BUFFER.skipUntilEndOfLine();
                    } else {
                        LEFT_BUFFER .skipUntilByteSequence(commentMarks[commentInProgress].end);
                        RIGHT_BUFFER.skipUntilByteSequence(commentMarks[commentInProgress].end);
                    }
                    commentInProgress = -1;

                } else {
                    LEFT_BUFFER .skipUntilEndOfLine();
                    RIGHT_BUFFER.skipUntilEndOfLine();

                    final String leftDiffedText  = LEFT_BUFFER .getTextFromMark();
                    final String rightDiffedText = RIGHT_BUFFER.getTextFromMark();

                    if (!node.getModel().matchAllowedDiffs(node, leftDiffedText, rightDiffedText)) {
                        return FileStateEnum.DIFFERENT;
                    }

                    insignificantDifference = true;
                    LEFT_BUFFER .setMark();
                    RIGHT_BUFFER.setMark();
                }
            }

            // Skip end-of-file blanks/non-significant diffs when they are in only one of the two non-binary files.
            if (!(isBinary || interruptible.hasBeenInterrupted()) &&
                (LEFT_BUFFER.hasBytes() ^ RIGHT_BUFFER.hasBytes())) {
                if (LEFT_BUFFER.hasBytes() && Character.isWhitespace(LEFT_BUFFER.getByte())) {
                    blankDifference = true;
                    LEFT_BUFFER .skipWhiteSpaceBytes();
                } else if (RIGHT_BUFFER.hasBytes() && Character.isWhitespace(RIGHT_BUFFER.getByte())) {
                    blankDifference = true;
                    RIGHT_BUFFER.skipWhiteSpaceBytes();
                } else {
                    // Handles end-of-file non-significant differences if there are any.
                    if (LEFT_BUFFER.hasBytes()) {
                        LEFT_BUFFER .skipUntilEndOfLine();
                    } else {
                        RIGHT_BUFFER.skipUntilEndOfLine();
                    }
                    insignificantDifference = node.getModel().matchAllowedDiffs(node, LEFT_BUFFER.getTextFromMark(),
                                                                                RIGHT_BUFFER.getTextFromMark());
                }
            }

            return (LEFT_BUFFER.hasBytes() || RIGHT_BUFFER.hasBytes() ? FileStateEnum.DIFFERENT :
                    insignificantDifference                           ? FileStateEnum.DIFFERENT_NON_SIGNIFICANT :
                    differenceInComment                               ? FileStateEnum.DIFFERENT_IN_COMMENTS     :
                    blankDifference                                   ? FileStateEnum.DIFFERENT_IN_BLANKS
                                                                      : FileStateEnum.IDENTICAL);
        } catch (IOException e) {
            return FileStateEnum.DIFFERENT;

        } finally {
            try {
                LEFT_BUFFER.closeStream();
            } catch (IOException e) {
                CompareDirectoryPlugin.getLogger().error(e);
            }
            try {
                RIGHT_BUFFER.closeStream();
            } catch (IOException e) {
                CompareDirectoryPlugin.getLogger().error(e);
            }
        }
    }

    /**
     * Creates a file containing a textual view of a binary file.
     * @param file the readable file whose contents are binary
     * @return the textual view of a binary file.
     */
    @SuppressWarnings({"NumericCastThatLosesPrecision"})
    public static File getComparableBinaryFile(ReadableFile file) {
        BufferedOutputStream outputStream = null;

        try {
            final File extractedFile = FileUtil.createTempFile(BINARY_TEMP_FILE_PREFIX, ".txt");

            extractedFile.deleteOnExit();

            outputStream = new BufferedOutputStream(new FileOutputStream(extractedFile));

            final byte[] hexDigits = new byte[4 * NUM_BYTES_PER_LINE + 4];
            int          iByte     = 0;

            Arrays.fill(hexDigits, (byte) ' ');
            LEFT_BUFFER.openStream(file);

            while (LEFT_BUFFER.hasBytes()) {
                final byte oneByte = LEFT_BUFFER.getByte();

                if (iByte == NUM_BYTES_PER_LINE) {
                    outputStream.write(hexDigits);
                    outputStream.write('\n');
                    iByte = 0;
                }

                hexDigits[3 * iByte]     = (byte) Character.toUpperCase(Character.forDigit((oneByte >> 4) & 0x0F, 16));
                hexDigits[3 * iByte + 1] = (byte) Character.toUpperCase(Character.forDigit( oneByte       & 0x0F, 16));

                // Show control characters as dots
                hexDigits[3 * NUM_BYTES_PER_LINE + iByte + 4] = (Character.isISOControl(oneByte) ? (byte) '.' : oneByte);

                LEFT_BUFFER.goToNextByte();
                iByte++;
            }

            if (iByte < NUM_BYTES_PER_LINE) {
                Arrays.fill(hexDigits, 3 * iByte,                          3 * NUM_BYTES_PER_LINE,     (byte) ' ');
                Arrays.fill(hexDigits, 3 * NUM_BYTES_PER_LINE + iByte + 4, 4 * NUM_BYTES_PER_LINE + 4, (byte) ' ');
            }

            outputStream.write(hexDigits);
            outputStream.write('\n');

            //noinspection ResultOfMethodCallIgnored
            extractedFile.setReadOnly();

            return extractedFile;
        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            return null;

        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }
            }
        }
    }

    /**
     * Creates a description containing a textual view of a Java class file.
     * @param file the readable file whose contents are a compiled Java class
     * @return the description with the textual view of a Java class file.
     */
    @SuppressWarnings({"TypeMayBeWeakened"})
    public static JavaClassDesc getJavaClassDesc(ReadableFile file, boolean generateText, boolean analyzeMethodCode, MyClassVisitorContext context) {
        try {
            final MyClassVisitor classVisitor = (generateText ? new FullClassVisitor(context, true)
                                                              : new SimpleClassVisitor(context, analyzeMethodCode));

            try {
                new ClassReader(file.getInputStream()).accept(classVisitor, 0);
            } catch (RuntimeException e) {
                if (!generateText) {
                    throw e;
                }
                // If FullClassVisitor decompilation unexpectedly fails, then visit class again without decompilation.
                new ClassReader(file.getInputStream()).accept(new FullClassVisitor(context, false), 0);
            }
            return classVisitor.getClassDesc();
        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            return null;
        }
    }

    /**
     * Creates a file containing a textual view of a Java class file.
     * @param comparableJavaClass the text whose contents are a compiled Java class
     * @return the textual view of a Java class file.
     */
    @SuppressWarnings({"TypeMayBeWeakened"})
    public static File getComparableJavaClassFile(String comparableJavaClass) {
        BufferedOutputStream outputStream = null;

        try {
            final File extractedFile = FileUtil.createTempFile(CLASS_TEMP_FILE_PREFIX, ".txt");

            extractedFile.deleteOnExit();

            outputStream = new BufferedOutputStream(new FileOutputStream(extractedFile));
            outputStream.write(comparableJavaClass.getBytes());

            return extractedFile;
        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            return null;

        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }
            }
        }
    }

    /**
     * Copies a file from a source path to a target path using the
     * high-performance Java new I/O API.
     * If both paths are equal, the copy is skipped.
     * Note: this method is NOT thread-safe, for it uses a static byte buffer.
     * Thread synchronisation is globally completed by the calling method run().
     *
     * @param source    the directory the file to be copied is
     * @param target    the location where the file should be copied
     * @throws IOException if any I/O error occurred
     */
    public static void copyFile(ReadableFile source, File target) throws IOException {
        if (source.isInCompressedFile()) {
            Files.standardCopyFile(source, target);
        } else {
            Files.fastCopyFile(source.getRealFile(), target);
        }

        if (source.lastModified() > 0) {
            target.setLastModified(source.lastModified());
        }
    }

    /**
     * Copies a file from a source path to a target path using the
     * high-performance Java new I/O API.
     * If both paths are equal, the copy is skipped.
     * Note: this method is NOT thread-safe, for it uses a static byte buffer.
     * Thread synchronisation is globally completed by the calling method run().
     *
     * @param source the directory the file to be copied is
     * @param target the location where the file should be copied
     * @throws IOException if any I/O error occurred
     */
    private static void fastCopyFile(File source, File target) throws IOException {
        if (source.equals(target)) { return; }

        FileChannel sourceChannel = null;
        FileChannel targetChannel = null;

        try {
            // Open source and target files, then get channels from these streams
            sourceChannel = new FileInputStream (source).getChannel();
            targetChannel = new FileOutputStream(target).getChannel();

            final ByteBuffer  buffer        = Files.COPY_BUFFER;
            boolean           hasMoreBytes;

            // As long as there are bytes to be read,
            // read a bunch of bytes from source file to buffer,
            // then write buffer contents to target file.
            do {
                buffer.clear();
                hasMoreBytes = (sourceChannel.read(buffer) >= 0);

                if (hasMoreBytes) {
                    buffer.flip();
                    targetChannel.write(buffer);
                }
            } while (hasMoreBytes);

        } finally {
            // Close the channels and streams
            if (targetChannel != null) {
                targetChannel.close();
            }
            if (sourceChannel != null) {
                sourceChannel.close();
            }
        }
    }

    /**
     * Copies a file from a source path to a target path using the
     * standard Java I/O API.
     * If both paths are equal, the copy is skipped.
     * Note: this method is NOT thread-safe, for it uses a static byte buffer.
     * Thread synchronisation is globally completed by the calling method run().
     *
     * @param source the source file to be copied is
     * @param target the target where the file should be copied
     * @throws IOException if any I/O error occurred
     */
    private static void standardCopyFile(ReadableFile source, File target) throws IOException {
        if (source.equals(target)) { return; }

        FileChannel targetChannel = null;

        try {
            final ByteBuffer buffer = Files.COPY_BUFFER;

            // Open target file, then get channel from this stream
            targetChannel = new FileOutputStream(target).getChannel();

            // Open source file
            LEFT_BUFFER.openStream(source);

            // As long as there are bytes to be read,
            // read a bunch of bytes from source file to buffer,
            // then write buffer contents to target file.
            while (LEFT_BUFFER.hasBytes()) {
                buffer.clear();

                buffer.put(LEFT_BUFFER.getByteBuffer(), 0, LEFT_BUFFER.getNumBytesRead());
                buffer.flip();
                targetChannel.write(buffer);

                LEFT_BUFFER.readStream();
            }

        } finally {
            // Close the channels and streams
            if (targetChannel != null) {
                try {
                    LEFT_BUFFER.closeStream();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }

                targetChannel.close();
            }
        }
    }

    /**
     * Creates a temporary file with the contents of this input stream.
     * The temporary file will be automatically deleted when the Java VM
     * terminates (normal termination only.)
     *
     * @param stream the stream to be copied into the temporary file
     * @return the temporary file
     */
    public static File extractTempFile(InputStream stream) {
        BufferedInputStream  inputStream  = null;
        BufferedOutputStream outputStream = null;

        try {
            final File extractedFile = FileUtil.createTempFile(DIR_TEMP_FILE_PREFIX, null);
            extractedFile.deleteOnExit();

            inputStream  = new BufferedInputStream (stream);
            outputStream = new BufferedOutputStream(new FileOutputStream(extractedFile));

            final byte[] buffer = new byte[4096];
            int          numBytesRead;

            numBytesRead = inputStream.read(buffer);
            while (numBytesRead >= 0) {
                outputStream.write(buffer, 0, numBytesRead);
                numBytesRead = inputStream.read(buffer);
            }

            return extractedFile;

        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            return null;

        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }
            }
        }
    }

    /**
     * Returns a file path with a slash as file separator
     * @param filePath the file path
     * @return  the normalized file path
     * @see #denormalizeFilePath(String)
     */
    public static String normalizeFilePath(String filePath) {
        return filePath.replace(File.separatorChar, '/');
    }

    /**
     * Returns a file path with an OS-dependent file separator
     * @param filePath the file path
     * @return  the denormalized file path
     * @see #normalizeFilePath(String)
     */
    public static String denormalizeFilePath(String filePath) {
        return filePath.replace('/', File.separatorChar);
    }

    private static class CommentMark {
        public final byte[] start;
        public final byte[] end;
        public final int    startLength;
        public final int    endLength;

        private CommentMark(String start, String end) {
            this.start       = (start == null) ? null : start.getBytes();
            this.end         = (end   == null) ? null : end  .getBytes();
            this.startLength = (start == null) ? 1    : start.length();
            this.endLength   = (end   == null) ? 1    : end  .length();
        }
    }

    private static final CommentMark[] PROPERTIES_COMMENTS = { new CommentMark("#", null) };
    private static final CommentMark[] JAVA_COMMENTS       = { new CommentMark("/*", "*/"),    new CommentMark("//", null) };
    private static final CommentMark[] XML_COMMENTS        = { new CommentMark("<!--", "-->") };
    private static final CommentMark[] JSP_COMMENTS        = { new CommentMark("<!--", "-->"), new CommentMark("<%--", "--%>") };

    private static CommentMark[] getCommentMarks(FileType fileType) {
        final String typeName = fileType.getName();

        if (fileType == StdFileTypes.JAVA ||
            "JavaScript".equalsIgnoreCase(typeName) ||
            "C++"       .equalsIgnoreCase(typeName) ||
            "C#"        .equalsIgnoreCase(typeName) ||
            "C"         .equalsIgnoreCase(typeName) ||
            "Scala"     .equalsIgnoreCase(typeName)) {
            return JAVA_COMMENTS;
        } else if (fileType == StdFileTypes.PROPERTIES ||
                   "Ruby"  .equalsIgnoreCase(typeName) ||
                   "Python".equalsIgnoreCase(typeName)) {
            return PROPERTIES_COMMENTS;
        } else if (fileType == StdFileTypes.XML  ||
                   fileType == StdFileTypes.HTML ||
                   fileType == StdFileTypes.XHTML) {
            return XML_COMMENTS;
        } else if (fileType == StdFileTypes.JSP ||
                   fileType == StdFileTypes.JSPX) {
            return JSP_COMMENTS;
        } else {
            return null;
        }
    }
}
