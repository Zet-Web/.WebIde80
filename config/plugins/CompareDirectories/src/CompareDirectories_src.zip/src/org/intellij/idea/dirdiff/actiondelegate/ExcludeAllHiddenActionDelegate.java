/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 */
public class ExcludeAllHiddenActionDelegate extends AbstractActionDelegate {
    public void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        if (selectedNodes != null) {
            for (final ComparedTreeNode selectedNode : selectedNodes) {
                if (selectedNode != null) {
                    excludeFilteredNode(selectedNode);
                }
            }

            if (panel != null) {
                panel.refreshTree(false);
            }
        }
    }

    private static void excludeFilteredNode(@NotNull ComparedTreeNode selectedNode) {
        if (selectedNode.isNotFiltered()) {
            final int numChildren = selectedNode.getChildCount();

            for (int index = numChildren; --index >= 0; ) {
                excludeFilteredNode((ComparedTreeNode) selectedNode.getChildAt(index));
            }
        } else if (!selectedNode.isExcluded()) {
            selectedNode.setExcluded(true);
        }
    }
}