/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.intellij.idea.dirdiff.util.ByteVector;
import org.jetbrains.annotations.NotNull;

/**
 * A text representation of an attribute or method in a java class text.
 * @see JavaClassDesc
 */
public class JavaClassMemberDesc implements Comparable<JavaClassMemberDesc> {

    public enum Type {
        FIELD, CONSTRUCTOR, METHOD, SPECIAL, META_FIELD
    }

    private final JavaClassDesc javaClassDesc;
    private final String        name;
    private String              signature;
    private final Type          type;
    private int                 start;
    private int                 end;
    private String              text;
    private final int           accessFlags;
    private ByteVector          byteVector;

    public JavaClassMemberDesc(JavaClassDesc javaClassDesc, @NotNull String name, Type type, int accessFlags, int start) {
        this.javaClassDesc = javaClassDesc;
        this.name          = name;
        this.signature     = name;
        this.type          = type;
        this.accessFlags   = accessFlags;
        this.start         = start;
    }

    public String getSignature() {
        return this.signature;
    }

    public boolean hasSignature(Object signature) {
        return this.signature.equals(signature);
    }

    public boolean isAccessSyntheticMethod() {
        return AsmUtil.isAccessSyntheticMethod(this.name);
    }

    public String getName() {
        return this.name;
    }

    public Type getType() {
        return this.type;
    }

    public String getText() {
        if (this.text == null && this.end != 0) {
            this.text = this.javaClassDesc.getText().substring(this.start, this.end);
        }
        return (this.text == null) ? this.signature : this.text;
    }

    public JavaClassDesc getClassDesc() {
        return this.javaClassDesc;
    }

    /*package*/ void setSignature(@NotNull String signature) {
        this.signature = signature;
    }

    /*package*/ void setEnd(int end) {
        this.end  = end;
    }

    /*package*/ void shift(int shift, int startIndex) {
        if (this.start >= startIndex) {
            this.start += shift;
            this.end   += shift;
            this.text   = null;
        } else if (this.end >= startIndex) {
            this.end   += shift;
            this.text   = null;
        }
    }

    public int getAccessFlags() {
        return this.accessFlags;
    }

    public boolean isAbstract() {
        return AsmUtil.isAbstract(this.accessFlags);
    }

    public boolean isStatic() {
        return AsmUtil.isStatic(this.accessFlags);
    }

    public boolean isFinal() {
        return AsmUtil.isFinal(this.accessFlags);
    }

    public boolean isNative() {
        return AsmUtil.isNative(this.accessFlags);
    }

    public boolean isDeprecated() {
        return AsmUtil.isDeprecated(this.accessFlags);
    }

    public boolean isSynthetic() {
        return AsmUtil.isSynthetic(this.accessFlags);
    }

    public boolean isLambda() {
        return AsmUtil.isLambdaMethod(this.signature);
    }

    public boolean isVarArgs() {
        return AsmUtil.isVarArgs(this.accessFlags);
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }

        final JavaClassMemberDesc other = (JavaClassMemberDesc) o;

        return (this.type == other.type && this.signature.equals(other.signature));
    }

    @Override public int hashCode() {
        return 31 * this.signature.hashCode() + this.type.hashCode();
    }

    public int compareTo(JavaClassMemberDesc other) {
        final int result = this.type.compareTo(other.type);

        if (result != 0) { return result; }
        return this.getSignature().compareTo(other.signature);
    }

    @Override public String toString() {
        return this.signature;
    }

    public ByteVector getByteVector() {
        return this.byteVector;
    }

    public void setByteVector(ByteVector byteVector) {
        this.byteVector = byteVector;
    }

    public void disposeByteVector() {
        if (this.byteVector != null) {
            this.byteVector.dispose();
        }
    }
}
