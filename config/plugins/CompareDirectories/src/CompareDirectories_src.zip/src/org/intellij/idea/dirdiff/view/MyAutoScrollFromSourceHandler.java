/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditor;
import com.intellij.openapi.fileEditor.FileEditorManagerAdapter;
import com.intellij.openapi.fileEditor.FileEditorManagerEvent;
import com.intellij.openapi.fileEditor.FileEditorManagerListener;
import com.intellij.openapi.fileEditor.TextEditor;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiFile;
import com.intellij.ui.AutoScrollFromSourceHandler;
import com.intellij.util.Alarm;
import com.intellij.util.IJSwingUtilities;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.util.Commands;
import org.jetbrains.annotations.NotNull;

/**
 * Auto-to-scroll-from-source handler class:
 */
class MyAutoScrollFromSourceHandler extends AutoScrollFromSourceHandler {

    private final CompareDirectoryView     view;
    private final Alarm                    alarm;
    private       FileEditorManagerAdapter fileEditorManagerAdapter;

    public MyAutoScrollFromSourceHandler(@NotNull CompareDirectoryPanel panel, Project project) {
        super(project, panel);
        this.view    = (CompareDirectoryView) panel.getView();
        this.alarm   = new Alarm(this.myProject);
    }

    @Override
    protected boolean isAutoScrollEnabled() {
        return this.isAutoScrollMode();
    }

    @Override
    protected void setAutoScrollEnabled(boolean enabled) {
        this.setAutoScrollMode(enabled);
    }

    @Override
    protected void selectElementFromEditor(@NotNull FileEditor fileEditor) {
        throw new UnsupportedOperationException();
    }

    public void install() {
        this.fileEditorManagerAdapter = new FileEditorManagerAdapter() {
            public void selectionChanged(final FileEditorManagerEvent event) {
                Commands.invokeWithAlarm(MyAutoScrollFromSourceHandler.this.alarm, new Runnable() {
                    public void run() {
                        if (MyAutoScrollFromSourceHandler.this.myProject.isDisposed()) {
                            return;
                        }
                        final CompareDirectoryPanel currentPanel = MyAutoScrollFromSourceHandler.this.view.getCurrentPanel();
                        if (currentPanel == null      ||
                            !currentPanel.isShowing() ||
                            !currentPanel.getConfiguration().isAutoScrollFromSource()) {
                            return;
                        }
                        final FileEditor newEditor = event.getNewEditor();
                        if (newEditor instanceof TextEditor) {
                            final Editor editor = ((TextEditor) newEditor).getEditor();
                            MyAutoScrollFromSourceHandler.this.selectIn(editor, currentPanel);
                        }
                    }
                });
            }
        };
        this.myProject.getMessageBus().connect(this.myProject).subscribe(FileEditorManagerListener.FILE_EDITOR_MANAGER,
                                                                         this.fileEditorManagerAdapter);
    }

    private void selectIn(@NotNull Editor editor, @NotNull CompareDirectoryPanel currentPanel) {
        if (IJSwingUtilities.hasFocus(currentPanel.getComponentToFocus())) {
            return;
        }

        final PsiFile psiFile = PsiDocumentManager.getInstance(this.myProject).getPsiFile(editor.getDocument());

        if (psiFile == null) {
            return;
        }

        final ComparedTreeNode node = currentPanel.getTreeModel().findNode(psiFile.getVirtualFile());

        if (node != null) {
            currentPanel.selectNode(node);
        }
    }

    public void dispose() {
        if (this.fileEditorManagerAdapter != null) {
            this.myProject.getMessageBus().connect(this.myProject).disconnect();
        }
    }

    protected boolean isAutoScrollMode() {
        final CompareDirectoryPanel currentPanel = MyAutoScrollFromSourceHandler.this.view.getCurrentPanel();

        return (currentPanel != null && currentPanel.getConfiguration().isAutoScrollFromSource());
    }

    protected void setAutoScrollMode(boolean autoScrollMode) {
        final CompareDirectoryPanel currentPanel = MyAutoScrollFromSourceHandler.this.view.getCurrentPanel();

        if (currentPanel != null) {
            currentPanel.getConfiguration().setAutoScrollFromSource(autoScrollMode);

            if (autoScrollMode) {
                final Editor editor = this.view.getFileEditorManager().getSelectedTextEditor();
                if (editor != null) {
                    this.selectIn(editor, currentPanel);
                }
            }
        }
    }
}
