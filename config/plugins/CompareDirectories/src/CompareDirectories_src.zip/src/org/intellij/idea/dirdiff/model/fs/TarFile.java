/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Collections;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.fs.tar.TarEntryIterator;

import com.intellij.util.containers.HashMap;

/**
 * This class represents a TAR archive file to be compared, either GZIP-ped or not.
 */
@SuppressWarnings({"FieldAccessedSynchronizedAndUnsynchronized", "SynchronizeOnNonFinalField"})
public class TarFile implements AbstractArchiveFile<TarEntry> {
    private final File       sourceFile;
    private RandomAccessFile file;
    private final boolean    gzipped;
    private boolean          debug;

    /** Maps name to actual entry. */
    private final Map<String, TarEntry> nameMap;

    /** UnGZipped file if the Tar is gzipped. */
    private File extractedTarFile;

    public TarFile(File file) throws IOException {
        final String fileName = file.getName();

        this.sourceFile = file;
        this.gzipped = (fileName.endsWith(".gz") || fileName.endsWith(".tgz"));
        if (this.gzipped) {
            this.unGzipFile();
        }
        this.ensureFileIsOpen();
        this.nameMap = Collections.synchronizedMap(new HashMap<String, TarEntry>(509));
        this.populateNameMap();
    }

    private void ensureFileIsOpen() throws IOException {
        if (this.file == null || !this.file.getFD().valid()) {
            this.file = new RandomAccessFile(this.gzipped ? this.extractedTarFile : this.sourceFile, "r");
        }
    }

    private void populateNameMap() throws IOException {
        final InputStream          inStream         = new FileInputStream(this.file.getFD());
        final TarEntryIterator     tarEntryIterator = new TarEntryIterator(inStream, this.debug);
        final TarVirtualFileSystem tarVFS           = new TarVirtualFileSystem(this);

        while (tarEntryIterator.hasNext()) {
            final TarEntry tarEntry = tarEntryIterator.next();

            tarEntry.setVirtualFileSystem(tarVFS);
            this.nameMap.put(tarEntry.getName(), tarEntry);
        }
    }

    public void unGzipFile() throws IOException {
        try {
            final FileInputStream fileStream = new FileInputStream(this.sourceFile);

            this.extractedTarFile = Files.extractTempFile(new GZIPInputStream(fileStream));
        } catch (IOException e) {
            CompareDirectoryPlugin.getLogger().error(e);
            throw e;
        }
    }

    public File getSourceFile() {
        return this.sourceFile;
    }

    public Iterable<TarEntry> getEntries() throws IOException {
        return this.nameMap.values();
    }

    public TarEntry getEntry(String name) {
        return this.nameMap.get(name);
    }

    public static boolean isChild(org.intellij.idea.dirdiff.model.fs.tar.TarEntry tarEntry,
                                  org.intellij.idea.dirdiff.model.fs.tar.TarEntry tarParentEntry) {
        final String tarParentEntryName = tarParentEntry.getName();

        if (!tarParentEntryName.endsWith("/")) {
            return false;
        }

        final String tarEntryName = tarEntry.getName();

        if (!tarEntryName.startsWith(tarParentEntryName)) {
            return false;
        }

        final int slashIndex = tarEntryName.indexOf('/', tarParentEntryName.length());

        return (slashIndex < 0 || slashIndex == tarEntryName.length() - 1);
    }

    public InputStream getInputStream(TarEntry tarEntry) throws IOException {
        return new BoundedInputStream(tarEntry.getOffset() + tarEntry.getHeaderSize(), tarEntry.getSize());
    }

    public void close() throws IOException {
        this.file.close();
    }

    public void finalizeIt() {
        try {
            if (this.file != null && this.file.getFD() != null && this.file.getFD().valid()) {
                this.file.close();
            }
            this.file = null;
        } catch (Exception e) {
            CompareDirectoryPlugin.getLogger().error(e);
        }

        if (this.gzipped && this.extractedTarFile != null) {
            try {
                this.extractedTarFile.delete();
            } catch (Exception e) {
                CompareDirectoryPlugin.getLogger().error(e);
            }
            this.extractedTarFile = null;
        }
    }

    /**
     * <code>InputStream</code> that delegates requests to the underlying
     * <code>RandomAccessFile</code>, making sure that only bytes from a
     * certain range can be read.
     */
    private class BoundedInputStream extends InputStream {
        private long    remaining;
        private long    loc;
        private boolean addDummyByte;

        BoundedInputStream(long start, long remaining) {
            this.remaining = remaining;
            this.loc       = start;
        }

        public int read() throws IOException {
            TarFile.this.ensureFileIsOpen();

            if (this.remaining-- <= 0) {
                if (this.addDummyByte) {
                    this.addDummyByte = false;
                    return 0;
                }
                return -1;
            }
            synchronized (TarFile.this.file) {
                TarFile.this.file.seek(this.loc++);
                return TarFile.this.file.read();
            }
        }

        public int read(byte[] b, int off, int len) throws IOException {
            TarFile.this.ensureFileIsOpen();

            if (this.remaining <= 0) {
                if (this.addDummyByte) {
                    this.addDummyByte = false;
                    b[off] = 0;
                    return 1;
                }
                return -1;
            }

            if (len <= 0) {
                return 0;
            }

            if (len > this.remaining) {
                len = (int) this.remaining;
            }

            final int ret;

            synchronized (TarFile.this.file) {
                TarFile.this.file.seek(this.loc);
                ret = TarFile.this.file.read(b, off, len);
            }
            if (ret > 0) {
                this.loc       += ret;
                this.remaining -= ret;
            }
            return ret;
        }

        /**
         * Inflater needs an extra dummy byte for nowrap - see
         * Inflater's javadocs.
         */
        void addDummy() {
            this.addDummyByte = true;
        }

        @Override public void close() throws IOException {
            synchronized (TarFile.this.file) {
                super.close();
            }
        }
    }
}