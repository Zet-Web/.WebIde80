/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;

import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.view.CompareDirectoryStatisticsDialog;
import org.jetbrains.annotations.Nullable;

/**
 */
public class ShowComparisonInfoActionDelegate extends AbstractActionDelegate {
    public void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        if (panel != null) {
            final Window    infoDialog = new CompareDirectoryStatisticsDialog(panel.getTreeModel());
            final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            final Dimension dialogSize = infoDialog.getPreferredSize();

            infoDialog.pack();
            infoDialog.setLocation((screenSize.width  - dialogSize.width)  / 2,
                                   (screenSize.height - dialogSize.height) / 2);

            infoDialog.setVisible(true);
        }
    }
}