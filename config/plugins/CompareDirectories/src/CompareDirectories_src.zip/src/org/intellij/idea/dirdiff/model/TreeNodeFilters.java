/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

/**
 */
public class TreeNodeFilters {

    public static final TreeNodeFilter identical                      = new TreeNodeStateFilter         (FileStateEnum.IDENTICAL);
    public static final TreeNodeFilter differentInBlanks              = new TreeNodeStateFilter         (FileStateEnum.DIFFERENT_IN_BLANKS);
    public static final TreeNodeFilter differentNonSignificant        = new TreeNodeStateFilter         (FileStateEnum.DIFFERENT_NON_SIGNIFICANT);
    public static final TreeNodeFilter different                      = new TreeNodeStateFilter         (FileStateEnum.DIFFERENT);
    public static final TreeNodeFilter leftOnly                       = new TreeNodeStateFilter         (FileStateEnum.LEFT_ONLY);
    public static final TreeNodeFilter rightOnly                      = new TreeNodeStateFilter         (FileStateEnum.RIGHT_ONLY);
    public static final TreeNodeFilter mostProbablyIdentical          = new TreeNodeStateFilter         (FileStateEnum.MOST_PROBABLY_IDENTICAL);
    public static final TreeNodeFilter probablyIdenticalAndLeftNewer  = new TreeNodeStateTimestampFilter(FileStateEnum.PROBABLY_IDENTICAL, false);
    public static final TreeNodeFilter probablyIdenticalAndRightNewer = new TreeNodeStateTimestampFilter(FileStateEnum.PROBABLY_IDENTICAL, true);
    public static final TreeNodeFilter probablyDifferentAndLeftNewer  = new TreeNodeStateTimestampFilter(FileStateEnum.PROBABLY_DIFFERENT, false);
    public static final TreeNodeFilter probablyDifferentAndRightNewer = new TreeNodeStateTimestampFilter(FileStateEnum.PROBABLY_DIFFERENT, true);
    public static final TreeNodeFilter javaStructure                  = new JavaStructureFilter();

    public static final TreeNodeFilter[] ALL_FILTERS = { identical, differentInBlanks,  differentNonSignificant, different,
                                                         leftOnly,  rightOnly,          mostProbablyIdentical,
                                                         probablyDifferentAndLeftNewer, probablyDifferentAndRightNewer,
                                                         probablyIdenticalAndLeftNewer, probablyIdenticalAndRightNewer,
                                                         javaStructure };

    private TreeNodeFilters() {}

    public static boolean isNotFiltered(ComparedTreeNode node, Iterable<TreeNodeFilter> filters) {
        for (TreeNodeFilter filter : filters) {
            if (!filter.accept(node)) {
                return false;
            }
        }
        return true;
    }

    /**
     * This node filter allows filtering nodes on their state.
     */
    private static class TreeNodeStateFilter implements TreeNodeFilter {
        protected final FileStateEnum state;

        public TreeNodeStateFilter(FileStateEnum state) {
            this.state = state;
        }

        public boolean accept(ComparedTreeNode node) {
            return (this.state != node.getState());
        }

        public boolean checkInitialState() {
            return this.state.isInitial();
        }

        @Override public String toString() {
            return this.state.getText();
        }
    }

    /**
     * This node filter allows filtering nodes on their state and timestamp.
     */
    private static class TreeNodeStateTimestampFilter extends TreeNodeStateFilter {
        protected final boolean rightNewer;

        public TreeNodeStateTimestampFilter(FileStateEnum state, boolean rightNewer) {
            super(state);
            this.rightNewer = rightNewer;
        }

        @Override public boolean accept(ComparedTreeNode node) {
            return (super.accept(node) || (this.rightNewer ^ node.compareTimestamps() < 0));
        }

        @Override public String toString() {
            return this.state.getText() + (this.rightNewer ? " (RIGHT NEWER)" : " (LEFT NEWER)");
        }
    }

    private static class JavaStructureFilter implements TreeNodeFilter {
        public boolean accept(ComparedTreeNode node) {
            return !(node instanceof JavaFieldTreeNode);
        }

        public boolean checkInitialState() {
            return false;
        }

        @Override public String toString() {
            return "Java structure";
        }
    }
}
