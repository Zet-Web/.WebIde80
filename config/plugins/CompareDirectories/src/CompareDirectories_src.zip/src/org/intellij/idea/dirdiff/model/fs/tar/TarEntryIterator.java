/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs.tar;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.io.InputStream;
import java.io.IOException;

import org.intellij.idea.dirdiff.model.fs.TarEntry;

/**
 * Provides a fast iterator through all the entries of a TAR file.
 */
public class TarEntryIterator implements Iterator<TarEntry> {
    private static final int RECORD_SIZE = TarBuffer.DEFAULT_RCDSIZE;

    private boolean           hasHitEOF;
    private TarEntry          currEntry;
    private final InputStream inStream;
    private final boolean     debug;

    public TarEntryIterator(InputStream inStream, boolean debug)
            throws IOException {
        this.inStream  = inStream;
        this.debug     = debug;
        this.currEntry = this.getNextEntry();
    }

    public boolean hasNext() {
        return (this.currEntry != null);
    }

    public TarEntry next() {
        final TarEntry entry = this.currEntry;

        if (entry == null) {
            throw new NoSuchElementException();
        }
        try {
            this.currEntry = this.getNextEntry();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return entry;
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }

    private TarEntry getNextEntry() throws IOException {
        if (this.hasHitEOF) {
            return null;
        }

        /**
         * Here I have tried skipping the entry size, I have tried
         * skipping entrysize - header size,
         * entrysize + header, and all seem to skip to some bizarre location!
         */
        long nextEntryOffset = 0;
        if (this.currEntry != null) {
            // Need to round out the number of records to be read to skip entry...
            final long numRecords = (this.currEntry.getSize() + (RECORD_SIZE - 1)) / RECORD_SIZE;

            if (numRecords > 0) {
                //noinspection ResultOfMethodCallIgnored
                this.inStream.skip(numRecords * RECORD_SIZE);
            }
            nextEntryOffset = this.currEntry.getOffset() + this.currEntry.getHeaderSize() + numRecords * RECORD_SIZE;
        }

        final byte[] headerBuf = new byte[RECORD_SIZE];

        // NOTE Apparently (with GZIPInputStream maybe?) we are able to
        //      read less then record size bytes in any given read(). So,
        //      we have to be persistent.
        int bufIndex    = 0;
        int bytesNeeded = RECORD_SIZE;

        while (bytesNeeded > 0) {
            final int numRead = this.inStream.read(headerBuf, bufIndex, bytesNeeded);

            if (numRead < 0) {
                this.hasHitEOF = true;
                break;
            }

            bufIndex    += numRead;
            bytesNeeded -= numRead;
        }

        // Check for "EOF block" of all zeros
        if (!this.hasHitEOF) {
            this.hasHitEOF = true;
            for (byte aHeaderBuf : headerBuf) {
                if (aHeaderBuf != 0) {
                    this.hasHitEOF = false;
                    break;
                }
            }
        }

        if (this.hasHitEOF) {
            this.currEntry = null;
        } else {
            try {
                this.currEntry = new TarEntry(headerBuf);
                this.currEntry.setOffset(nextEntryOffset);

                if (this.debug) {
                    final byte[] by = new byte[headerBuf.length];

                    for (int i = 0; i < headerBuf.length; i++) {
                        by[i] = (headerBuf[i] == 0 ? 0x20 : headerBuf[i]);
                    }
                    System.out.println('\n' + new String(by));
                }

                if (!(headerBuf[257] == 'u' && headerBuf[258] == 's' &&
                      headerBuf[259] == 't' && headerBuf[260] == 'a' &&
                      headerBuf[261] == 'r')) {
                    throw new InvalidHeaderException("header magic is not 'ustar', but '" +
                         (char) headerBuf[257] + (char) headerBuf[258] + (char) headerBuf[259] +
                         (char) headerBuf[260] + (char) headerBuf[261] + "', or (dec) " +
                         ((int) headerBuf[257]) + ", " +
                         ((int) headerBuf[258]) + ", " +
                         ((int) headerBuf[259]) + ", " +
                         ((int) headerBuf[260]) + ", " +
                         ((int) headerBuf[261]));
                }
            } catch (InvalidHeaderException ex) {
                this.currEntry = null;
                throw ex;
            }
        }

        return this.currEntry;
    }
}
