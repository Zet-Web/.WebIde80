/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.util;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.NotNull;

import com.intellij.openapi.Disposable;

/**
 * A dynamically extensible vector of bytes. This class is roughly equivalent to
 * a <code>DataOutputStream</code> on top of a <code>ByteArrayOutputStream</code>,
 * but is more efficient.
 * It is implemented as a self-expanding <code>ArrayList</code> of byte arrays.
 *
 * @author Olivier Descout
 */
@SuppressWarnings({"NumericCastThatLosesPrecision"})
public final class ByteVector implements Disposable {

    /**
     * The data block pool.
     */
    protected final Pool<byte[]> dataBlockPool;

    /**
     * The last data block of this vector.
     */
    protected byte[] dataBlock;

    /**
     * The full content of this vector (list of data blocks).
     * If <code>null</code>, the byte vector is only made of a single block: {@link #dataBlock}
     */
    protected List<byte[]> data;

    /**
     * The actual number of bytes in this vector.
     */
    protected int length;

    /**
     * The actual number of bytes in the data block.
     */
    protected int dataBlockLength;

    /**
     * Constructs a new {@link ByteVector} with a default initial
     * size.
     */
    public ByteVector(@NotNull Pool<byte[]> dataBlockPool) {
        this.dataBlockPool = dataBlockPool;
        this.dataBlock     = dataBlockPool.acquire();
    }

    /**
     * Puts a byte into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param b a byte.
     * @return this byte vector.
     */
    public ByteVector putByte(final int b) {
        if (this.dataBlockLength == this.dataBlock.length) {
            this.enlarge();
        }

        this.dataBlock[this.dataBlockLength++] = (byte) b;
        this.length++;

        return this;
    }

    /**
     * Puts a short into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param s a short.
     * @return this byte vector.
     */
    public ByteVector putShort(final int s) {
        if (this.dataBlockLength < this.dataBlock.length - 2) {
            this.dataBlock[this.dataBlockLength++] = (byte) (s >>> 8);
            this.dataBlock[this.dataBlockLength++] = (byte) (s      );
            this.length += 2;
            return this;
        }
        return this.putByte(s >>> 8)
                   .putByte(s);
    }

    /**
     * Puts an int into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param i an int.
     * @return this byte vector.
     */
    public ByteVector putInt(final int i) {
        final byte[] block       = this.dataBlock;
        int          blockLength = this.dataBlockLength;

        if (blockLength < block.length - 4) {
            block[blockLength++] = (byte) (i >>> 24);
            block[blockLength++] = (byte) (i >>> 16);
            block[blockLength++] = (byte) (i >>>  8);
            block[blockLength++] = (byte) (i       );

            this.dataBlockLength = blockLength;
            this.length         += 4;
            return this;
        }
        return this.putByte(i >>> 24)
                   .putByte(i >>> 16)
                   .putByte(i >>> 8)
                   .putByte(i);
    }

    /**
     * Puts a long into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param l a long.
     * @return this byte vector.
     */
    public ByteVector putLong(final long l) {
        final byte[] block       = this.dataBlock;
        int          blockLength = this.dataBlockLength;

        if (blockLength < block.length - 8) {
            block[blockLength++] = (byte) (l >>> 56);
            block[blockLength++] = (byte) (l >>> 48);
            block[blockLength++] = (byte) (l >>> 40);
            block[blockLength++] = (byte) (l >>> 32);
            block[blockLength++] = (byte) (l >>> 24);
            block[blockLength++] = (byte) (l >>> 16);
            block[blockLength++] = (byte) (l >>>  8);
            block[blockLength++] = (byte) (l       );

            this.dataBlockLength = blockLength;
            this.length         += 8;
            return this;
        }
        return this.putInt((int) (l >>> 32))
                   .putInt((int) (l       ));
    }

    /**
     * Puts a float into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param f a float.
     * @return this byte vector.
     */
    public ByteVector putFloat(final float f) {
        return this.putInt(Float.floatToRawIntBits(f));
    }

    /**
     * Puts a double into this byte vector. The byte vector is automatically
     * enlarged if necessary.
     *
     * @param d a double.
     * @return this byte vector.
     */
    public ByteVector putDouble(final double d) {
        return this.putLong(Double.doubleToRawLongBits(d));
    }

    /**
     * Puts an Unicode string into this byte vector. The byte vector is
     * automatically enlarged if necessary.
     *
     * @param s a char sequence.
     * @return this byte vector.
     */
    public ByteVector putString(final CharSequence s) {
        final int    charLength  = s.length();
        final int    numBytes    = (2 + charLength) << 1;
        final byte[] block       = this.dataBlock;
        int          blockLength = this.dataBlockLength;

        if (blockLength < block.length - numBytes) {
            block[blockLength++] = (byte) (charLength >>> 24);
            block[blockLength++] = (byte) (charLength >>> 16);
            block[blockLength++] = (byte) (charLength >>>  8);
            block[blockLength++] = (byte)  charLength;

            for (int index = 0; index < charLength; index++) {
                final int c = (int) s.charAt(index);
                block[blockLength++] = (byte) (c >>> 8);
                block[blockLength++] = (byte)  c;
            }
            this.dataBlockLength = blockLength;
            this.length         += numBytes;
        } else {
            this.putInt(charLength);
            for (int index = 0; index < charLength; index++) {
                this.putShort((int) s.charAt(index));
            }
        }
        return this;
    }

    /**
     * Puts an UTF8 string into this byte vector. The byte vector is
     * automatically enlarged if necessary.
     *
     * @param s a char sequence.
     * @return this byte vector.
     */
    public ByteVector putUTF8(final CharSequence s) {
        final int charLength = s.length();
        int       byteLength = charLength;

        // Optimistic algorithm: instead of computing the byte length and then
        // serializing the string (which requires two loops), we assume the byte
        // length is equal to char length (which is the most frequent case), and
        // we start serializing the string right away. During the serialization,
        // if we find that this assumption is wrong, we fix the byte-length
        // computed value and end up fixing the serialized length.
        this.putInt(charLength);
        for (int index = 0; index < charLength; index++) {
            final char c = s.charAt(index);

            if ((c & 0xFF80) == 0) {
                this.putByte(c);
            } else if ((c & 0xF800) == 0) {
                byteLength++;
                this.putByte(0xC0 | (c >> 6) & 0x1F)
                    .putByte(0x80 | (c     ) & 0x3F);
            } else {
                byteLength += 2;
                this.putByte(0xE0 | (c >> 12) & 0x0F)
                    .putByte(0x80 | (c >>  6) & 0x3F)
                    .putByte(0x80 | (c      ) & 0x3F);
            }
        }

        // Fix byte length if multi-byte character present
        if (charLength != byteLength) {
            this.replaceInt(this.length - byteLength - 4, byteLength);
        }

        return this;
    }

    /**
     * Puts bytes into this byte vector. The byte vector is
     * automatically enlarged if necessary.
     *
     * @param bytes the bytes.
     * @return this byte vector.
     */
    public ByteVector putBytes(final byte... bytes) {
        final int len = bytes.length;

        if (this.dataBlockLength + len < this.dataBlock.length) {
            System.arraycopy(bytes, 0, this.dataBlock, this.dataBlockLength, len);
            this.dataBlockLength += len;
        } else {
            final int partialLength = bytes.length - this.dataBlockLength;

            System.arraycopy(bytes, 0,             this.dataBlock, this.dataBlockLength, partialLength);
            this.enlarge();
            System.arraycopy(bytes, partialLength, this.dataBlock, 0,                    bytes.length - partialLength);
        }
        this.length += len;

        return this;
    }

    /**
     * Puts an array of bytes into this byte vector. The byte vector is
     * automatically enlarged if necessary.
     *
     * @param b an array of bytes. May be <tt>null</tt> to put <tt>len</tt>
     *        null bytes into this byte vector.
     * @param off index of the fist byte of b that must be copied.
     * @param len number of bytes of b that must be copied.
     * @return this byte vector.
     */
    public ByteVector putByteArray(final byte[] b, final int off, final int len) {
        if (b != null && len > 0) {
            final int numFreeBytes = this.dataBlock.length - len;

            if (numFreeBytes < len) {
                System.arraycopy(b, off, this.dataBlock, this.dataBlockLength, len);
                this.dataBlockLength += len;
            } else {
                System.arraycopy(b, off, this.dataBlock, this.dataBlockLength, numFreeBytes);
                this.enlarge();
                this.dataBlockLength = len - numFreeBytes;
                System.arraycopy(b, off + numFreeBytes, this.dataBlock, 0, this.dataBlockLength);
            }
            this.length += len;
        }
        return this;
    }

    /**
     * Enlarge this byte vector so that it can receive more bytes.
     */
    private void enlarge() {
        if (this.data == null) {
            this.data = new ArrayList<byte[]>();
            this.data.add(this.dataBlock);
        }

        this.dataBlock       = this.dataBlockPool.acquire();
        this.dataBlockLength = 0;
        this.data.add(this.dataBlock);
    }

    public byte[] getData() {
        if (this.data == null) {
            return this.dataBlock;
        }

        final byte[] fullData  = new byte[this.length];
        final int    numBlocks = this.data.size() - 1;
        int          byteIndex = 0;

        for (int i = 0; i < numBlocks; i++) {
            final byte[] block       = this.data.get(i);
            final int    blockLength = block.length;

            System.arraycopy(block, 0, fullData, byteIndex, blockLength);
            byteIndex += blockLength;
        }
        System.arraycopy(this.dataBlock, 0, fullData, byteIndex, this.dataBlockLength);

        return fullData;
    }

    private void replaceInt(int position, final int n) {
        if (position < 0 || position > this.length - 1) {
            throw new IndexOutOfBoundsException(Integer.toString(position));
        }

        int    blockIndex = 0;
        byte[] block;

        if (this.data == null) {
            block = this.dataBlock;
        } else {
            block = this.data.get(blockIndex);
            while (position - block.length >= 0) {
                position -= block.length;
                block = this.data.get(++blockIndex);
            }
        }

        final int partialLength = block.length - position;

        // Is the next int fully stored in this block?
        if (partialLength >= 4) {
            block[position++] = (byte) (n >>> 24);
            block[position++] = (byte) (n >>> 16);
            block[position++] = (byte) (n >>> 8);
            block[position]   = (byte)  n;
        } else {
            final byte[] newBytes = { (byte) (n >>> 24), (byte) (n >>> 16), (byte) (n >>> 8), (byte) n };

            if (this.data == null) {
                this.enlarge();
            }
            System.arraycopy(newBytes, 0,             block,                         position, partialLength);
            System.arraycopy(newBytes, partialLength, this.data.get(blockIndex + 1), 0,        4 - partialLength);
        }
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }

        final ByteVector that       = (ByteVector) o;
        final int        thisLength = this.length;

        if (thisLength != that.length) {
            return false;
        }

        if (this.data != null) {
            final int numBlocks = this.data.size() - 1;

            for (int i = 0; i < numBlocks; i++) {
                final byte[] block       = this.data.get(i);
                final int    blockLength = block.length;

                if (!equalBlocks(block, that.data.get(i), blockLength)) {
                    return false;
                }
            }
        }

        return equalBlocks(this.dataBlock, that.dataBlock, this.dataBlockLength);
    }

    private static boolean equalBlocks(byte[] thisData, byte[] thatData, int length) {
        for (int index = length; --index >= 0; ) {
            if (thisData[index] != thatData[index]) {
                return false;
            }
        }

        return true;
    }

    @Override public int hashCode() {
        int result = 1;

        if (this.data != null) {
            final int numBlocks = this.data.size() - 1;

            for (int i = 0; i < numBlocks; i++) {
                final byte[] block = this.data.get(i);

                result = blockHashCode(result, block, block.length);
            }
        }

        return blockHashCode(result, this.dataBlock, this.dataBlockLength);
    }

    private static int blockHashCode(int result, byte[] block, int length) {
        for (int index = 0; index < length; index++) {
            result = 31 * result + block[index];
        }
        return result;
    }

    public void dispose() {
        if (this.data == null) {
            this.dataBlockPool.dispose(this.dataBlock);
        } else {
            for (byte[] dataBlock : this.data) {
                this.dataBlockPool.dispose(dataBlock);
            }
            this.data = null;
        }

        this.dataBlock       = null;
        this.dataBlockLength = 0;
        this.length          = 0;
    }
}