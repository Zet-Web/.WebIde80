/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import java.awt.event.InputEvent;
import java.io.File;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.util.Commands;
import org.intellij.idea.dirdiff.model.ComparisonParameters;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.model.ZipEntryFile;
import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.CompareDirectoryView;
import org.intellij.idea.dirdiff.view.PanelConfiguration;
import org.intellij.idea.dirdiff.view.SelectDialogWrapper;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataKeys;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.ToolWindow;

/**
 */
public abstract class CompareDirectoryAction extends AnAction implements ACompareDirectoryAction {

    private CompareDirectoryView  view;

    protected static Project getProject(AnActionEvent event) {
        return DataKeys.PROJECT.getData(event.getDataContext());
    }

    @Nullable private CompareDirectoryView getView(AnActionEvent event) {
        final Project              project              = getProject(event);
        final CompareDirectoryView compareDirectoryView = CompareDirectoryPlugin.getView(project);

        if (compareDirectoryView != null) {
            this.view = compareDirectoryView;
            return compareDirectoryView;
        }

        // Try to recover...
        return ((project != null && this.view != null && project.equals(this.view.getProject())) ? this.view : null);
    }

    @Nullable public CompareDirectoryPanel getPanel(AnActionEvent event) {
        final CompareDirectoryView view = this.getView(event);

        return ((view == null) ? null : view.getCurrentPanel());
    }

    public static void update(AnActionEvent event, VirtualFile[] files) {
        final Project       project      = DataKeys.PROJECT.getData(event.getDataContext());
        final Presentation  presentation = event.getPresentation();
        final String        textKey      = (files == null || files.length == 0 ? "title.tool-window.0" :
                                            files.length == 1                  ? "title.tool-window.1" :
                                            files.length == 2                  ? "title.tool-window.2"
                                                                               : null);
        final boolean       visible      = (textKey != null);
	    boolean             directory    = true;

        if (visible && files != null) {
            for (VirtualFile file : files) {
                directory &= (file.isDirectory() || file.getFileType().equals(StdFileTypes.ARCHIVE));
            }
        }

        presentation.setVisible(visible);
        presentation.setEnabled(project != null);
        presentation.setText((textKey == null) ? null : CompareDirectoryBundle.message(textKey + (directory ? ".dir" : ".file")));
    }

    public void actionPerformed(AnActionEvent event, VirtualFile[] files) {
        final Project              project        = getProject(event);
        final CompareDirectoryView view           = this.getView(event);
        final boolean              compareAnyFile = ((event.getModifiers() & InputEvent.SHIFT_MASK) != 0);

        if (view == null || project == null) {
            return;
        }

        final PanelConfiguration   configuration = view.getLastConfiguration();
        final File                 leftFile;
        final File                 rightFile;
        final ComparisonParameters parameters;

        final CompareDirectoryPanel panel = this.view.getCurrentPanel();
        if (panel != null) {
            panel.getManager().refreshCachedFiles();
        }
        if (files == null || files.length < 2) {
            final String              leftFilePath  = ((files == null || files.length == 0) ? null : files[0].getPath());
            final SelectDialogWrapper dialogWrapper = new SelectDialogWrapper(project, leftFilePath, leftFilePath,
                                                                              (leftFilePath != null), false,
                                                                              configuration.getLastLeftPaths(),
                                                                              configuration.getLastRightPaths(),
                                                                              compareAnyFile);

            dialogWrapper.show();
            if (!dialogWrapper.isOK()) {
                return;
            }

            leftFile   = dialogWrapper.getLeftDirectory();
            rightFile  = dialogWrapper.getRightDirectory();
            parameters = new ComparisonParameters(dialogWrapper.isByteComparison(),
                                                  dialogWrapper.isClassAnalysis(),
                                                  false);
        } else if (files.length > 2) {
            return;
        } else {
            leftFile   = new File(files[0].getPath());
            rightFile  = new File(files[1].getPath());
            parameters = new ComparisonParameters();
        }

        if (!(checkFileExists(project, leftFile) &&
              checkFileExists(project, rightFile))) {
            return;
        }

        configuration.addLastLeftPath (leftFile .getAbsolutePath());
        configuration.addLastRightPath(rightFile.getAbsolutePath());

        doCompare(FileTreeNode.getReadableFile(leftFile), FileTreeNode.getReadableFile(rightFile),
                  view.addPanel(parameters), CompareDirectoryPlugin.getToolWindow(project));
    }

    private static boolean checkFileExists(Project project, File file) {
        File             checkedFile          = file;
        final String     path                 = ((file == null) ? null : file.getAbsolutePath());
        final Integer[]  archiveFileSignIndex = { (path == null) ? -1 : path.indexOf(JarFileSystem.JAR_SEPARATOR),
                                                  (path == null) ? -1 : path.indexOf(ZipEntryFile.ZIP_PATH_SEPARATOR) };

        for (Integer index : archiveFileSignIndex) {
            if (index >= 0) {
                //noinspection ConstantConditions
                checkedFile = new File(path.substring(0, index));
                break;
            }
        }

        if (checkedFile == null || !checkedFile.exists()) {
            Commands.showWarningDialog(project,
                                       CompareDirectoryBundle.message("error.file.not-exist", (checkedFile == null) ? "" : checkedFile.getAbsolutePath()),
                                       CompareDirectoryBundle.message("error.title"));
            return false;
        }

        return true;
    }

    public static void doCompare(ReadableFile leftFile, ReadableFile rightFile,
                                 CompareDirectoryPanel panel, ToolWindow toolWindow) {
        final FileTreeNode treeRoot = panel.getTreeModel().createRootNode(leftFile, rightFile);

        if (treeRoot != null) {
            panel.getView().setLastPanelTitle(treeRoot.getName());
            toolWindow.setAvailable(true, null);
            if (toolWindow.isActive()) {
                toolWindow.show(panel.getView());
            } else {
                toolWindow.activate(panel.getView());
            }
            panel.setCurrentTree(treeRoot, panel.getComparisonParameters());
        }
    }
}
