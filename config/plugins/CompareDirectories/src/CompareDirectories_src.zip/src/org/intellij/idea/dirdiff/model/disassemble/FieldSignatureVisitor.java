/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.ArrayList;
import java.util.List;

import com.intellij.openapi.Disposable;
import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.signature.SignatureReader;
import org.jetbrains.asm4.signature.SignatureVisitor;

/**
 *
 */
class FieldSignatureVisitor extends SignatureVisitor implements Disposable {

    private static final String EXTENDS_OBJECT = " extends Object";

    private final Printer                     printer;
    private final MyClassVisitorContext       context;
    private       StringBuilder               localBuilder;
    private final FullClassVisitor            classVisitor;
    private final Printer                     parentPrinter;
    private final boolean                     classBound;
    private       int                         parameterIndex;
    private       int                         arrayLevel;
    private       List<FieldSignatureVisitor> typeArguments;
    private       boolean                     endVisited;

    public FieldSignatureVisitor(FullClassVisitor classVisitor, @NotNull MyClassVisitorContext context) {
        this(classVisitor, classVisitor.getPrinter(), context);
    }

    /*package*/ FieldSignatureVisitor(FullClassVisitor classVisitor, Printer parentPrinter, @NotNull MyClassVisitorContext context) {
        super(Opcodes.ASM4);
        this.localBuilder  = context.allocateBuilder();
        this.printer       = new Printer(this.localBuilder);
        this.context       = context;
        this.classVisitor  = classVisitor;
        this.parentPrinter = parentPrinter;
        this.classBound    = false;
    }

    /*package*/ FieldSignatureVisitor(FullClassVisitor classVisitor, @NotNull MyClassVisitorContext context, boolean classBound, boolean firstFormalTypeParameter, StringBuilder buffer) {
        super(Opcodes.ASM4);
        this.printer       = new Printer(buffer);
        this.context       = context;
        this.classVisitor  = classVisitor;
        this.parentPrinter = null;
        this.classBound    = classBound;
        if (classBound && firstFormalTypeParameter) {
            this.printer.insert(0, "<");
        }
    }

    private FieldSignatureVisitor createTypeArgument(FullClassVisitor fullClassVisitor, Printer parentPrinter, @NotNull MyClassVisitorContext context) {
        if (this.typeArguments == null) {
            this.typeArguments = new ArrayList<FieldSignatureVisitor>(5);
        }

        final FieldSignatureVisitor typeArgument = new FieldSignatureVisitor(fullClassVisitor, parentPrinter, context);

        this.typeArguments.add(typeArgument);
        return typeArgument;
    }

    public static String getTypeName(@NotNull String signature, @NotNull MyClassVisitorContext context) {
        final StringBuilder         fieldTypeBuilder = context.allocateBuilder();
        final FieldSignatureVisitor typePrinter      = new FieldSignatureVisitor(null, context, false, false, fieldTypeBuilder);
        final String                typeName;

        new SignatureReader(signature).acceptType(typePrinter);
        if (!typePrinter.endVisited) {
            typePrinter.visitEndNoDispose();
        }
        typeName = fieldTypeBuilder.toString();
        context.disposeBuilder(fieldTypeBuilder);
        return typeName;
    }

    @Override public void visitClassType(String name) {
        final String qualifiedName = AsmUtil.getQualified(name);
        this.printer.append((this.classVisitor == null) ? AsmUtil.getSimpleClassName(qualifiedName)
                                                        : this.classVisitor.ensureClassImported(qualifiedName));
    }

    @Override public SignatureVisitor visitTypeArgument(char wildcard) {
        this.printer.append((this.parameterIndex == 0 || this.classBound) ? "<" : ", ");

        if (wildcard != SignatureVisitor.INSTANCEOF) {
            this.printer.append((wildcard == SignatureVisitor.EXTENDS) ? "? extends " : "? super ");
        }
        this.parameterIndex++;
        return this.createTypeArgument(this.classVisitor, this.printer, this.context);
    }

    @Override public void visitBaseType(char descriptor) {
        this.printer.append(VarType.valueOf(descriptor).getTypeName());
    }

    @Override public void visitInnerClassType(String name) {
        if (this.typeArguments != null) {
            for (FieldSignatureVisitor typeArgument : this.typeArguments) {
                typeArgument.visitEnd();
            }
            this.typeArguments.clear();
        }
        if (this.parameterIndex > 0) {
            this.printer.append('>');
            this.parameterIndex = 0;
        }

        this.printer.append(".", name);
    }

    @Override public void visitTypeVariable(String name) {
        final Printer printer = (this.parentPrinter == null) ? this.printer : this.parentPrinter;
        printer.append(name);
    }

    @Override public void visitFormalTypeParameter(String name) {
        final Printer printer = (this.parentPrinter == null) ? this.printer : this.parentPrinter;
        printer.append(name);
    }

    @Override public void visitTypeArgument() {
        this.printer.append((this.parameterIndex > 0)   ? ", ?" :
                            (this.printer.length() > 0) ? "<?"
                                                        : "?");
        this.parameterIndex++;
    }

    @Override public SignatureVisitor visitArrayType() {
        this.arrayLevel++;
        return this;
    }

    public void visitEndNoDispose() {
        if (this.typeArguments != null) {
            for (FieldSignatureVisitor typeArgument : this.typeArguments) {
                typeArgument.visitEnd();
            }
        }

        for (int index = 0; index < this.arrayLevel; index++) {
            this.printer.append("[]");
        }
        if (this.parameterIndex > 0) {
            this.printer.append('>');
        }
        if (this.classBound) {
            // No need to make a generic parameter extend Object (which is assumed to be java.lang.Object).
            if (this.printer.endsWith(EXTENDS_OBJECT)) {
                this.printer.truncate(this.printer.length() - EXTENDS_OBJECT.length());
            }
            this.printer.append('>');
        }

        if (this.printer.length() > 0) {
            if (this.parentPrinter != null) {
                this.parentPrinter.append(this.printer.toString());
            } else if (this.classBound && this.classVisitor != null) {
                this.classVisitor.getPrinter().append(this.printer.toString(), Printer.SPACE);
            }
        }
    }

    @Override public void visitEnd() {
        if (!this.endVisited) {
            this.visitEndNoDispose();
            this.dispose();
            this.endVisited = true;
        }
    }

    public void dispose() {
        if (this.localBuilder != null) {
            this.context.disposeBuilder(this.localBuilder);
            this.localBuilder = null;
        }
    }

    @Override public String toString() {
        return this.printer.toString();
    }

    @Override public SignatureVisitor visitClassBound    () { return null; }
    @Override public SignatureVisitor visitInterfaceBound() { return null; }
    @Override public SignatureVisitor visitSuperclass    () { return null; }
    @Override public SignatureVisitor visitInterface     () { return null; }
    @Override public SignatureVisitor visitParameterType () { return null; }
    @Override public SignatureVisitor visitReturnType    () { return null; }
    @Override public SignatureVisitor visitExceptionType () { return null; }
}