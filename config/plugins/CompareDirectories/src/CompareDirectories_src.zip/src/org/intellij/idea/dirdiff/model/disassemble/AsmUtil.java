/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

@SuppressWarnings ({ "TypeMayBeWeakened", "HardCodedStringLiteral" })
public class AsmUtil {
    private static final String PUBLIC_VISIBILITY     = "public ";
    private static final String PRIVATE_VISIBILITY    = "private ";
    private static final String PROTECTED_VISIBILITY  = "protected ";
    private static final String PACKAGE_VISIBILITY    = "";
    private static final String ABSTRACT_MODIFIER     = "abstract ";
    private static final String STATIC_MODIFIER       = "static ";
    private static final String FINAL_MODIFIER        = "final ";
    private static final String NATIVE_MODIFIER       = "native ";
    private static final String VOLATILE_MODIFIER     = "volatile ";
    private static final String SYNCHRONIZED_MODIFIER = "synchronized ";
    private static final String TRANSIENT_MODIFIER    = "transient ";
    private static final String STRICT_MODIFIER       = "strictfp ";
    private static final String INTERFACE_UNIT        = "interface ";
    private static final String ANNOTATION_UNIT       = "@interface ";
    private static final String CLASS_UNIT            = "class ";
    private static final String ENUM_UNIT             = "enum ";
    private static final String JAVA_LANG_PACKAGE     = "java.lang";
    private static final String OBJECT_CLASS          = "java.lang.Object";
    private static final String STRING_CLASS          = "java.lang.String";
    private static final String STRING_TYPE_NAME      = "java/lang/String";
    private static final String CLASS_CLASS           = "java.lang.Class";
    private static final String CONSTRUCTOR_NAME      = "<init>";
    private static final String STATIC_INIT_NAME      = "<clinit>";
    private static final String ACCESS_METHOD         = "access$";
    private static final String LAMBDA_METHOD         = "lambda$";

    // Opcodes.V1_8 = 52 in ASM v4 and above and this file should compile with IDEA 13 bundled with ASM v3.3 only
    private static final int    Opcodes_JAVA_V1_8     = 52;
    private static final int    Opcodes_JAVA_V1_9     = 53;
    private static final int    Opcodes_JAVA_V1_10    = 54;


    private AsmUtil() {
    }

    private static boolean checkBits(int bits, int mask) {
        return ((bits & mask) == mask);
    }

    public static String getVersionAsText(int version) {
        switch (version) {
            case Opcodes.V1_1:       return "1.1";
            case Opcodes.V1_2:       return "1.2";
            case Opcodes.V1_3:       return "1.3";
            case Opcodes.V1_4:       return "1.4";
            case Opcodes.V1_5:       return "1.5";
            case Opcodes.V1_6:       return "1.6";
            case Opcodes.V1_7:       return "1.7";
            case Opcodes_JAVA_V1_8:  return "1.8";
            case Opcodes_JAVA_V1_9:  return "1.9";
            case Opcodes_JAVA_V1_10: return "1.10";
            default:                 return "1.0";
        }
    }

    public static int getVersion(int version) {
        switch (version) {
            case Opcodes.V1_1:       return 11;
            case Opcodes.V1_2:       return 12;
            case Opcodes.V1_3:       return 13;
            case Opcodes.V1_4:       return 14;
            case Opcodes.V1_5:       return 15;
            case Opcodes.V1_6:       return 16;
            case Opcodes.V1_7:       return 17;
            case Opcodes_JAVA_V1_8:  return 18;
            case Opcodes_JAVA_V1_9:  return 19;
            case Opcodes_JAVA_V1_10: return 20;
            default:                 return 10;
        }
    }

    public static String getVisibility(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_PUBLIC)    ? PUBLIC_VISIBILITY   :
                checkBits(accessFlags, Opcodes.ACC_PRIVATE)   ? PRIVATE_VISIBILITY  :
                checkBits(accessFlags, Opcodes.ACC_PROTECTED) ? PROTECTED_VISIBILITY
                                                              : PACKAGE_VISIBILITY);
    }

    public static String getAbstractModifier(int accessFlags) {
        return (isAbstract(accessFlags) ? ABSTRACT_MODIFIER : "");
    }

    public static String getStaticModifier(int accessFlags) {
        return (isStatic(accessFlags) ? STATIC_MODIFIER : "");
    }

    public static String getFinalModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_FINAL) ? FINAL_MODIFIER : "");
    }

    public static String getNativeModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_NATIVE) ? NATIVE_MODIFIER : "");
    }

    public static String getSynchronizedModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_SYNCHRONIZED) ? SYNCHRONIZED_MODIFIER : "");
    }

    public static String getTransientModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_TRANSIENT) ? TRANSIENT_MODIFIER : "");
    }

    public static String getVolatileModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_VOLATILE) ? VOLATILE_MODIFIER : "");
    }

    public static String getStrictFpModifier(int accessFlags) {
        return (checkBits(accessFlags, Opcodes.ACC_STRICT) ? STRICT_MODIFIER : "");
    }

    public static String getCompilationUnit(int accessFlags) {
        return (isAnnotation(accessFlags) ? ANNOTATION_UNIT :
                isInterface (accessFlags) ? INTERFACE_UNIT :
                isEnum      (accessFlags) ? ENUM_UNIT
                                          : CLASS_UNIT);
    }

    public static boolean isAbstract(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_ABSTRACT);
    }

    public static boolean isStatic(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_STATIC);
    }

    public static boolean isFinal(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_FINAL);
    }

    public static boolean isNative(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_NATIVE);
    }

    public static boolean isConstant(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_STATIC | Opcodes.ACC_FINAL);
    }

    public static boolean isPublicConstant(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_FINAL);
    }

    public static boolean isPrivateConstant(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC | Opcodes.ACC_FINAL);
    }

    public static boolean isInterface(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_INTERFACE);
    }

    public static boolean isEnum(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_ENUM);
    }

    public static boolean isAnnotation(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_ANNOTATION);
    }

    public static boolean isSynthetic(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_SYNTHETIC);
    }

    public static boolean isDeprecated(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_DEPRECATED);
    }

    public static boolean isVarArgs(int accessFlags) {
        return checkBits(accessFlags, Opcodes.ACC_VARARGS);
    }

    public static boolean isArrayType(String type) {
        return (type == null || type.endsWith("[]"));
    }

    public static boolean isJavaLangPackage(String classPackage) {
        return JAVA_LANG_PACKAGE.equals(classPackage);
    }

    public static boolean isObjectClass(String className) {
        return OBJECT_CLASS.equals(className);
    }

    public static boolean isStringClass(String className) {
        return STRING_CLASS.equals(className);
    }

    public static boolean isStringType(Type type) {
        return (type.getSort() == Type.OBJECT && type.getDimensions() == 0 &&
                STRING_TYPE_NAME.equals(type.getInternalName()));
    }

    public static boolean isClassClass(String className) {
        return CLASS_CLASS.equals(className);
    }

    public static boolean isConstructor(String methodName) {
        return CONSTRUCTOR_NAME.equals(methodName);
    }

    public static boolean isStaticInitializer(String methodName) {
        return STATIC_INIT_NAME.equals(methodName);
    }

    public static boolean isSynthetic(String name) {
        return (name != null && name.indexOf('$') >= 0);
    }

    public static boolean isLambdaMethod(String methodName) {
        return (methodName != null && methodName.startsWith(LAMBDA_METHOD));
    }

    public static boolean isAccessSyntheticMethod(String methodName) {
        return (methodName != null && methodName.startsWith(ACCESS_METHOD));
    }

    public static boolean isInnerClass(String className) {
        return isSynthetic(className);
    }

    public static String getOuterClass(String className) {
        if (className == null) {
            return null;
        }

        final int index = className.indexOf('$');

        if (index < 0) {
            return className;
        }

        final String outerClassName = className.substring(0, index);
        return (className.endsWith(".class")) ? outerClassName.concat(".class") : outerClassName;
    }

    public static String getInnerClass(String className) {
        if (className == null) {
            return null;
        }

        final int index = className.indexOf('$');

        return (index < 0) ? className : className.substring(index + 1);
    }

    public static String getSimpleClassName(String qualifiedClassName) {
        final int    lastSeparatorIndex = qualifiedClassName.lastIndexOf('.');
        final String className          = (lastSeparatorIndex < 0) ? qualifiedClassName : qualifiedClassName.substring(lastSeparatorIndex + 1);

        return className.replace('$', '.');
    }

    public static String getClassPackage(String qualifiedClassName) {
        final int lastSeparatorIndex = qualifiedClassName.lastIndexOf('.');

        return (lastSeparatorIndex < 0) ? null : qualifiedClassName.substring(0, lastSeparatorIndex);
    }

    public static String getQualified(String slashed) {
        return slashed.replace('/', '.');
    }

    /**
     * Quotes and returns this string literal.
     *
     * @param literal the string to be quoted.
     * @return the quoted string
     */
    public static String getStringLiteral(final CharSequence literal, MyClassVisitorContext context) {
        final StringBuilder buffer = context.allocateBuilder();
        final int           length = literal.length();

        buffer.append('\"');
        for (int i = 0; i < length; i++) {
            final char c = literal.charAt(i);

            switch (c) {
                case '\n': buffer.append("\\n");  break;
                case '\r': buffer.append("\\r");  break;
                case '\\': buffer.append("\\\\"); break;
                case '"':  buffer.append("\\\""); break;

                default:
                    if (c < 0x20 || c > 0x7f) {
                        buffer.append("\\u");
                        if (c < 0x10) {
                            buffer.append("000");
                        } else if (c < 0x100) {
                            buffer.append("00");
                        } else if (c < 0x1000) {
                            buffer.append('0');
                        }
                        buffer.append(Integer.toString(c, 16));
                    } else {
                        buffer.append(c);
                    }
                    break;
            }
        }

        final String stringLiteral = buffer.append('\"').toString();

        context.disposeBuilder(buffer);
        return stringLiteral;
    }

}
