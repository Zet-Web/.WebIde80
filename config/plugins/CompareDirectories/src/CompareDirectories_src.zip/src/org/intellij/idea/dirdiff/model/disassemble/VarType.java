/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.jetbrains.asm4.Type;

enum VarType {
    INT    ('I',  'I',  "i",     "int"),
    LONG   ('J',  'L',  "l",     "long"),
    FLOAT  ('F',  'F',  "f",     "float"),
    DOUBLE ('D',  'D',  "d",     "double"),
    OBJECT ('A',  'A',  "o",     "Object"),
    BYTE   ('B',  'B',  "b",     "byte"),
    SHORT  ('S',  'S',  "short", "short"),
    CHAR   ('C',  'C',  "c",     "char"),
    BOOLEAN('Z',  'Z',  "flag",  "boolean"),
    VOID   ('V',  'V',  "x",     "void");

    private final char   scrambledTypeLetter;
    private final char   opcodePrefixTypeLetter;
    private final String varNamePrefix;
    private final String typeName;

    private VarType(char scrambledTypeLetter, char opcodePrefixTypeLetter, String varNamePrefix, String typeName) {
        this.scrambledTypeLetter    = scrambledTypeLetter;
        this.opcodePrefixTypeLetter = opcodePrefixTypeLetter;
        this.varNamePrefix          = varNamePrefix;
        this.typeName               = typeName;
    }

    public String getTypeName(String variableTypeName) {
        if (variableTypeName != null && Character.isUpperCase(variableTypeName.charAt(0))) {
            return variableTypeName;
        }
        return this.typeName;
    }

    public String getTypeName() {
        return this.typeName;
    }

    public char getOpcodePrefixTypeLetter() {
        return this.opcodePrefixTypeLetter;
    }

    public static boolean isClassName(CharSequence typeName) {
        return (typeName != null && Character.isUpperCase(typeName.charAt(0)));
    }

    public String getVariableName(String typeName, int suffix, MyClassVisitorContext context) {
        if (!isClassName(typeName)) {
            return this.varNamePrefix.concat(Integer.toString(suffix));
        }
        if (AsmUtil.isStringClass(typeName) || AsmUtil.isObjectClass(typeName)) {
            return Character.toLowerCase(typeName.charAt(0)) + Integer.toString(suffix);
        }

	    // Remove array type suffix and generic parameters if any.
        int           typeNameLength        = typeName.length();
        final boolean plural                = (typeName.charAt(typeNameLength - 1) == ']');
        final int     genericParameterIndex = typeName.indexOf('<');

        if (genericParameterIndex >= 0) {
            typeNameLength = genericParameterIndex;
        } else if (plural) {
            do {
                typeNameLength -= 2;
            } while (typeNameLength > 1 && typeName.charAt(typeNameLength - 1) == ']');
        }

        final StringBuilder builder = context.allocateBuilder();
        final String        name    = builder.append(Character.toLowerCase(typeName.charAt(0)))
                                             .append(typeName, 1, typeNameLength)
                                             .append(plural ? "s" : "")
                                             .append(suffix)
                                             .toString();

        context.disposeBuilder(builder);
        return name;
    }

    public boolean isDoubleWord() {
        return (this == LONG || this == DOUBLE);
    }

    public static VarType valueOf(char scrambledTypeLetter) {
        for (VarType varType : values()) {
            if (varType.scrambledTypeLetter == scrambledTypeLetter) {
                return varType;
            }
        }
        return null;
    }

    public static VarType valueOfOpcodeType(char opcodePrefixTypeLetter) {
        for (VarType varType : values()) {
            if (varType.opcodePrefixTypeLetter == opcodePrefixTypeLetter) {
                return varType;
            }
        }
        return null;
    }

    public static VarType valueOfType(CharSequence type) {
        return ("float"  .equals(type) ? VarType.FLOAT  :
                "long"   .equals(type) ? VarType.LONG   :
                "double" .equals(type) ? VarType.DOUBLE :
                isClassName(type)      ? VarType.OBJECT
                                       : VarType.INT);
    }

    public static VarType valueOfType(Type type) {
        switch (type.getSort()) {
            case Type.CHAR:
            case Type.BYTE:
            case Type.SHORT:
            case Type.INT:    return VarType.INT;

            case Type.LONG:   return VarType.LONG;
            case Type.FLOAT:  return VarType.FLOAT;
            case Type.DOUBLE: return VarType.DOUBLE;
            default:          return VarType.OBJECT;
        }
    }
}
