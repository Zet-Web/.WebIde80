/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.ComparisonParameters;
import org.jetbrains.annotations.NotNull;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentManager;

/**
 * The tool-window containing all the compare-directory panels
 */
public class CompareDirectoryView extends CompareDirectoryAbstractView {
    private CompareDirectoryPlugin  plugin;
    private final FileEditorManager fileEditorManager;

    public CompareDirectoryView(CompareDirectoryPlugin plugin, ContentManager contentManager) {
        super(contentManager);
        this.plugin            = plugin;
        this.fileEditorManager = FileEditorManager.getInstance(plugin.getProject());
    }

    protected CompareDirectoryPanel createPanel(ComparisonParameters parameters) {
        return new CompareDirectoryPanel(this, (PanelConfiguration) this.plugin.getLastConfiguration().clone(),
                                         parameters);
    }

    protected ToolWindow getToolWindow() {
        return CompareDirectoryPlugin.getToolWindow(this.plugin.getProject());
    }

    @Override
    public void closeCurrentTabbedPane() {
        final Content               selectedContent       = this.contentManager.getSelectedContent();
        final CompareDirectoryPanel compareDirectoryPanel = (CompareDirectoryPanel) ((selectedContent == null) ? null : selectedContent.getComponent());

        if (compareDirectoryPanel != null) {
            this.plugin.setLastConfiguration(compareDirectoryPanel.getConfiguration());
        }
        super.closeCurrentTabbedPane();
    }

    public void setPlugin(CompareDirectoryPlugin plugin) {
        this.plugin = plugin;
    }

    public CompareDirectoryPlugin getPlugin() {
        return this.plugin;
    }

    public Project getProject() {
        return this.plugin.getProject();
    }

    /*package*/ FileEditorManager getFileEditorManager() {
        return this.fileEditorManager;
    }

    @NotNull
    public PanelConfiguration getLastConfiguration() {
        return this.plugin.getLastConfiguration();
    }
}
