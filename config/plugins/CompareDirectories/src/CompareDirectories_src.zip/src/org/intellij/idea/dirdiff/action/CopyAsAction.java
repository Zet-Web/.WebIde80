/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import org.intellij.idea.dirdiff.actiondelegate.AbstractActionDelegate;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.jetbrains.annotations.NonNls;

import com.intellij.openapi.actionSystem.AnActionEvent;

/**
 * Copy action (common to left-to-right and right-to-left copies).
 */
public class CopyAsAction extends PopupMenuAction {

    private String  standardActionKey;
    private String  alternateActionKey;
    private boolean isLeftToRight;

    public CopyAsAction() {}

    public CopyAsAction(final CompareDirectoryPanel panel,
                        @NonNls final String        standardActionKey,
                        @NonNls final String        alternateActionKey,
                        AbstractActionDelegate      actionDelegate,
                        boolean                     isLeftToRight) {
        super(panel, standardActionKey, actionDelegate);

        this.standardActionKey  = standardActionKey;
        this.alternateActionKey = alternateActionKey;
        this.isLeftToRight      = isLeftToRight;
    }

    @Override public void update(AnActionEvent event) {
        super.update(event);

        final boolean otherSideOnlySelected = isOtherSideOnlySelected(getSelectedNodes(event), this.isLeftToRight);

        setActionKey(event.getPresentation(),
                     (otherSideOnlySelected ? this.alternateActionKey : this.standardActionKey));
    }

    private static boolean isOtherSideOnlySelected(ComparedTreeNode[] selectedNodes, boolean isLeftToRight) {
        final FileStateEnum otherSideOnlyState = (isLeftToRight ? FileStateEnum.RIGHT_ONLY : FileStateEnum.LEFT_ONLY);

        for (final ComparedTreeNode selectedNode : selectedNodes) {
            if (selectedNode != null && selectedNode.getState() != otherSideOnlyState) {
                return false;
            }
        }
        return true;
    }
}