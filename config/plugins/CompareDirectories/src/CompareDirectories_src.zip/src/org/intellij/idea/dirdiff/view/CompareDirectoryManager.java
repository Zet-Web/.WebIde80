/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import javax.swing.JOptionPane;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.util.Commands;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryManager;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiDocumentManager;

/**
 * 
 */
public class CompareDirectoryManager implements ICompareDirectoryManager {

    @NonNls private static final String REFRESH_ACTION = "refresh";
    @NonNls private static final String OPEN_DIFF      = "openDiff";
    @NonNls private static final String OPEN_FILE      = "openFile";

    private Project                     project;
    private ICompareDirectoryPanel      panel;
    private final MyClassVisitorContext context;

    public CompareDirectoryManager(@Nullable Project project, @NotNull ICompareDirectoryPanel panel) {
        this.project = project;
        this.panel   = panel;
        this.context = new MyClassVisitorContext();
    }

    public MyClassVisitorContext getClassVisitorContext() {
        return this.context;
    }

    public void execute(@NotNull Runnable runnable, boolean asynchronously) {
        if (asynchronously) {
            ApplicationManager.getApplication().executeOnPooledThread(runnable);
        } else {
            runnable.run();
        }
    }

    public void showErrorMessage(String text, String title) {
        Commands.showErrorDialog(this.project, text, title);
    }

    public boolean doesUserConfirm(String text, String title) {
        return (Messages.showYesNoDialog(this.project, text, title,
                                         Messages.getQuestionIcon()) == JOptionPane.YES_OPTION);
    }

    public int doesUserConfirm2(String text, String title) {
        return Commands.showConfirmDialog(this.project, text, title, true);
    }

    public boolean saveFiles(@NotNull ReadableFile[] files) {
        final FileDocumentManager fileDocumentManager = FileDocumentManager.getInstance();
        boolean                   changed             = false;

        // If no files are specified, use the files of the specified nodes.
        // If some are directories, use the files of the tree leaves only (real files only)
        for (ReadableFile file : files) {
            changed |= saveFileIfNeeded(fileDocumentManager, file);
        }

        return changed;
    }

    public boolean saveFiles(@NotNull ComparedTreeNode[] nodes) {
        final FileDocumentManager fileDocumentManager = FileDocumentManager.getInstance();
        boolean                   changed             = false;

        // If no files are specified, use the files of the specified nodes.
        // If some are directories, use the files of the tree leaves only (real files only)
        for (ComparedTreeNode node : nodes) {
            for (ComparedTreeNode leaf : node.getDescendentLeaves()) {
                final FileTreeNode fileNode = leaf.getSelfOrAncestor(FileTreeNode.class);

                if (fileNode != null) {
                    changed |= (saveFileIfNeeded(fileDocumentManager, fileNode.getLeftFile()) ||
                                saveFileIfNeeded(fileDocumentManager, fileNode.getRightFile()));
                }
            }
        }

        return changed;
    }

    public void saveFilesAndRefreshStates(@NotNull ComparedTreeNode... nodes) {
        boolean changed = this.saveFiles(nodes);

        // If any of the files has changed, recompute the state of the nodes.
        if (changed) {
            changed = false; // Does tree need to be refreshed?

            for (ComparedTreeNode node : nodes) {
                 // Recompute state of the node and, if it has changed,
                 // recompute the state of the ancestor nodes.
                final FileStateEnum state    = node.getState();
                final FileStateEnum newState = this.panel.recomputeNodeState(node);

                if (newState != state) {
                    this.panel.autoExcludeNode(node);
                    this.panel.recomputeAncestorsState(node);
                    changed = true;
                }
            }

            if (changed) {
                this.panel.refreshTree(true);
            }
        }
    }

    private static boolean saveFileIfNeeded(@NotNull FileDocumentManager fileDocumentManager,
                                            @NotNull ReadableFile        file) {
        // Gets the document to force its saving when the editor is closed.
        // If it is not cached, no editor was opened to edit it => nothing to be done
        final VirtualFile virtualFile  = file.getVirtualFile();
        final Document    fileDocument = ((virtualFile == null) ? null : fileDocumentManager.getCachedDocument(virtualFile));

        if (fileDocument != null && fileDocumentManager.isDocumentUnsaved(fileDocument)) {
            fileDocumentManager.saveDocument(fileDocument);
            return true;
        }

        return false;
    }

    /**
     * Ensures all the files stored in the IDEA memory cache and editors are properly saved
     * synchronized to disk.
     */
    public void refreshCachedFiles() {
        this.refreshCachedFiles(this.panel.getTreeModel().getRoot(), true);
    }

    /**
     * Ensures all the files stored in the IDEA memory cache and editors are properly saved
     * synchronized to disk.
     * @param treeNode     the comparison node, whose files are to be synchronized to disk.
     * @param redraw       <tt>true</tt> to redraw the nodes after refresh, <tt>false</tt>
     *                     otherwise.
     */
    public void refreshCachedFiles(@NotNull ComparedTreeNode treeNode,
                                   boolean               redraw) {
        if (this.project != null) {
            this.saveAllDocuments();
            this.refreshNode(treeNode, true, false);

            if (redraw) {
                this.panel.redrawNode(treeNode);
            }
        }
    }

    /**
     * Ensures every document of this project is committed and saved on disk.
     */
    public void saveAllDocuments() {
        PsiDocumentManager .getInstance(this.project).commitAllDocuments();
        FileDocumentManager.getInstance().saveAllDocuments();
    }

    public void refreshNode(@NotNull ComparedTreeNode node) {
        this.refreshNode(node, false, true);
    }

    public void refreshNode(@NotNull final ComparedTreeNode node, final boolean recursive, final boolean asynchronous) {
        final Runnable runnable = new Runnable() {
                public void run() {
                    Commands.runWriteCommand(CompareDirectoryManager.this.project, new Runnable() {
                            public void run() {
                                node.refreshCacheFiles(recursive, asynchronous);
                            }
                        }, REFRESH_ACTION, CompareDirectoryPlugin.ACTION_GROUP_ID);
                }
            };

        Commands.invoke(runnable);
    }

    /*package*/ void doOpenFile(Project project, ComparedTreeNode node, ReadableFile file) {
        // If IDEA file type is UNKNOWN, temporarily associate extension with the PLAIN_TEXT file type
        // so that the IDEA text editor can be opened.
        final CompareDirectoryPlugin plugin = CompareDirectoryPlugin.getInstance(project);

        if (plugin != null) {
            plugin.registerUnknownExtension(file, file.getExtension());
        }

        final Runnable openFileTask = new OpenFileRunnable(this, this.panel, project, file, node);

        Commands.runWriteCommand(project, openFileTask, OPEN_FILE, CompareDirectoryPlugin.ACTION_GROUP_ID);
    }

    /*package*/ void doOpenFileDiffs(Project project, ComparedTreeNode[] nodes, ReadableFile leftFile, ReadableFile rightFile) {
        if (!(project == null || leftFile.isDirectory() || rightFile.isDirectory())) {
            final Runnable openDiffTask = new OpenDiffRunnable(project, this.panel, nodes, leftFile, rightFile);

            Commands.runWriteCommand(project, openDiffTask, OPEN_DIFF, CompareDirectoryPlugin.ACTION_GROUP_ID);
        }
    }
}
