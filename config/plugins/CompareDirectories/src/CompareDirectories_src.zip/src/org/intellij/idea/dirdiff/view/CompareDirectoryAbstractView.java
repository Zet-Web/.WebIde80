/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.intellij.idea.dirdiff.model.ComparisonParameters;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import com.intellij.ui.content.ContentManager;
import com.intellij.ui.content.ContentManagerEvent;
import com.intellij.ui.content.ContentManagerListener;

/**
 * The abstract view containing all the compare-directory panels.
 */
public abstract class CompareDirectoryAbstractView implements Runnable, Disposable {

    protected final ContentManager       contentManager;
    private   CompareViewManagerListener contentManagerListener;

    public CompareDirectoryAbstractView(ContentManager contentManager) {
        this.contentManager = contentManager;
    }

    protected abstract CompareDirectoryPanel createPanel(ComparisonParameters parameters);

    public CompareDirectoryPanel addPanel(ComparisonParameters parameters) {
        final CompareDirectoryPanel panel          = this.createPanel(parameters);
        final ContentFactory        contentFactory = ContentFactory.SERVICE.getInstance();
        final Content               content        = contentFactory.createContent(panel, "", true);

        content.setCloseable(true);
        this.contentManager.addContent(content);
        this.contentManager.setSelectedContent(this.getContent(this.getNumPanels() - 1), true);

        if (this.contentManagerListener == null) {
            this.contentManagerListener = new CompareViewManagerListener(this.getToolWindow(), this.contentManager);
            this.contentManager.addContentManagerListener(this.contentManagerListener);
        }

        return panel;
    }

    @Nullable
    protected abstract ToolWindow getToolWindow();

    @Nullable
    public abstract Project getProject();

    @NotNull
    public abstract PanelConfiguration getLastConfiguration();

    public final int getNumPanels() {
        return this.contentManager.getContentCount();
    }

    @Nullable public final CompareDirectoryPanel getPanel(int index) {
        final Content content = this.getContent(index);

        return (CompareDirectoryPanel) ((content == null) ? null : content.getComponent());
    }

    @Nullable protected final Content getContent(int index) {
        return this.contentManager.getContent(index);
    }

    @Nullable public final CompareDirectoryPanel getCurrentPanel() {
        final Content selectedContent = this.contentManager.getSelectedContent();

        return (selectedContent == null) ? null : (CompareDirectoryPanel) selectedContent.getComponent();
    }

    protected static void setPanelTitle(@Nullable Content selectedContent, String title) {
        if (selectedContent != null) {
            selectedContent.setDisplayName(title);
        }
    }

    public final void setLastPanelTitle(String title) {
        setPanelTitle(this.contentManager.getContent(this.getNumPanels() - 1), title);
    }

    public final void setCurrentPanelTitle(String title) {
        setPanelTitle(this.contentManager.getSelectedContent(), title);
    }

    public void dispose() {
        if (this.contentManagerListener != null) {
            this.contentManager.removeContentManagerListener(this.contentManagerListener);
            this.contentManagerListener = null;
        }
    }

    public void closeCurrentTabbedPane() {
        final Content selectedContent = this.contentManager.getSelectedContent();

        if (selectedContent != null) {
            this.contentManager.removeContent(selectedContent, true);
        }
    }

    public void run() {
        // Force panel redrawing when the view becomes visible
        final CompareDirectoryPanel panel = this.getCurrentPanel();
        if (panel != null) {
            panel.invalidate();
        }
    }

    protected static class CompareViewManagerListener implements ContentManagerListener {
        private final ToolWindow     toolWindow;
        private final ContentManager contentManager;

        public CompareViewManagerListener(@Nullable ToolWindow toolWindow, @NotNull ContentManager manager) {
            this.toolWindow     = toolWindow;
            this.contentManager = manager;
        }

        public void contentAdded    (ContentManagerEvent event) {}
        public void selectionChanged(ContentManagerEvent event) {}

        public void contentRemoveQuery(ContentManagerEvent event) {
            ((CompareDirectoryPanel) event.getContent().getComponent()).setCurrentTree(null, new ComparisonParameters());
        }

        public void contentRemoved(ContentManagerEvent event) {
            if (this.toolWindow != null && this.contentManager.getContentCount() == 0) {
                // Hides tool window
                this.toolWindow.setAvailable(false, null);
            }
        }
    }
}