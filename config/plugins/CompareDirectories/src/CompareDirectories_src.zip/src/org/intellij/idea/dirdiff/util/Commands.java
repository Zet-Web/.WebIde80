/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.util;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.Callable;

import com.intellij.openapi.application.Application;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.command.CommandProcessor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Condition;
import com.intellij.util.Alarm;

/**
 * Utility class, which makes easier the running of tasks in read, write or
 * graphical commands in the apropiate threads
 */
public class Commands {

    private Commands() {}

    /**
     * Invokes a read command in the appropriate context.
     * @param project  the IDEA project
     * @param runnable the runnable completing the read operation
     * @param name     the command name
     * @param groupId  the command group id
     */
    public static void runReadCommand(Project project, Runnable runnable, String name, Object groupId) {
        CommandProcessor.getInstance().executeCommand(project, new ReadCommandRunnable(runnable), name, groupId);
    }

    /**
     * Invokes a write command in the appropriate context.
     * @param project  the IDEA project
     * @param runnable the runnable completing the write operation
     * @param name     the command name
     * @param groupId  the command group id
     */
    public static void runWriteCommand(Project project, Runnable runnable, String name, Object groupId) {
        CommandProcessor.getInstance().executeCommand(project, new WriteCommandRunnable(runnable), name, groupId);
    }

    /**
     * Runs a graphical operation in the appropriate context (i.e.
     * synchronously if possible, or asynchronously on the AWT event
     * dispatching thread, when IDEA is in the specified modality
     * state).
     * @param runnable the runnable completing the graphical operation.
     */
    public static void invoke(Runnable runnable) {
        final Application application = ApplicationManager.getApplication();

        if (application.isDispatchThread()) {
            runnable.run();
        } else {
            application.invokeLater(runnable, ModalityState.NON_MODAL);
        }
    }

    /**
     * Runs a graphical operation in the appropriate context (i.e.
     * synchronously if possible, or asynchronously on the AWT event
     * dispatching thread, when IDEA is in the specified modality
     * state).
     * @param runnable the runnable completing the graphical operation.
     * @param condition the runnable execution condition
     */
    public static <T> void invoke(Runnable runnable, Condition<T> condition) {
        final Application application = ApplicationManager.getApplication();

        if (application.isDispatchThread()) {
            runnable.run();
        } else {
            application.invokeLater(runnable, ModalityState.NON_MODAL, condition);
        }
    }

    /**
     * Runs a graphical operation returning a result in the appropriate
     * context (i.e. synchronously if possible, or asynchronously on the
     * AWT event dispatching thread, when IDEA is in the specified modality
     * state).
     * @param callable the callable completing the graphical operation.
     * @return the return value of the callable
     */
    public static <E> E invoke(Callable<E> callable) throws Exception {
        final Application application = ApplicationManager.getApplication();

        if (application.isDispatchThread()) {
            return callable.call();
        } else {
            final CallableRunnableAdapter<E> caller = new CallableRunnableAdapter<E>(callable);

            application.invokeAndWait(caller, ModalityState.NON_MODAL);

            final Exception thrownException = caller.getThrownException();

            if (thrownException != null) {
                throw thrownException;
            }
            return caller.getReturnedValue();
        }
    }

    public static void invokeWithAlarm(Alarm alarm, Runnable runnable) {
        alarm.cancelAllRequests();
        alarm.addRequest(runnable, 300, ModalityState.NON_MODAL);
    }

    /**
     * Opens an error dialog box with this message and title.
     * @param project the IDEA project
     * @param message the dialog box message
     * @param title   the dialog box title
     */
    public static void showErrorDialog(final Project project, final String message, final String title) {
        final Runnable runnable = new Runnable() {
                public void run() {
                    Messages.showErrorDialog(project, message, title);
                }
            };

        Commands.invoke(runnable);
    }

    /**
     * Opens a warning dialog box with this message and title.
     * @param project the IDEA project
     * @param message the dialog box message
     * @param title   the dialog box title
     */
    public static void showWarningDialog(final Project project, final String message, final String title) {
        final Runnable runnable = new Runnable() {
                public void run() {
                    Messages.showWarningDialog(project, message, title);
                }
            };

        Commands.invoke(runnable);
    }

    /**
     * Opens a confirmation box with this message and title.
     * @param project the IDEA project
     * @param message the confirmation box message
     * @param title   the confirmation box title
     * @param useApplyAllButton if <code>true</code>, the confirmation box
     *          should includes "Yes to All" and "No to All" buttons with
     *          "Yes", "No" and "Cancel" buttons; <code>false</code> if it
     *          should only include the "Yes", "No" and "Cancel" buttons.
     * @return YES (0), NO (1), YES_TO_ALL (2), NO_TO_ALL (3) or CANCEL (4)
     *         integer values
     */
    public static int showConfirmDialog(final Project project, final String  message,
                                        final String  title,   final boolean useApplyAllButton) {
        final Callable<Integer> callable = new Callable<Integer>() {
                public Integer call() throws Exception {
                    final String[] buttonTexts = (useApplyAllButton ? StandardButtonTexts.buttonTextsWithApplyAll
                                                                    : StandardButtonTexts.buttonTextsWithoutApplyAll);

                    return Messages.showDialog(project, message, title, buttonTexts, 0, Messages.getQuestionIcon());
                }
            };

        try {
            return Commands.invoke(callable);
        } catch (Exception e) {
            // Should never happen here since this callable implementation never throws any exception
            CompareDirectoryPlugin.getLogger().error(e);
            return -1;
        }
    }

    private static class ReadCommandRunnable implements Runnable {
        private final Runnable runnable;

        public ReadCommandRunnable(Runnable runnable) {
            this.runnable = runnable;
        }

        public void run() {
            ApplicationManager.getApplication().runReadAction(this.runnable);
        }
    }

    private static class WriteCommandRunnable implements Runnable {
        private final Runnable runnable;

        public WriteCommandRunnable(Runnable runnable) {
            this.runnable = runnable;
        }

        public void run() {
            ApplicationManager.getApplication().runWriteAction(this.runnable);
        }
    }

    private static class CallableRunnableAdapter<E> implements Runnable {
        private final Callable<E> callable;
        private Exception         thrownException;
        private E                 returnedValue;

        public CallableRunnableAdapter(Callable<E> callable) {
            this.callable = callable;
        }

        public void run() {
            try {
                this.returnedValue = this.callable.call();
            } catch (Exception e) {
                this.thrownException = e;
            }
        }

        public Exception getThrownException() {
            return this.thrownException;
        }

        public E getReturnedValue() {
            return this.returnedValue;
        }
    }

    private static class StandardButtonTexts extends Messages {
        public static final String OK_BUTTON     = Messages.OK_BUTTON;
        public static final String YES_BUTTON    = Messages.YES_BUTTON;
        public static final String NO_BUTTON     = Messages.NO_BUTTON;
        public static final String CANCEL_BUTTON = Messages.CANCEL_BUTTON;
        public static final String YES_TO_ALL    = CompareDirectoryBundle.message("button.yes-to-all");
        public static final String NO_TO_ALL     = CompareDirectoryBundle.message("button.no-to-all");

        public static final String[]  buttonTextsWithApplyAll = {
                StandardButtonTexts.YES_BUTTON, StandardButtonTexts.YES_TO_ALL,
                StandardButtonTexts.NO_BUTTON,  StandardButtonTexts.NO_TO_ALL,
                StandardButtonTexts.CANCEL_BUTTON };

        public static final String[]  buttonTextsWithoutApplyAll = {
                StandardButtonTexts.YES_BUTTON, StandardButtonTexts.NO_BUTTON, StandardButtonTexts.CANCEL_BUTTON };
    }
}