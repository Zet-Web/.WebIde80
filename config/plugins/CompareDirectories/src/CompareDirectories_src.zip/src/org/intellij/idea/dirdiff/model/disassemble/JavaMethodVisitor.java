/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import gnu.trove.THashMap;
import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.asm4.Handle;
import org.jetbrains.asm4.Label;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

class JavaMethodVisitor extends MyMethodVisitor {

    private static final String COMMENT = "// ";

    private class TryCatchBlock {
        private final String             tryStartLabel;
        private final String             tryEndLabel;
        private final List<CatchClause>  catchClauses;
        private String                   finallyLabel;

        private TryCatchBlock(String tryStartLabel, String tryEndLabel) {
            this.tryStartLabel = tryStartLabel;
            this.tryEndLabel   = tryEndLabel;
            this.catchClauses  = new ArrayList<CatchClause>();
        }
    }

    private static class CatchClause {
        private final String label;
        private final String exceptionType;

        private CatchClause(String label, String exceptionType) {
            this.label         = label;
            this.exceptionType = exceptionType;
        }
    }

    private final List<String>        operands;
    private final Map<String, String> instructionBlocks;
    private final List<String>        instructionLabels;
    private final List<TryCatchBlock> tryCatchBlocks;
    private TryCatchBlock             currentTryCatchBlock;
    private String                    currentLabel;
    private boolean                   currentLabelPrinted;
    private boolean                   inCatchClause;

    JavaMethodVisitor(FullClassVisitor fullClassVisitor, Printer bufferPrinter, JavaClassMemberDesc javaMethod) {
        super(fullClassVisitor, bufferPrinter, javaMethod);
        this.operands          = new ArrayList<String>();
        this.instructionBlocks = new THashMap<String, String>();
        this.instructionLabels = new ArrayList<String>();
        this.tryCatchBlocks    = new ArrayList<TryCatchBlock>();
    }

    public List<String> getOperands() {
        return this.operands;
    }

    public void offerOperand(String value, VarType varType) {
        this.operands.add(value);
        if (varType.isDoubleWord()) {
            this.operands.add(value);
        }
    }

    public String pollOperand(VarType varType) {
        int index = this.operands.size() - 1;

        if (varType.isDoubleWord()) {
            this.operands.remove(index);
            index--;
        }
        return this.operands.remove(index);
    }

    @Nullable private TryCatchBlock findCurrentTryCatchBlock(@NotNull  String startLabelName,
                                                             @Nullable String endLabelName,
                                                             boolean          checkTryOnly) {
        for (int index = this.tryCatchBlocks.size(); --index >= 0; ) {
            final TryCatchBlock block = this.tryCatchBlocks.get(index);

            if (startLabelName.equals(block.tryStartLabel) &&
                (endLabelName == null || endLabelName.equals(block.tryEndLabel))) {
                return block;
            }

            if (!checkTryOnly) {
                if (startLabelName.equals(block.finallyLabel)) {
                    return block;
                }

                for (int i = block.catchClauses.size(); --i >= 0; ) {
                     if (startLabelName.equals(block.catchClauses.get(i).label)) {
                         return block;
                     }
                }
            }
        }
        return null;
    }

    @Override public void visitCode() {
        this.startBufferIndex = this.printer.lastIndexOf("(");
        this.printer.indent()
                    .append(" {", Printer.CR);
    }

    @Override public void visitInsn(int opcode) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[opcode];

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.CR);
        instruction.apply(this);
    }

    private void visitInsnWithArgument(int opcode, String argument) {
        this.printer.appendIndented(COMMENT, JavaInstructions.INSTRUCTIONS[opcode].getMnemonic(),
                                    Printer.SPACE, argument, Printer.CR);
    }

    @Override public void visitIntInsn(int opcode, int operand) {
        final String operandStr = (opcode == Opcodes.NEWARRAY) ? JavaInstructions.TYPES[operand]
                                                               : Integer.toString(operand);

        this.visitInsnWithArgument(opcode, operandStr);
        JavaInstructions.INSTRUCTIONS[opcode].apply(this, operandStr);
    }

    @Override public void visitVarInsn(int opcode, int var) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[opcode];

        this.visitInsnWithArgument(opcode, this.getVariableName(instruction.getMnemonic(), var));
        instruction.apply(this, var);
    }

    private String getVariableName(String opcode, int var) {
        if (var >= this.localVariables.size() &&
            (opcode.endsWith("LOAD") || opcode.endsWith("STORE"))) {
            final VarType varType      = VarType.valueOfOpcodeType(opcode.charAt(0));
            final String  variableName = this.getVariableName(varType, var, false);

            if (this.inCatchClause) {
                this.printer.unindent()
                            .appendIndented("catch(Object ", variableName, ") {", Printer.CR)
                            .indent();
                this.offerOperand(variableName, VarType.OBJECT);
                this.inCatchClause = false;
            }
            return variableName;
        }

        return (var < this.localVariables.size()) ? this.localVariables.get(var) : Integer.toString(var);
    }

    @Override public void visitTypeInsn(int opcode, String desc) {
        final String type = (desc.charAt(0) == '[' || desc.charAt(desc.length() - 1) == ';')
                                      ? this.classVisitor.getClassVisitorContext().getClassName(Type.getType(desc))
                                      : AsmUtil.getQualified(desc);

        this.visitInsnWithArgument(opcode, this.classVisitor.ensureClassImported(type));
        JavaInstructions.INSTRUCTIONS[opcode].apply(this, type);
    }

    @Override public void visitFieldInsn(int opcode, String owner, String name, String desc) {
        final String          ownerTypeName   = this.classVisitor.ensureClassImported(AsmUtil.getQualified(owner));
        final String          fieldTypeName   = this.classVisitor.ensureClassImported(Type.getType(desc));
        final JavaInstruction javaInstruction = JavaInstructions.INSTRUCTIONS[opcode];

        this.printer.appendIndented(COMMENT, javaInstruction.getMnemonic(), Printer.SPACE, fieldTypeName,
                                    Printer.SPACE, ownerTypeName, ".", name, Printer.CR);
        javaInstruction.apply(this, owner, name, desc);
    }

    @Override public void visitMethodInsn(int opcode, String owner, String name, String desc) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[opcode];

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.SPACE);
        this.classVisitor.appendMethodSignature(this, null, AsmUtil.getQualified(owner), name,
                                                desc, null, Type.getArgumentTypes(desc), null);
        this.printer.append(Printer.CR);
        instruction.apply(this, owner, name, desc);
    }

    @Override public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs) {
        final String mnemonic = JavaInstructions.INSTRUCTIONS[Opcodes.INVOKEDYNAMIC].getMnemonic();
        boolean      notFirst = false;

        this.printer.appendIndented(COMMENT, mnemonic, Printer.SPACE);
        for (Object bsmArg : bsmArgs) {
            if (bsmArg instanceof Handle) {
                final Handle handle = (Handle) bsmArg;

                if (notFirst) {
                    this.printer.append(Printer.CR)
                                .appendIndentedRepeatedly(COMMENT.length() + mnemonic.length() + 1, Printer.SPACE);
                }

                this.printer.append("[", JavaInstructions.HANDLES[handle.getTag()].getMnemonic(), "]", Printer.SPACE);

                switch (handle.getTag()) {
                    case Opcodes.H_GETFIELD:
                    case Opcodes.H_GETSTATIC:
                    case Opcodes.H_PUTFIELD:
                    case Opcodes.H_PUTSTATIC:
                        final String ownerTypeName = this.classVisitor.ensureClassImported(AsmUtil.getQualified(handle.getOwner()));
                        final String fieldTypeName = this.classVisitor.ensureClassImported(Type.getType(handle.getDesc()));

                        this.printer.append(ownerTypeName, ".", handle.getName(), ": ", fieldTypeName, Printer.CR);
                        break;

                    case Opcodes.H_INVOKEVIRTUAL:
                    case Opcodes.H_INVOKESTATIC:
                    case Opcodes.H_INVOKESPECIAL:
                    case Opcodes.H_NEWINVOKESPECIAL:
                    case Opcodes.H_INVOKEINTERFACE:
                        final String handleName = handle.getName();

                        this.classVisitor.appendMethodSignature(this, null, AsmUtil.getQualified(handle.getOwner()), handleName,
                                                                handle.getDesc(), null, Type.getArgumentTypes(handle.getDesc()), null);
                        this.printer.append(Printer.CR);
                        if (AsmUtil.isLambdaMethod(handleName)) {
                            this.classVisitor.getClassDesc().addLambdaCaller(handleName, this.javaMethod);
                        }
                        break;
                }

                notFirst = true;
            }
        }
    }

    @Override public void visitJumpInsn(int opcode, Label label) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[opcode];
        final String          labelName   = this.getLabelName(label);

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.SPACE, labelName, Printer.CR);
        instruction.apply(this, labelName);
    }

    @Override public void visitLabel(Label label) {
        if (this.currentLabel == null) {
            this.instructionLabels.add("");
            this.instructionBlocks.put("", this.printer.toString());
        } else {
            this.instructionBlocks.put(this.currentLabel, this.printer.toString());
        }
        this.printer.truncate(0);

        this.currentLabel = this.getLabelName(label);
        this.instructionLabels.add(this.currentLabel);
        this.printer.unindent()
                    .appendIndented(this.currentLabel, ":", Printer.CR)
                    .indent();
    }

    @Override public void visitLdcInsn(Object cst) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[Opcodes.LDC];
        final String          literal     = this.classVisitor.getLiteral(cst);

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.SPACE, literal, Printer.CR);
        instruction.apply(this, literal);
    }

    @Override public void visitIincInsn(int var, int increment) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[Opcodes.IINC];

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.SPACE,
                                    Integer.toString(var), Printer.SPACE, Integer.toString(increment), Printer.CR);
        instruction.apply(this, var, increment);
    }

    @Override public void visitTableSwitchInsn(int min, int max, Label defaultLabel, Label[] labels) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[Opcodes.TABLESWITCH];

        this.printer.appendIndented(instruction.getMnemonic(), Printer.CR)
                    .indent();

        for (int index = 0; index < labels.length; index++) {
            this.printer.appendIndented(Integer.toString(min + index), ": goto ",
                                        this.getLabelName(labels[index]), Printer.CR);
        }

        this.printer.appendIndented("default: goto ", this.getLabelName(defaultLabel), Printer.CR)
                    .unindent();

        instruction.apply(this, min, max);
    }

    @Override public void visitLookupSwitchInsn(Label defaultLabel, int[] keys, Label[] labels) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[Opcodes.LOOKUPSWITCH];

        this.printer.appendIndented(instruction.getMnemonic(), Printer.CR);
        this.printer.indent();

        for (int index = 0; index < labels.length; ++index) {
            this.printer.appendIndented(Integer.toString(keys[index]), ": goto ", this.getLabelName(labels[index]), Printer.CR);
        }
        this.printer.appendIndented("default: goto ", this.getLabelName(defaultLabel), Printer.CR)
                    .unindent();

        instruction.apply(this);
    }

    @Override public void visitMultiANewArrayInsn(String desc, int dims) {
        final JavaInstruction instruction = JavaInstructions.INSTRUCTIONS[Opcodes.MULTIANEWARRAY];

        this.printer.appendIndented(COMMENT, instruction.getMnemonic(), Printer.SPACE,
                                    this.classVisitor.ensureClassImported(AsmUtil.getQualified(desc)),
                                    "[", Integer.toString(dims), "]", Printer.CR);
        instruction.apply(this, desc, dims);
    }

    @Override public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
        final String  tryStartLabel = this.getLabelName(start);
        final String  tryEndLabel   = this.getLabelName(end);
        TryCatchBlock tryCatchBlock = this.findCurrentTryCatchBlock(tryStartLabel, tryEndLabel, true);

        this.printer.appendIndented("TRYCATCHBLOCK ",
                                    tryStartLabel,              Printer.SPACE,
                                    tryEndLabel,                Printer.SPACE,
                                    this.getLabelName(handler), Printer.SPACE, Printer.SPACE, Printer.SPACE);

        if (tryCatchBlock == null) {
            tryCatchBlock = new TryCatchBlock(tryStartLabel, tryEndLabel);
            this.tryCatchBlocks.add(tryCatchBlock);
        }
        if (type == null && start == handler) {
            tryCatchBlock.finallyLabel = tryStartLabel;
            this.printer.append("finally", Printer.CR);
        } else {
            final String typeName = (type == null) ? "Throwable"
                                                   : this.classVisitor.ensureClassImported(AsmUtil.getQualified(type));

            tryCatchBlock.catchClauses.add(new CatchClause(this.getLabelName(handler), typeName));
            this.printer.append("catch (", typeName, ")", Printer.CR);
        }
    }

    @Override public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index) {
        // Is it a local variable never referenced before?
        if (index >= this.localVariables.size()) {
            while (index > this.localVariables.size()) {
                this.localVariables.add("x".concat(Integer.toString(this.localVariables.size())));
            }
            this.localVariables.add(name);
        } else {
            // Parameter or local variable referenced before => rename every usage of it
            final String[] defaultVarNames  = { ' ' + this.localVariables.get(index), '(' + this.localVariables.get(index) };
            final String[] replacementNames = { ' ' + name,                           '(' + name };

            if (this.startBufferIndex >= 0) {
                for (int n = 0; n < replacementNames.length; n++) {
                    if (!defaultVarNames[n].equals(replacementNames[n])) {
                        this.replaceAllOccurrences(defaultVarNames[n], replacementNames[n], desc);
                    }
                }
                this.localVariables.set(index, name);
            }
        }
    }

    @Override public void visitLineNumber(int line, Label start) {
//        if (this.currentLabel != null && !this.currentLabelPrinted) {
//            this.printer.unindent()
//                        .appendIndented(this.currentLabel, ":", Printer.CR)
//                        .indent();
//            this.currentLabelPrinted = true;
//
//            this.currentTryCatchBlock = this.findCurrentTryCatchBlock(this.currentLabel, null, false);
//            if (this.currentTryCatchBlock != null) {
//                if (this.currentLabel.equals(this.currentTryCatchBlock.finallyLabel)) {
//                    this.printer.unindent()
//                                .appendIndented("finally {", Printer.CR)
//                                .indent();
//                    this.inCatchClause = false;
//                } else {
//                    boolean inNewCatchClause = false;
//
//
//                    for (int index = this.currentTryCatchBlock.catchClauses.size(); --index >= 0; ) {
//                        final CatchClause catchClause = this.currentTryCatchBlock.catchClauses.get(index);
//
//                        if (this.currentLabel.equals(catchClause.label)) {
//                            inNewCatchClause = true;
//                            break;
//                        }
//                    }
//
//                    if (inNewCatchClause) {
//                        this.inCatchClause = true;
//                    } else {
//                        if (this.inCatchClause) {
//                            this.printer.appendIndented("}", Printer.CR)
//                                        .unindent();
//                            this.inCatchClause = false;
//                        } else {
//                            this.printer.appendIndented("try {", Printer.CR)
//                                        .indent();
//                        }
//                    }
//                }
//            }
//        }
    }

    @Override public void visitEnd() {
        this.normalizeGeneratedVariableNames();
        if (this.classVisitor.getClassDesc().isAnnotation()) {
            this.printer.append(";", Printer.CR);
        } else {
            this.printer.unindent()
                        .appendIndented("}", Printer.CR);
        }

        // Add last bit of code
        if (!this.operands.isEmpty()) {
            this.printer.appendIndented(this.pollOperand(VarType.OBJECT), ";", Printer.CR);
        }
        this.instructionBlocks.put(this.currentLabel, this.printer.toString());
        this.printer.truncate(0);

        // Gather all bits of code (TODO: handling try-catch blocks)
        for (String label : this.instructionLabels) {
            this.printer.append(this.instructionBlocks.get(label));
        }

        // Finalize method code
        this.javaMethod.setEnd(this.printer.length());
        this.javaMethod.setByteVector(null);  // Byte vector becomes useless.
    }
}