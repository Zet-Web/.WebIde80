/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import gnu.trove.THashMap;
import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.asm4.AnnotationVisitor;
import org.jetbrains.asm4.Attribute;
import org.jetbrains.asm4.FieldVisitor;
import org.jetbrains.asm4.MethodVisitor;
import org.jetbrains.asm4.Type;
import org.jetbrains.asm4.signature.SignatureReader;

/**
 *
 */
public class FullClassVisitor extends MyClassVisitor {

    private final Printer               printer;
    private       String                className;
    private       String                simpleClassName;
    private       String                superClassName;
    private       String                containingPackage;
    private       int                   importInsertionPoint;
    private       Map<String, String>   imports;
    private       Map<String, String>   constants;
    private       List<String>          enumValues;
    private       int                   javaVersion;
    private final JavaClassDesc         classDesc;
    private final MyClassVisitorContext context;
    private final boolean               decompile;

    public FullClassVisitor(@NotNull MyClassVisitorContext context, boolean decompileBytecode) {
        this.printer   = new Printer(new StringBuilder());
        this.imports   = new THashMap<String, String>();
        this.constants = new THashMap<String, String>();
        this.classDesc = new JavaClassDesc();
        this.context   = context;
        this.decompile = decompileBytecode;
    }

    public Printer getPrinter() {
        return this.printer;
    }

    public String getClassName() {
        return this.className;
    }

    public JavaClassDesc getClassDesc() {
        return this.classDesc;
    }

    public String getSimpleClassName() {
        return this.simpleClassName;
    }

    public String getSuperClassName() {
        return this.superClassName;
    }

    /*package*/ MyClassVisitorContext getClassVisitorContext() {
        return this.context;
    }

    protected String ensureClassImported(final String className) {
        final String classPackage = AsmUtil.getClassPackage(className);

        if (!(classPackage == null || classPackage.equals(this.containingPackage) ||
              AsmUtil.isJavaLangPackage(classPackage))) {
            // If inner class, then import outer class type.
            int importedNameEndIndex = className.indexOf('$', classPackage.length());

            if (importedNameEndIndex < 0) {
                importedNameEndIndex = className.length();

                // If array type, then remove the square brackets before importing the type
                while (className.regionMatches(importedNameEndIndex - 2, "[]", 0, 2)) {
                    importedNameEndIndex -= 2;
                }
            }

            final String nonArrayQualifiedClassName = AsmUtil.getQualified(className.substring(0, importedNameEndIndex));
            final String nonArraySimpleClassName    = AsmUtil.getSimpleClassName(nonArrayQualifiedClassName);
            final String registeredClassName        = this.imports.get(nonArraySimpleClassName);

            if (registeredClassName == null) {
                this.imports.put(nonArraySimpleClassName, nonArrayQualifiedClassName);
            } else if (!registeredClassName.equals(nonArrayQualifiedClassName)) {
                // Never import two different classes with the same simple name (name conflict)!
                return className;
            }
        }

        return AsmUtil.getSimpleClassName(className);
    }

    protected String ensureClassImported(final Type type) {
        return this.ensureClassImported(this.context.getClassName(type));
    }

    public String getLiteral(Object cst) {
        final String literal;

        if (cst instanceof String) {
            literal = AsmUtil.getStringLiteral((String) cst, this.context);
        } else if (cst instanceof Type) {
            final String typeDescriptor     = ((Type) cst).getDescriptor();
            final String qualifiedClassName = AsmUtil.getQualified(typeDescriptor.substring(1, typeDescriptor.length() - 1));

            literal = this.ensureClassImported(qualifiedClassName).concat(".class");
        } else if (cst instanceof Long) {
            literal = cst.toString().concat("L");
        } else if (cst instanceof Float) {
            literal = cst.toString().concat("f");
        } else {
            literal = cst.toString();
        }

        final String symbol = this.constants.get(literal);

        return (symbol == null) ? literal : symbol;
    }

    @Override public void visit(int      version,
                                int      accessFlags,
                                String   name,
                                String   signature,
                                String   superName,
                                String[] interfaces) {
        this.superClassName    = AsmUtil.getQualified      ((superName == null) ? name : superName);  // superName == null if name = "java/lang/Object"
        this.className         = AsmUtil.getQualified      (name);
        this.containingPackage = AsmUtil.getClassPackage   (this.className);
        this.simpleClassName   = AsmUtil.getSimpleClassName(this.className);
        this.javaVersion       = AsmUtil.getVersion        (version);

        this.classDesc.setClassName  (this.simpleClassName);
        this.classDesc.setAccessFlags(accessFlags);
        if (this.classDesc.isEnum()) {
            this.enumValues = new ArrayList<String>();
        }

        if (this.containingPackage != null) {
            this.printer.append("package ", this.containingPackage, ";", Printer.CR, Printer.CR);
        }
        this.importInsertionPoint = this.printer.length();

        this.printer.append("/* Java target: ", AsmUtil.getVersionAsText(version), " */", Printer.CR);
        this.printer.append(AsmUtil.getVisibility(accessFlags));
        if (this.classDesc.isClass()) {
            this.printer.append(AsmUtil.getAbstractModifier(accessFlags),
                                AsmUtil.getStaticModifier  (accessFlags),
                                AsmUtil.getFinalModifier   (accessFlags));
        }
        this.printer.append(AsmUtil.getCompilationUnit(accessFlags), this.simpleClassName);
        if (!(this.classDesc.isEnum() || AsmUtil.isObjectClass(this.superClassName))) {
            this.printer.append(" extends ", this.ensureClassImported(this.superClassName));
        }

        // Annotation types implicitly (and only) implement java.lang.annotation.Annotation type => skip this.
        if (interfaces != null && interfaces.length > 0 && !this.classDesc.isAnnotation()) {
            this.printer.append(" implements ");
            for (int index = 0; index < interfaces.length; index++) {
                if (index > 0) {
                    this.printer.append(", ");
                }
                this.printer.append(this.ensureClassImported(AsmUtil.getQualified(interfaces[index])));
            }
        }

        this.printer.append(" {", Printer.CR)
                    .indent();
    }

    @Override public void visitSource(String source, String debug) {
    }

    @Override public void visitOuterClass(String owner, String name, String desc) {
    }

    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
        return new MyAnnotationVisitor(desc, this, true);
    }

    @Override public void visitAttribute(Attribute attr) {
    }

    @Override public void visitInnerClass(String name,
                                          String outerName,
                                          String innerName,
                                          int    accessFlags) {
    }

    @Override public FieldVisitor visitField(int    accessFlags,
                                             String name,
                                             String desc,
                                             String signature,
                                             Object value) {
        // Skip assertion synthetic field
        if (this.javaVersion >= 14 && "$assertionsDisabled".equals(name)) {
            return null;
        }

        String typeName = this.context.getClassName(Type.getType(desc));

        if (this.classDesc.isEnum()) {
            // Skip enum synthetic field (array containing every enum value)
            if ("$VALUES".equals(name)) {
                // Skip synthetic field and insert all gathered enumerated values
                // as a simple comma-separated list of symbols.
                final int lastIndex = this.enumValues.size() - 1;

                for (int index = 0; index <= lastIndex; index++) {
                    this.printer.appendIndented(this.enumValues.get(index),
                                                (index == lastIndex) ? ";\n" : ",\n");
                }
            } else if (typeName.equals(this.className) && AsmUtil.isPublicConstant(accessFlags)) {
                this.enumValues.add(name);
                this.classDesc.addMember(name, JavaClassMemberDesc.Type.FIELD, accessFlags, 0);
            }

            return null;
        }

        // Skip synthetic static final Class<?> fields.
        if (name.startsWith("class$") && AsmUtil.isPrivateConstant(accessFlags) && AsmUtil.isClassClass(typeName)) {
            return null;
        }

        final JavaClassMemberDesc javaField  = this.classDesc.addMember(name, JavaClassMemberDesc.Type.FIELD, accessFlags, this.printer.length());

        this.printer.appendIndented();
        if (this.classDesc.isClass()) {
            this.printer.append(AsmUtil.getVisibility       (accessFlags),
                                AsmUtil.getVolatileModifier (accessFlags),
                                AsmUtil.getTransientModifier(accessFlags),
                                AsmUtil.getStaticModifier   (accessFlags),
                                AsmUtil.getFinalModifier    (accessFlags));
        }

        if (signature != null) {
            final int                   index                 = this.printer.length();
            final FieldSignatureVisitor fieldSignatureVisitor = new FieldSignatureVisitor(this, this.context);

            new SignatureReader(signature).acceptType(fieldSignatureVisitor);
            typeName = this.printer.substring(index);
        } else {
            typeName = this.ensureClassImported(typeName);
            this.printer.append(typeName);
        }
        javaField.setSignature(javaField.getSignature() + ": " + typeName);

        this.printer.append(Printer.SPACE, name);
        if (value != null) {
            final String literal = (value instanceof String ? AsmUtil.getStringLiteral((String) value, this.context) :
                                    value instanceof Long   ? String.valueOf(value) + 'L' :
                                    value instanceof Float  ? String.valueOf(value) + 'f'
                                                            : String.valueOf(value));
            this.constants.put(literal, name);
            this.printer.append(" = ", literal);
        }
        this.printer.append(";\n");
        javaField.setEnd(this.printer.length());

        return null;
    }

    @Override public MethodVisitor visitMethod(int      accessFlags,
                                               String   name,
                                               String   desc,
                                               String   signature,
                                               String[] exceptions) {
        final Type[]                   argumentTypes  = Type.getArgumentTypes(desc);
        final int                      numArguments   = argumentTypes.length;
        final boolean                  isStaticInit   = AsmUtil.isStaticInitializer(name);
        final JavaClassMemberDesc.Type javaMethodType = (isStaticInit ? JavaClassMemberDesc.Type.SPECIAL : JavaClassMemberDesc.Type.METHOD);
        final JavaClassMemberDesc      javaMethod     = this.classDesc.addMember(name, javaMethodType, accessFlags, this.printer.length() + 1);

        //TODO Fix JavaMethodVisitor implementation
        //final MyMethodVisitor methodVisitor = new JavaMethodVisitor(this, this.printer, javaMethod);
        final MyMethodVisitor methodVisitor = new BytecodeMethodVisitor(this, this.printer, javaMethod);

        if (isStaticInit) {
            // Special case of the static initializer of the class
            this.printer.append(Printer.CR)
                        .appendIndented("static");
            javaMethod.setSignature("static class initializer");
        } else {
            // Skip out enum synthetic methods
            if (this.classDesc.isEnum()) {
                // Skip synthetic method "values()" returning an array of enum instances.
                if ("values".equals(name) && javaMethod.isStatic() && numArguments == 0) {
                    this.classDesc.removeMember(javaMethod);
                    return null;
                }
                // Skip synthetic method "valueOf(String name)" returning an enum instance.
                if ("valueOf".equals(name) && javaMethod.isStatic() &&
                    numArguments == 1 && AsmUtil.isStringType(argumentTypes[0])) {
                    this.classDesc.removeMember(javaMethod);
                    return null;
                }
            }

            // Prints out the method modifiers
            this.printer.append('\n')
                        .appendIndented();
            if (this.classDesc.isClass()) {
                this.printer.append(AsmUtil.getVisibility          (accessFlags),
                                    AsmUtil.getAbstractModifier    (accessFlags),
                                    AsmUtil.getSynchronizedModifier(accessFlags),
                                    AsmUtil.getStaticModifier      (accessFlags),
                                    AsmUtil.getNativeModifier      (accessFlags),
                                    AsmUtil.getFinalModifier       (accessFlags));
            }

            // Prints out the method signature and exception list (if any)
            this.appendMethodSignature(methodVisitor, javaMethod, null, name, desc, signature, argumentTypes, exceptions);
        }

        return (javaMethod.isAbstract() && !this.classDesc.isAnnotation() ? null : methodVisitor);
    }

    protected void appendMethodSignature(@NotNull MyMethodVisitor      methodVisitor,
                                         @Nullable JavaClassMemberDesc javaMethodDesc,
                                         String                        ownerClassName,
                                         String                        name,
                                         String                        desc,
                                         String                        signature,
                                         Type[]                        argumentTypes,
                                         String[]                      exceptions) {

	    final boolean          isMethodCall           = (javaMethodDesc == null);
        MethodSignatureDecoder methodSignatureDecoder = null;
        if (signature != null) {
            methodSignatureDecoder = new MethodSignatureDecoder(this, argumentTypes.length, exceptions, this.context);
            new SignatureReader(signature).accept(methodSignatureDecoder);
        }

        final String returnTypeName;

        if (AsmUtil.isConstructor(name)) {
            returnTypeName = null;
            // Prints out the constructor
            // Note: it may either be a constructor definition or a call to "this" or "super" constructor
            this.printer.append(ownerClassName == null                     ? this.simpleClassName :
                                ownerClassName.equals(this.className)      ? "this"               :
                                ownerClassName.equals(this.superClassName) ? "super"
                                                                           : this.ensureClassImported(ownerClassName));
            if (javaMethodDesc != null && ownerClassName == null) {
                javaMethodDesc.setSignature(this.simpleClassName);
            }
        } else {
            // Prints out the method return type and name
            returnTypeName = (signature == null) ? this.ensureClassImported(Type.getReturnType(desc))
                                                 : methodSignatureDecoder.getReturnType();

            if (!isMethodCall) {
                this.printer.append(returnTypeName, Printer.SPACE);
            }

            // If an owner class is specified, write method name as <class-name>.<method-name>
            if (ownerClassName != null) {
                this.printer.append(this.ensureClassImported(ownerClassName), ".");
            }
            this.printer.append(name);
        }

        // Prints out the method argument type list
        final StringBuilder javaMethodSignatureText = (javaMethodDesc == null) ? null : this.context.allocateBuilder();
        final int           lastIndex               = argumentTypes.length - 1;

        this.printer.append('(');
        if (javaMethodSignatureText != null) {
            javaMethodSignatureText.append(javaMethodDesc.getSignature())
                                   .append('(');
        }

        for (int i = 0; i <= lastIndex; i++) {
            final boolean isLast = (i == lastIndex);
            String        argumentType;

            // Specific case of the enum constructors (the 2 first parameters are hidden in signature but not in desc)
            if (this.classDesc.isEnum() && AsmUtil.isConstructor(name)) {
                argumentType = (signature == null || i <= 2) ? this.ensureClassImported(argumentTypes[i])
                                                             : methodSignatureDecoder.getParameterType(i - 2);
            } else {
                argumentType = (signature == null) ? this.ensureClassImported(argumentTypes[i])
                                                   : methodSignatureDecoder.getParameterType(i);
            }

            // Method declaration? Generate parameter names
            final String argumentName = (ownerClassName != null)
                                               ? null
                                               : methodVisitor.generateVariableName(VarType.valueOfType(argumentType), argumentType);

            // Var-args handling
            if (isLast && javaMethodDesc != null && javaMethodDesc.isVarArgs() && AsmUtil.isArrayType(argumentType)) {
                argumentType = argumentType.substring(0, argumentType.length() - 2) + "...";
            }

            this.printer.append(argumentType);
            if (argumentName != null) {
                this.printer.append(Printer.SPACE, argumentName);
            }
            if (javaMethodSignatureText != null) {
                javaMethodSignatureText.append(argumentType);
            }

            if (!isLast) {
                this.printer.append(", ");
                if (javaMethodSignatureText != null) {
                    javaMethodSignatureText.append(", ");
                }
            }
        }
        this.printer.append(')');
        if (javaMethodSignatureText != null) {
            if (returnTypeName == null) {
                javaMethodSignatureText.append(')');
            } else {
                javaMethodSignatureText.append("): ")
                                       .append(returnTypeName);
            }
        }

        if (javaMethodDesc != null) {
            javaMethodDesc.setSignature(javaMethodSignatureText.toString());
            this.context.disposeBuilder(javaMethodSignatureText);
        }

        if (isMethodCall && returnTypeName != null) {
            this.printer.append(": ", returnTypeName);
        } else if (exceptions != null && exceptions.length != 0) {
            // Prints out the exceptions this method may throw
            this.printer.append(Printer.CR, Printer.INDENT)
                        .appendIndented("throws ");
            for (int i = 0; i < exceptions.length; i++) {
                final String exceptionName = exceptions[i];
                if (i > 0) {
                    this.printer.append(", ");
                }

                final String exception = (signature == null) ? this.ensureClassImported(AsmUtil.getQualified(exceptionName))
                                                             : methodSignatureDecoder.getExceptionType(i);
                this.printer.append(exception);
            }
        }

        if (javaMethodDesc != null && javaMethodDesc.isAbstract() && !this.classDesc.isAnnotation()) {
            this.printer.append(";", Printer.CR);
            javaMethodDesc.setEnd(this.printer.length());
        }

        if (methodSignatureDecoder != null) {
            methodSignatureDecoder.dispose();
        }
    }

    @Override public void visitEnd() {
        this.printer.unindent();
        this.printer.appendIndented("}", Printer.CR);

        if (!this.imports.isEmpty()) {
            final String[]      importedClasses   = this.imports.values().toArray(new String[this.imports.size()]);
            final StringBuilder importListBuilder = new StringBuilder(70 * importedClasses.length);

            Arrays.sort(importedClasses);
            for (String importedClass : importedClasses) {
                importListBuilder.append("import ")
                                 .append(importedClass)
                                 .append(';')
                                 .append(Printer.CR);
            }
            importListBuilder.append('\n');
            this.printer.insert(this.importInsertionPoint, importListBuilder.toString());
            this.classDesc.shiftMemberIndices(importListBuilder.length(), 0);

            // Clean memory
            this.imports   = Collections.emptyMap();
            this.constants = Collections.emptyMap();
        }
        this.classDesc.setText(this.printer.toString());
        this.classDesc.sortMembers();
    }
}
