/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.jetbrains.annotations.NotNull;

import com.intellij.mock.MockVirtualFile;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileSystem;
import com.intellij.openapi.vfs.ex.dummy.DummyFileSystem;
import com.intellij.openapi.Disposable;
import com.intellij.util.ArrayUtil;
import com.intellij.util.LocalTimeCounter;

/**
 * An IDEA virtual file, which contents in stored in memory
 */
public class MemoryVirtualFile extends MockVirtualFile implements Disposable {

    private final DummyFileSystem fileSystem;
    private final VirtualFile     parent;
    private final String          name;
    private       byte[]          contents;
    private       long            timestamp;

    public MemoryVirtualFile(VirtualFile parent, String name) {
        super(name);
        this.fileSystem = DummyFileSystem.getInstance();
        this.parent     = parent;
        this.name       = name;
        this.contents   = ArrayUtil.EMPTY_BYTE_ARRAY;
        this.timestamp  = LocalTimeCounter.currentTime();
    }

    @NotNull
    public VirtualFileSystem getFileSystem() {
        return this.fileSystem;
    }

    public String getPath() {
        if (this.parent == null) {
            return this.name;
        } else {
            return this.parent.getPath() + '/' + this.name;
        }
    }

    @NotNull public String getName() {
        return this.name;
    }

    public boolean isWritable() {
        return false;
    }

    public boolean isValid() {
        return true;
    }

    public VirtualFile getParent() {
        return this.parent;
    }

    public long getTimeStamp() {
        return -1L;
    }

    public void refresh(boolean asynchronous, boolean recursive, Runnable postRunnable) {
    }

    public boolean isDirectory() {
        return false;
    }

    public long getLength() {
        return (long) this.contents.length;
    }

    public VirtualFile[] getChildren() {
        return null;
    }

    public InputStream getInputStream() throws IOException {
        return new ByteArrayInputStream(this.contents);
    }

    public OutputStream getOutputStream(Object requestor, final long newModificationStamp, long newTimeStamp) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        return new OutputStream() {
            public void write(int b) throws IOException {
                out.write(b);
            }

            public void write(byte[] b) throws IOException {
                out.write(b);
            }

            public void write(byte[] b, int off, int len) throws IOException {
                out.write(b, off, len);
            }

            public void flush() throws IOException {
                out.flush();
            }

            public void close() throws IOException {
                out.close();
                MemoryVirtualFile.this.contents = out.toByteArray();
                MemoryVirtualFile.this.timestamp = (newModificationStamp < 0L) ? LocalTimeCounter.currentTime() : newModificationStamp;
            }
        };
    }

    public byte[] contentsToByteArray() throws IOException {
        return this.contents;
    }

    public void setContents(byte[] contents) {
        this.contents = contents;
    }

    public long getModificationStamp() {
        return this.timestamp;
    }

    public void setModificationStamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void dispose() {
        this.contents = null;
    }
}