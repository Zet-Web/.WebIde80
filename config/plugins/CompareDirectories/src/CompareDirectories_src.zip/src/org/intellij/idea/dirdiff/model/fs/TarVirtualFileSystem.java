/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.ZipEntryFile;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.vfs.DeprecatedVirtualFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.containers.WeakValueHashMap;

/**
 * This class is an adapter to the IDEA Virtual File System for tar files.
 */
public class TarVirtualFileSystem extends DeprecatedVirtualFileSystem {
    private final TarFile                     tarFile;
    private final String                      tarFilePath;
    private final Map<String, TarVirtualFile> knownVirtualFiles;

    public TarVirtualFileSystem(@NotNull TarFile tarFile) {
        this.tarFile           = tarFile;
        this.tarFilePath       = Files.normalizeFilePath(tarFile.getSourceFile().getPath());
        this.knownVirtualFiles = new WeakValueHashMap<String, TarVirtualFile>();
    }

    @NotNull
    /*package*/ TarFile getTarFile() {
        return this.tarFile;
    }

    @Override
    public boolean isReadOnly() {
        return true;
    }

    @NonNls
    public String getProtocol() {
        return "tar";
    }

    @Nullable
    public VirtualFile findFileByPath(@NotNull @NonNls String path) {
        return this.findFileByRelativePath(path.substring(this.tarFilePath.length() + ZipEntryFile.ZIP_PATH_SEPARATOR.length()));
    }

    @Nullable
    public VirtualFile findFileByRelativePath(@NotNull @NonNls String relativePath) {
        TarVirtualFile virtualFile = this.knownVirtualFiles.get(relativePath);

        if (virtualFile != null) {
            return virtualFile;
        }

        virtualFile = new TarVirtualFile(this, this.tarFile.getEntry(relativePath), relativePath);
        this.knownVirtualFiles.put(relativePath, virtualFile);

        return virtualFile;
    }

    public void refresh(boolean asynchronous) {
        //Do nothing.
    }

    @Nullable
    public VirtualFile refreshAndFindFileByPath(String path) {
        this.refresh(false);
        return this.findFileByPath(path);
    }

    protected void deleteFile(Object requestor, VirtualFile vFile) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    protected void moveFile(Object requestor, VirtualFile vFile, VirtualFile newParent) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    protected void renameFile(Object requestor, VirtualFile vFile, String newName) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    protected VirtualFile createChildFile(Object requestor, VirtualFile vDir, String fileName) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    protected VirtualFile createChildDirectory(Object requestor, VirtualFile vDir, String dirName) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    protected VirtualFile copyFile(Object requestor, VirtualFile virtualFile, VirtualFile newParent, String copyName) throws IOException {
        throw new UnsupportedOperationException("TAR file contents cannot be modified");
    }

    @Override public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }

        final TarVirtualFileSystem that = (TarVirtualFileSystem) o;

        return (this.tarFile     == null ? that.tarFile     == null : this.tarFile    .equals(that.tarFile)) &&
               (this.tarFilePath == null ? that.tarFilePath == null : this.tarFilePath.equals(that.tarFilePath));

    }

    @Override public int hashCode() {
        final int result = (this.tarFile != null ? this.tarFile.hashCode() : 0);

        return 31 * result + (this.tarFilePath != null ? this.tarFilePath.hashCode() : 0);
    }

    public VirtualFile[] getChildren(TarEntry tarEntryRoot) {
        try {
            final List<VirtualFile> children = new ArrayList<VirtualFile>();

            for (TarEntry tarEntry : this.tarFile.getEntries()) {
                if (TarFile.isChild(tarEntry, tarEntryRoot)) {
                    children.add(new TarVirtualFile(tarEntryRoot.getVirtualFileSystem(), tarEntry));
                }
            }

            return children.toArray(new VirtualFile[children.size()]);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
