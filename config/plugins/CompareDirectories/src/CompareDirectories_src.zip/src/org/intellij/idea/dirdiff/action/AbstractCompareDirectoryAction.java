/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.CompareDirectoryView;
import org.intellij.idea.dirdiff.view.IconUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataKeys;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;

/**
 */
public abstract class AbstractCompareDirectoryAction extends AnAction implements ACompareDirectoryAction {

    private CompareDirectoryPanel panel;

    protected AbstractCompareDirectoryAction() {}

    protected AbstractCompareDirectoryAction(final CompareDirectoryPanel panel, @NonNls final String actionKey) {
        super(CompareDirectoryBundle.message("title." + actionKey),
              CompareDirectoryBundle.message("text."  + actionKey),
              IconUtil.createIconWithKey    ("icon."  + actionKey));
        this.panel = panel;
    }

    protected static void setActionKey(@NotNull final Presentation   presentation,
                                       @NotNull @NonNls final String actionKey) {
        presentation.setText       (CompareDirectoryBundle.message("title." + actionKey));
        presentation.setDescription(CompareDirectoryBundle.message("text."  + actionKey));
        presentation.setIcon       (IconUtil.createIconWithKey    ("icon."  + actionKey));
    }

    protected static Project getProject(AnActionEvent event) {
        return DataKeys.PROJECT.getData(event.getDataContext());
    }

    @Nullable public CompareDirectoryPanel getPanel(AnActionEvent event) {
        final Project              project              = getProject(event);
        final CompareDirectoryView compareDirectoryView = CompareDirectoryPlugin.getView(project);

        if (compareDirectoryView != null) {
            this.panel = compareDirectoryView.getCurrentPanel();
            return this.panel;
        }

        // Try to recover...
        return ((project != null && this.panel != null && project.equals(this.panel.getView().getProject())) ? this.panel : null);
    }
}
