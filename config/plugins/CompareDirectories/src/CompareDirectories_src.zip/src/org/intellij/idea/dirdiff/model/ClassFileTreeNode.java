/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.util.List;
import java.util.Vector;

import org.intellij.idea.dirdiff.model.disassemble.JavaClassDesc;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.jetbrains.annotations.NotNull;

import com.intellij.openapi.fileTypes.FileTypeManager;

/**
 */
public class ClassFileTreeNode extends FileTreeNode implements Comparable<ClassFileTreeNode> {

    private static final String SYNTHETIC_FIELDS_PARENT_NAME = "synthetic fields/methods";
    private static final String LAMBDA_EXPR_PARENT_NAME      = "lambda expressions";

    private JavaClassDesc leftClassDesc;
    private JavaClassDesc rightClassDesc;

    public ClassFileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model, ReadableFile leftFile, ReadableFile rightFile) {
        super(name, parent, model, leftFile, rightFile);
    }

    public ClassFileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model, ReadableFile leftFile, ReadableFile rightFile, FileStateEnum state) {
        super(name, parent, model, leftFile, rightFile, state);
    }

    public ClassFileTreeNode(String name, ComparedTreeNode parent, FileTreeModel model, ReadableFile file, FileStateEnum state) {
        super(name, parent, model, file, file, state);
    }

    public void analyze(MyClassVisitorContext context, boolean generateText, boolean analyzeMethodCode) {
        if (this.state == FileStateEnum.DIFFERENT) {
            this.disassemble(this.getLeftFile(), this.getRightFile(), generateText, analyzeMethodCode, context, null);
        } else {
            this.disassemble(this.getLeftFile(), null,                generateText, analyzeMethodCode, context, this.state);
        }
    }

    private void disassemble(ReadableFile          leftFile,
                             ReadableFile          rightFile,
                             boolean               generateText,
                             boolean               analyzeMethodCode,
                             MyClassVisitorContext context,
                             FileStateEnum         state) {
        this.leftClassDesc  = Files.getJavaClassDesc(leftFile, generateText, analyzeMethodCode, context);
        this.rightClassDesc = (rightFile == null) ? this.leftClassDesc
                                                  : Files.getJavaClassDesc(rightFile, generateText, analyzeMethodCode, context);

        // Removes all children but inner classes
        if (this.children != null) {
            for (int index = this.children.size(); --index >= 0; ) {
                if (!(this.children.get(index) instanceof ClassFileTreeNode)) {
                    this.children.remove(index);
                }
            }
        }

        // Add nodes for every class member
        if (state != null) {
            this.addMemberNodes(state);
        } else {
            this.addMemberNodes();
        }

        // Case of differences in differences in parts of the class non parsed by ASM.
        if (this.state == FileStateEnum.DIFFERENT && this.areAllMembersInState(FileStateEnum.IDENTICAL)) {
            this.setState(FileStateEnum.DIFFERENT_NON_SIGNIFICANT);
        }
    }

    private void addMemberNodes(@NotNull FileStateEnum state) {
        JavaFieldTreeNode accessMethodNode = null;

        for (JavaClassMemberDesc member : this.leftClassDesc.getMembers()) {
            ComparedTreeNode parent;

            if (!member.isLambda()) {
                if (member.isSynthetic()) {
                    accessMethodNode = this.getAndUpdateSyntheticMemberTreeNode(accessMethodNode, member, member, state);

                    parent = accessMethodNode;
                } else {
                    parent = this;
                }
                this.addMemberNode(member.getSignature(), parent, member, member, state);
            }
        }

        // Process lambdas after all other methods
        for (JavaClassMemberDesc member : this.leftClassDesc.getMembers()) {
            ComparedTreeNode parent;

            if (member.isLambda()) {
                parent = this.getLambdaCallerTreeNode(member, member);
                if (parent == null) {
                    parent = this;
                }
                this.addMemberNode(member.getSignature(), parent, member, member, state);
            }
        }

        if (accessMethodNode != null) {
            this.appendChildNode(accessMethodNode);
        }
    }

    /** Only callable if this node state (and its children) is unknown */
    private void addMemberNodes() {
        final List<JavaClassMemberDesc> leftMembers      = this.leftClassDesc .getMembers();
        final List<JavaClassMemberDesc> rightMembers     = this.rightClassDesc.getMembers();
        final int                       numLeftMembers   = leftMembers .size();
        final int                       numRightMembers  = rightMembers.size();
        int                             leftIndex        = 0;
        int                             rightIndex       = 0;
        JavaClassMemberDesc             leftMember       = (numLeftMembers  == 0) ? null : leftMembers .get(0);
        JavaClassMemberDesc             rightMember      = (numRightMembers == 0) ? null : rightMembers.get(0);
        JavaFieldTreeNode               accessMethodNode = null;

        while (leftMember != null || rightMember != null) {
            final FileStateEnum state       = getFieldNodeState(leftMember, rightMember);
            final boolean       isSynthetic = (state == FileStateEnum.LEFT_ONLY ? leftMember .isSynthetic()
                                                                                : rightMember.isSynthetic());
            final boolean       isLambda    = (state == FileStateEnum.LEFT_ONLY ? leftMember .isLambda()
                                                                                : rightMember.isLambda());
            final ComparedTreeNode parent;

            if (isLambda) {
                parent = this.getLambdaCallerTreeNode(leftMember, rightMember);
            } else if (isSynthetic) {
                accessMethodNode = this.getAndUpdateSyntheticMemberTreeNode(accessMethodNode, leftMember, rightMember, state);
                parent = accessMethodNode;
            } else {
                parent = this;
            }

            //noinspection EnumSwitchStatementWhichMissesCases
            switch (state) {
                case LEFT_ONLY:  this.addMemberNode(leftMember .getSignature(), parent, leftMember,  leftMember,  state); break;
                case RIGHT_ONLY: this.addMemberNode(rightMember.getSignature(), parent, rightMember, rightMember, state); break;
                default:         this.addMemberNode(leftMember .getSignature(), parent, leftMember,  rightMember, state); break;
            }

            if (state != FileStateEnum.RIGHT_ONLY) {
                leftMember.disposeByteVector();
                leftIndex++;
                leftMember = (leftIndex >= numLeftMembers) ? null : leftMembers.get(leftIndex);
            }
            if (state != FileStateEnum.LEFT_ONLY) {
                rightMember.disposeByteVector();
                rightIndex++;
                rightMember = (rightIndex >= numRightMembers) ? null : rightMembers.get(rightIndex);
            }
        }

        if (accessMethodNode != null) {
            this.appendChildNode(accessMethodNode);
        }
    }

    private void addMemberNode(String signature, ComparedTreeNode parent, JavaClassMemberDesc leftMember, JavaClassMemberDesc rightMember, FileStateEnum state) {
        parent.appendChildNode(new JavaFieldTreeNode(signature, parent, this.getModel(), leftMember, rightMember, state));
    }

    private JavaFieldTreeNode getLambdaCallerTreeNode(JavaClassMemberDesc leftMember,
                                                      JavaClassMemberDesc rightMember) {
        final JavaClassMemberDesc methodDesc = this.leftClassDesc.getLambdaCaller((leftMember == null) ? rightMember.getName() : leftMember.getName());

        if (methodDesc != null && this.children != null) {
            synchronized (this) {
                for (final Object currentNode : this.children) {
                    if (currentNode instanceof JavaFieldTreeNode) {
                        final JavaFieldTreeNode node = (JavaFieldTreeNode) currentNode;

                        if (methodDesc == node.getLeftMember() || methodDesc == node.getRightMember()) {
                            return node;
                        }
                    }
                }
            }
        }
        return null;
    }

    private JavaFieldTreeNode getAndUpdateSyntheticMemberTreeNode(JavaFieldTreeNode   syntheticMemberTreeNode,
                                                                  JavaClassMemberDesc leftMember,
                                                                  JavaClassMemberDesc rightMember,
                                                                  FileStateEnum       state) {
        if (syntheticMemberTreeNode == null) {
            final JavaClassMemberDesc member    = (rightMember == null) ? leftMember : rightMember;
            final JavaClassMemberDesc newMember = new JavaClassMemberDesc(member.getClassDesc(), "",
                                                                          JavaClassMemberDesc.Type.META_FIELD,
                                                                          member.getAccessFlags(), 0);

            syntheticMemberTreeNode = new JavaFieldTreeNode(SYNTHETIC_FIELDS_PARENT_NAME, this, this.getModel(),
                                                           newMember, newMember, state);
        } else if (syntheticMemberTreeNode.state == FileStateEnum.IDENTICAL && state == FileStateEnum.DIFFERENT) {
            syntheticMemberTreeNode.setState(FileStateEnum.DIFFERENT);
        }
        return syntheticMemberTreeNode;
    }

    private boolean areAllMembersInState(FileStateEnum state) {
        if (this.children != null) {
            for (ComparedTreeNode node : (Vector<ComparedTreeNode>) this.children) {
                if (node.state != state) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override public final boolean isIgnored() {
        // Don't ignore class node if java fields are ignored
        return (FileTypeManager.getInstance().isFileIgnored(this.getName()) ||
                this.getModel().isAnyMatchWithExcludedFileMasks(this.getLeftFile().getPath(), this.getRightFile().getPath()));
    }

    public final int memberIndexOf(JavaClassMemberDesc member) {
        return this.indexOf(member, FileTreeModel.javaClassMemberComparator);
    }

    public JavaFieldTreeNode getSyntheticParentNode() {
        return this.getSyntheticParentNode(SYNTHETIC_FIELDS_PARENT_NAME);
    }

    public JavaFieldTreeNode getLambdaParentNode() {
        return this.getSyntheticParentNode(LAMBDA_EXPR_PARENT_NAME);
    }

    private JavaFieldTreeNode getSyntheticParentNode(@NotNull String nodeName) {
        for (int index = this.children.size(); --index >= 0; ) {
            final JavaFieldTreeNode child     = (JavaFieldTreeNode) this.children.get(index);
            final String            childName = child.getName();

            if (nodeName.equals(childName)) {
                return child;
            }
        }
        return null;
    }

    private static FileStateEnum getFieldNodeState(JavaClassMemberDesc leftMember, JavaClassMemberDesc rightMember) {
        if (leftMember == null) {
            return FileStateEnum.RIGHT_ONLY;
        } else if (rightMember == null) {
            return FileStateEnum.LEFT_ONLY;
        }

        final int compare = leftMember.compareTo(rightMember);

        if (compare != 0) {
            return (compare < 0) ? FileStateEnum.LEFT_ONLY : FileStateEnum.RIGHT_ONLY;
        }

        final boolean equals;

        if (leftMember.getByteVector() != null && rightMember.getByteVector() != null) {
            equals = leftMember.getByteVector().equals(rightMember.getByteVector());
        } else {
            equals = leftMember.getText()      .equals(rightMember.getText());
        }
        return (equals ? FileStateEnum.IDENTICAL : FileStateEnum.DIFFERENT);
    }

    @NotNull
    @Override protected ComparedTreeNode split(ComparedTreeNode parentNode) {
        final ClassFileTreeNode splitNode = (ClassFileTreeNode) super.split(parentNode);

        splitNode.rightClassDesc = this.rightClassDesc;
        splitNode.leftClassDesc  = this.rightClassDesc;
        this     .rightClassDesc = this.leftClassDesc;

        return splitNode;
    }

    public JavaClassDesc getLeftClassDesc() {
        return this.leftClassDesc;
    }

    public void setLeftClassDesc(JavaClassDesc leftClassDesc) {
        this.leftClassDesc = leftClassDesc;
    }

    public JavaClassDesc getRightClassDesc() {
        return this.rightClassDesc;
    }

    public void setRightClassDesc(JavaClassDesc rightClassDesc) {
        this.rightClassDesc = rightClassDesc;
    }

    public int compareTo(ClassFileTreeNode other) {
        return this.leftClassDesc.compareTo(this.rightClassDesc);
    }
}
