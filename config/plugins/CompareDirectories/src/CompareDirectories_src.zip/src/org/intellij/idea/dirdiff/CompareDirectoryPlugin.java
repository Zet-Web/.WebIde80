/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff;

import java.util.HashMap;
import java.util.Map;

import org.intellij.idea.dirdiff.util.Commands;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.view.CompareDirectoryView;
import org.intellij.idea.dirdiff.view.IconUtil;
import org.intellij.idea.dirdiff.view.PanelConfiguration;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Disposer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowAnchor;
import com.intellij.openapi.wm.ToolWindowManager;

/**
 * Plugin entry point class.
 * Handles IDEA project opening/closing and persistent configuration;
 * provides general tools for the rest of the plugin code: file extension
 * management, access to plugin logger and toolwindow...
 */
public class CompareDirectoryPlugin implements ProjectComponent, JDOMExternalizable {
    @NonNls private static final String COMPARE_DIRECTORY_LOG           = "#org.intellij.idea.dirdiff.CompareDirectoryPlugin";
    @NonNls public  static final String COMPARE_DIRECTORY_PLUGIN_ID     = "Compare Directories";
    @NonNls public  static final String COMPARE_DIRECTORY_TOOLWINDOW_ID = COMPARE_DIRECTORY_PLUGIN_ID;
    @NonNls public  static final String COMPARE_DIRECTORY_HELP_ID       = "managingFiles.dirdiff";
    @NonNls public  static final String ACTION_GROUP_ID                 = "DirectoryCompare_PopupActionGroup";
    @NonNls public  static final String ACTION_TOOLBAR_ID               = "DirectoryCompare_ActionToolbar";
    @NonNls public  static final String ACTION_POPUP_ID                 = "DirectoryCompare_ActionPopup";

    @NonNls private static final String ASSOCIATE_PLAIN_EXTENSION       = "associateExtension";
    @NonNls private static final String DISSOCIATE_PLAIN_EXTENSION      = "dissociateExtension";

    private final Project               project;
    private CompareDirectoryView        view;
    private PanelConfiguration          lastConfiguration;
    private final Map<String, Integer>  registeredExtensions;


    public CompareDirectoryPlugin(Project project) {
        this.project              = project;
        this.lastConfiguration    = new PanelConfiguration();
        this.registeredExtensions = new HashMap<String, Integer>();
    }

    public void projectOpened() {
        final ToolWindowManager toolWindowManager = ToolWindowManager.getInstance(this.project);
        final ToolWindow        toolWindow        = toolWindowManager.registerToolWindow(COMPARE_DIRECTORY_TOOLWINDOW_ID, true, ToolWindowAnchor.LEFT);

        toolWindow.setAvailable(false, null);
        toolWindow.setIcon(IconUtil.createIconWithKey("icon.tool-window"));

        this.view = new CompareDirectoryView(this, toolWindow.getContentManager());
        this.project.putUserData(new Key<CompareDirectoryView>(COMPARE_DIRECTORY_PLUGIN_ID), this.view);

        Disposer.register(toolWindow.getContentManager(), this.view);
    }

    public void projectClosed() {
        if (this.view != null) {
            this.project.putUserData(new Key<CompareDirectoryView>(COMPARE_DIRECTORY_PLUGIN_ID), null);
            ToolWindowManager.getInstance(this.project).unregisterToolWindow(COMPARE_DIRECTORY_TOOLWINDOW_ID);
        }
    }

    @NotNull
    public String getComponentName() {
        return COMPARE_DIRECTORY_PLUGIN_ID;
    }

    public void initComponent() {
        this.view = null;
    }

    public void disposeComponent() {}

    @Nullable
    public static CompareDirectoryPlugin getInstance(@Nullable Project project) {
        return ((project == null) ? null : project.getComponent(CompareDirectoryPlugin.class));
    }

    @Nullable
    public static ToolWindow getToolWindow(@Nullable Project project) {
        return ((project == null) ? null : ToolWindowManager.getInstance(project).getToolWindow(CompareDirectoryPlugin.COMPARE_DIRECTORY_TOOLWINDOW_ID));
    }

    @Nullable
    public static CompareDirectoryView getView(@Nullable Project project) {
        final CompareDirectoryPlugin plugin = CompareDirectoryPlugin.getInstance(project);

        return ((plugin == null) ? null : plugin.view);
    }

    @NotNull
    public static Logger getLogger() {
        return Logger.getInstance(CompareDirectoryPlugin.COMPARE_DIRECTORY_LOG);
    }

    public Project getProject() {
        return this.project;
    }

    @NotNull public CompareDirectoryView getView() {
        return this.view;
    }

    public PanelConfiguration getLastConfiguration() {
        return this.lastConfiguration;
    }

    public void setLastConfiguration(PanelConfiguration lastConfiguration) {
        this.lastConfiguration = lastConfiguration;
    }

    /**
     * If IDEA file type is UNKNOWN, temporarily associate extension with the PLAIN_TEXT
     * file type so that the IDEA diff window or texte editor can be opened.
     * Extension association is cancelled by {@link #unregisterUnknownExtension}.
     * Registration count is stored to allow editor/diff window closing in any order.
     * @param file          the file whose extension is to be registered
     * @param fileExtension the file extension string
     * @return <tt>true</tt> if the extension is registered, <tt>false</tt> otherwise.
     */
    public boolean registerUnknownExtension(@Nullable final ReadableFile file,
                                            @Nullable final String       fileExtension) {
        final String fileTypeName = ((file == null) ? "" : file.getFileType().getName());

        if (fileExtension != null &&
            (Files.UNKNOWN_FILE_TYPE_NAME.equals(fileTypeName) ||
             (Files.PLAIN_TEXT_FILE_TYPE_NAME.equals(fileTypeName) &&
              this.isUnknownExtensionRegistered(fileExtension)))) {

            Integer numAssociations = this.registeredExtensions.get(fileExtension);

            if (numAssociations == null) {
                numAssociations = 1;
                Commands.runWriteCommand(this.project, new Runnable() {
                        public void run() {
                            FileTypeManager.getInstance().associateExtension(StdFileTypes.PLAIN_TEXT, fileExtension);
                        }
                    }, ASSOCIATE_PLAIN_EXTENSION, CompareDirectoryPlugin.ACTION_GROUP_ID);
            } else {
                numAssociations++;
            }
            this.registeredExtensions.put(fileExtension, numAssociations);

            return true;
        }

        return false;
    }

    /**
     * @see #registerUnknownExtension
     * @param file          the file whose extension is to be unregistered
     * @param fileExtension the file extension string
     */
    public void unregisterUnknownExtension(@Nullable final ReadableFile file,
                                           @Nullable final String       fileExtension) {
        final String fileTypeName = ((file == null) ? "" : file.getFileType().getName());

        if (fileExtension != null && Files.PLAIN_TEXT_FILE_TYPE_NAME.equals(fileTypeName)) {
            final Integer numAssociations = this.registeredExtensions.get(fileExtension);

            if (numAssociations != null) {
                if (numAssociations <= 1) {
                    CompareDirectoryPlugin.this.registeredExtensions.remove(fileExtension);
                    Commands.runWriteCommand(CompareDirectoryPlugin.this.project, new Runnable() {
                            public void run() {
                                FileTypeManager.getInstance().removeAssociatedExtension(StdFileTypes.PLAIN_TEXT, fileExtension);
                            }
                        }, DISSOCIATE_PLAIN_EXTENSION, CompareDirectoryPlugin.ACTION_GROUP_ID);
                } else {
                    this.registeredExtensions.put(fileExtension, numAssociations - 1);
                }
            }
        }
    }

    public final boolean isUnknownExtensionRegistered(@Nullable final String fileExtension) {
        return this.registeredExtensions.containsKey(fileExtension);
    }

    public void writeExternal(Element element) throws WriteExternalException {
        this.lastConfiguration.writeExternal(element);
    }

    public void readExternal(Element element) throws InvalidDataException {
        this.lastConfiguration.readExternal(element);
    }
}
