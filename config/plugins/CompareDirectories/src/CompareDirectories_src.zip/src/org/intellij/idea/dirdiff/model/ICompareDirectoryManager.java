/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import org.jetbrains.annotations.NotNull;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;

/**
 * Fa�ade interface to system operations.
 */
public interface ICompareDirectoryManager {

    void          refreshCachedFiles       ();
    void          refreshCachedFiles       (@NotNull ComparedTreeNode rootNode, boolean redraw);
    boolean       saveFiles                (@NotNull ReadableFile[] files);
    boolean       saveFiles                (@NotNull ComparedTreeNode[] nodes);
    void          saveFilesAndRefreshStates(@NotNull ComparedTreeNode... nodes);
    void          saveAllDocuments         ();

    void          refreshNode              (@NotNull ComparedTreeNode node);
    void          refreshNode              (@NotNull ComparedTreeNode node, boolean recursive, boolean asynchronous);

    void          execute                  (@NotNull Runnable runnable, boolean asynchronously);

    void          showErrorMessage         (String text, String title);
    boolean       doesUserConfirm          (String text, String title);
    int           doesUserConfirm2         (String text, String title);

    MyClassVisitorContext getClassVisitorContext();
}