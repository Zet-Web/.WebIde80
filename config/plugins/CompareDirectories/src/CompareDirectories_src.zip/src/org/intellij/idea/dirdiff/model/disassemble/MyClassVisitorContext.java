/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.Map;

import org.intellij.idea.dirdiff.util.ObjectPool;
import org.intellij.idea.dirdiff.util.Pool;
import org.jetbrains.asm4.Type;

import gnu.trove.THashMap;

/**
 * Keeps track of a context shared by several class visitors.
 */
public class MyClassVisitorContext {

    private final Map<Type, String> classNameCache;
    private final StringBuilderPool builderCache;
    private final ByteArrayPool     byteArrayCache;

    public MyClassVisitorContext() {
        this.classNameCache = new THashMap<Type, String>();
        this.builderCache   = new StringBuilderPool();
        this.byteArrayCache = new ByteArrayPool();
    }

    public String getClassName(Type type) {
        String className = this.classNameCache.get(type);

        if (className == null) {
            className = type.getClassName();
            this.classNameCache.put(type, className);
        }
        return className;
    }

    public StringBuilder allocateBuilder() {
        final StringBuilder builder = this.builderCache.acquire();

        builder.setLength(0);
        return builder;
    }

    public void disposeBuilder(StringBuilder builder) {
        this.builderCache.dispose(builder);
    }

    public Pool<byte[]> getByteArrayPool() {
        return this.byteArrayCache;
    }

    /**
     * This class allows the {@link StringBuilder} instances reuse performing non-blocking allocation and dispose.
     */
    private static class StringBuilderPool extends ObjectPool<StringBuilder> {

        public StringBuilderPool() {
            super(new InstanceFactory<StringBuilder>() {
                          public StringBuilder createInstance() {
                              return new StringBuilder();
                          }
                      },
                  new InstanceDisposer<StringBuilder>() {
                          public void disposeInstance(final StringBuilder instance) {
                              if ((instance.capacity() & 0xFFFFFC00) != 0) {  // More than 1024 characters?
                                  instance.setLength(16);       // Then trim capacity to 16 characters only
                                  instance.trimToSize();
                              }
                              instance.setLength(0);
                          }
                      },
                  false);
        }
    }

    /**
     * This class allows the byte arrays reuse performing non-blocking allocation and dispose.
     */
    private static class ByteArrayPool extends ObjectPool<byte[]> {
        private static final int STANDARD_BYTE_BLOCK_SIZE = 1024;

        public ByteArrayPool() {
            super(new InstanceFactory<byte[]>() {
                          public byte[] createInstance() {
                              return new byte[STANDARD_BYTE_BLOCK_SIZE];
                          }
                      },
                  new InstanceDisposer<byte[]>() {
                          public void disposeInstance(final byte[] instance) {}
                      },
                  false);
        }
    }
}
