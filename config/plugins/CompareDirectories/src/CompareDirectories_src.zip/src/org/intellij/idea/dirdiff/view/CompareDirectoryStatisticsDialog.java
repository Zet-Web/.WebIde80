/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Window;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.model.FileTreeModel;
import org.intellij.idea.dirdiff.model.TreeStatistics;
import org.intellij.idea.dirdiff.util.Commands;

import com.intellij.openapi.application.ApplicationManager;

public class CompareDirectoryStatisticsDialog extends JDialog {
    private JPanel  contentPane;
    private JButton okButton;
    private JLabel  numDirectoryLabel;
    private JLabel  numMergedLabel;
    private JLabel  numIdenticalLabel;
    private JLabel  numDifferentLabel;
    private JLabel  numDifferentInBlanksLabel;
    private JLabel  numNonSignificantlyDifferentLabel;
    private JLabel  numLeftRightLabel;
    private JLabel  numLeftOnlyLabel;
    private JLabel  numRightOnlyLabel;
    private JLabel  numJavaFieldsMethodsLabel;
    private JLabel  numUncheckedLabel;
    private JLabel  inProgressLabel;

    public CompareDirectoryStatisticsDialog(FileTreeModel model) {
        this.setTitle(CompareDirectoryBundle.message("statistics.title"));
        this.setContentPane(this.contentPane);
        this.setModal(true);
        this.getRootPane().setDefaultButton(this.okButton);

        this.okButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    CompareDirectoryStatisticsDialog.this.dispose();
                }
            });

        final TreeStatistics statistics = new TreeStatistics();

        if (model == null) {
            statistics.setDone(true);
            this.updateLabels(statistics);
        } else {
            ApplicationManager.getApplication().executeOnPooledThread(new StatisticsUpdateThread(statistics));
            model.retrieveStatistics(statistics);
        }
    }

    private void updateLabels(final TreeStatistics statistics) {
        this.inProgressLabel.setVisible(!statistics.isDone());

        Commands.invoke(new Runnable() {
                public void run() {
                    final CompareDirectoryStatisticsDialog dialog = CompareDirectoryStatisticsDialog.this;

                    setLabelText(dialog.numLeftRightLabel,                 statistics.getNumLeftRightLeaves());
                    setLabelText(dialog.numLeftOnlyLabel,                  statistics.getNumLeftOnlyLeaves());
                    setLabelText(dialog.numRightOnlyLabel,                 statistics.getNumRightOnlyLeaves());
                    setLabelText(dialog.numDirectoryLabel,                 statistics.getNumDirectories());
                    setLabelText(dialog.numMergedLabel,                    statistics.getNumMergedNodes());
                    setLabelText(dialog.numIdenticalLabel,                 statistics.getNumIdenticalLeaves());
                    setLabelText(dialog.numDifferentLabel,                 statistics.getNumDifferentLeaves());
                    setLabelText(dialog.numDifferentInBlanksLabel,         statistics.getNumDifferentInBlanksLeaves());
                    setLabelText(dialog.numNonSignificantlyDifferentLabel, statistics.getNumNonSignificantlyDifferentLeaves());
                    setLabelText(dialog.numUncheckedLabel,                 statistics.getNumUncheckedLeaves());
                    setLabelText(dialog.numJavaFieldsMethodsLabel,         statistics.getNumJavaFieldsMethods());
                }
            });
    }

    private static void setLabelText(JLabel label, int textIntValue) {
        label.setText(Integer.toString(textIntValue));
    }

    private class StatisticsUpdateThread extends Thread {
        private final TreeStatistics statistics;

        private StatisticsUpdateThread(TreeStatistics statistics) {
            this.statistics = statistics;
        }

        @Override public void run() {
            long timeout = 350L;

            while (!this.statistics.isDone()) {
                try {
                    synchronized (this) {
                        this.wait(timeout);
                    }
                } catch (InterruptedException e) {
                    // Ignore.
                }

                timeout = 600L;
                CompareDirectoryStatisticsDialog.this.updateLabels(this.statistics);
                CompareDirectoryStatisticsDialog.this.repaint();
            }
        }
    }

    public static void main(String[] args) {
        final Window dialog = new CompareDirectoryStatisticsDialog(null);
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
