/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.Arrays;

import gnu.trove.TObjectIntHashMap;
import org.intellij.idea.dirdiff.util.ByteVector;
import org.jetbrains.asm4.AnnotationVisitor;
import org.jetbrains.asm4.Attribute;
import org.jetbrains.asm4.Handle;
import org.jetbrains.asm4.Label;
import org.jetbrains.asm4.MethodVisitor;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

class BinaryMethodParser extends MethodVisitor {

    private final MyClassVisitor           classVisitor;
    private final JavaClassMemberDesc      javaMethod;
    private final ByteVector               bytes;
    private final TObjectIntHashMap<Label> labels;

    public BinaryMethodParser(JavaClassMemberDesc javaMethod, MyClassVisitor classVisitor, MyClassVisitorContext context) {
        super(Opcodes.ASM4);
        this.classVisitor = classVisitor;
        this.javaMethod   = javaMethod;
        this.labels       = new TObjectIntHashMap<Label>();
        this.bytes        = new ByteVector(context.getByteArrayPool());
        javaMethod.setByteVector(this.bytes);
    }

    @Override public AnnotationVisitor visitAnnotationDefault()                                              { return null; }
    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible)                         { return null; }
    @Override public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible) { return null; }

    @Override public void visitAttribute(Attribute attr)                                               {}
    @Override public void visitCode()                                                                  {}
    @Override public void visitLineNumber(int line, Label start)                                       {}
    @Override public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {}
    @Override public void visitMaxs(int maxStack, int maxLocals)                                       {}
    @Override public void visitEnd()                                                                   {}

    @Override public void visitInsn(int opcode) {
        this.bytes.putByte(opcode);
    }

    @Override public void visitIntInsn(int opcode, int operand) {
        this.bytes.putByte(opcode)
                  .putInt (operand);
    }

    @Override public void visitVarInsn(int opcode, int var) {
        this.bytes.putByte(opcode)
                  .putInt (var);
    }

    @Override public void visitTypeInsn(int opcode, String desc) {
        this.bytes.putByte(opcode)
                  .putString(desc);
    }

    @Override public void visitFieldInsn(int opcode, String owner, String name, String desc) {
        this.bytes.putByte(opcode)
                  .putString(desc)
                  .putByte(' ')
                  .putString(owner)
                  .putByte('.')
                  .putString(name);
    }

    @Override public void visitMethodInsn(int opcode, String owner, String name, String desc) {
        this.bytes.putByte(opcode)
                  .putString(desc)
                  .putByte(' ')
                  .putString(owner)
                  .putByte('.')
                  .putString(name);
    }

    @Override public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs) {
        this.bytes.putByte(Opcodes.INVOKEDYNAMIC)
                  .putString(desc)
                  .putByte(' ')
                  .putString(name)
                  .putByte(' ')
                  .putString(bsm.getOwner())
                  .putByte('.')
                  .putString(bsm.getName())
                  .putByte('(')
                  .putString(Arrays.asList(bsmArgs).toString())
                  .putByte(')');

        for (final Object bsmArg : bsmArgs) {
            if (bsmArg instanceof Handle) {
                final Handle handle = (Handle) bsmArg;

                switch (handle.getTag()) {
                    case Opcodes.H_INVOKEVIRTUAL:
                    case Opcodes.H_INVOKESTATIC:
                    case Opcodes.H_INVOKESPECIAL:
                    case Opcodes.H_NEWINVOKESPECIAL:
                    case Opcodes.H_INVOKEINTERFACE:
                        final String handleName = handle.getName();

                        if (AsmUtil.isLambdaMethod(handleName)) {
                            this.classVisitor.getClassDesc().addLambdaCaller(handleName, this.javaMethod);
                        }
                        break;
                }
            }
        }
    }

    @Override public void visitJumpInsn(int opcode, Label label) {
        this.bytes.putByte(opcode)
                  .putInt (this.getLabelIndex(label));
    }

    @Override public void visitLabel(Label label) {
        this.bytes.putInt(this.getLabelIndex(label));
    }

    @Override public void visitLdcInsn(Object cst) {
        this.bytes.putByte(Opcodes.LDC);
        this.putLiteral(cst);
    }

    @Override public void visitIincInsn(int var, int increment) {
        this.bytes.putByte(Opcodes.IINC)
                  .putInt (var)
                  .putInt (increment);
    }

    @Override public void visitTableSwitchInsn(int min, int max, Label defaultLabel, Label[] labels) {
        this.bytes.putByte(Opcodes.TABLESWITCH);
        for (int index = 0; index < labels.length; index++) {
            this.bytes.putInt(min + index)
                      .putInt(this.getLabelIndex(labels[index]));
        }
        this.bytes.putInt(this.getLabelIndex(defaultLabel));
    }

    @Override public void visitLookupSwitchInsn(Label defaultLabel, int[] keys, Label[] labels) {
        this.bytes.putByte(Opcodes.LOOKUPSWITCH);
        for (int index = 0; index < labels.length; index++) {
            this.bytes.putInt(keys[index])
                      .putInt(this.getLabelIndex(labels[index]));
        }
        this.bytes.putInt(this.getLabelIndex(defaultLabel));
    }

    @Override public void visitMultiANewArrayInsn(String desc, int dims) {
        this.bytes.putByte(Opcodes.MULTIANEWARRAY)
                  .putByte(dims)
                  .putString(desc);
    }

    @Override public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
        this.bytes.putByte(253)
                  .putInt (this.getLabelIndex(start))
                  .putInt (this.getLabelIndex(end))
                  .putInt (this.getLabelIndex(handler))
                  .putString((type == null) ? "Ljava/lang/Throwable;" : type);
    }

    @Override public void visitLocalVariable(String name, String desc, String signature,
                                             Label start, Label end, int index) {
        this.bytes.putByte(254)
                  .putString(name)
                  .putByte(' ')
                  .putString(desc)
                  .putInt (this.getLabelIndex(start))
                  .putInt (this.getLabelIndex(end));
    }

    private void putLiteral(Object cst) {
        if (cst instanceof String) {
            this.bytes.putString((CharSequence) cst);
        } else if (cst instanceof Type) {
            this.bytes.putString(((Type) cst).getDescriptor());
        } else if (cst instanceof Integer) {
            this.bytes.putInt((Integer) cst);
        } else if (cst instanceof Long) {
            this.bytes.putLong((Long) cst);
        } else if (cst instanceof Double) {
            this.bytes.putDouble((Double) cst);
        } else if (cst instanceof Float) {
            this.bytes.putFloat((Float) cst);
        } else {
            assert false : cst.getClass().getName();
        }
    }

    private int getLabelIndex(Label label) {
        int index = this.labels.get(label);

        if (index == 0) {
            index = this.labels.size() + 1;
            this.labels.put(label, index);
        }
        return index;
    }
}