/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.Files;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.mock.MockVirtualFile;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileSystem;

/**
 * This class is an adapter to the IDEA Virtual File system for tar file entries.
 */
public class TarVirtualFile extends MockVirtualFile {
    private final TarVirtualFileSystem tarFileSystem;
    private final TarEntry             tarEntry;
    private String                     parentPath;
    private String                     name;

    public TarVirtualFile(TarVirtualFileSystem tarFileSystem, TarEntry tarEntry) {
        this(tarFileSystem, tarEntry, tarEntry.getName());
    }

    public TarVirtualFile(TarVirtualFileSystem tarFileSystem, TarEntry tarEntry, String tarEntryName) {
        super(tarEntryName);
        this.tarFileSystem = tarFileSystem;
        this.tarEntry      = tarEntry;
        this.extractParentPathAndSimpleName(tarEntryName);
    }

    @NotNull @NonNls
    public String getName() {
        return this.name;
    }

    @NotNull
    public VirtualFileSystem getFileSystem() {
        return this.tarFileSystem;
    }

    public String getPath() {
        return this.tarEntry.getName();
    }

    public boolean isWritable() {
        return false;
    }

    public boolean isDirectory() {
        return this.tarEntry.isDirectory();
    }

    public boolean isValid() {
        return true;
    }

    @Nullable
    public VirtualFile getParent() {
        return (this.parentPath.length() == 0)
                    ? LocalFileSystem.getInstance().findFileByIoFile(this.tarFileSystem.getTarFile().getSourceFile())
                    : this.tarFileSystem.findFileByRelativePath(this.parentPath);
    }

    public VirtualFile[] getChildren() {
        return this.tarFileSystem.getChildren(this.tarEntry);
    }

    @NotNull
    public OutputStream getOutputStream(Object requestor, long newModificationStamp, long newTimeStamp) throws IOException {
        throw new UnsupportedOperationException();
    }

    @NotNull
    public byte[] contentsToByteArray() throws IOException {
        return this.getFileContents();
    }

    public long getTimeStamp() {
        return this.tarEntry.getModTimeAsLong();
    }

    @Override public long getModificationStamp() {
        return this.getTimeStamp();
    }

    public long getLength() {
        return this.tarEntry.getSize();
    }

    public void refresh(boolean asynchronous, boolean recursive, Runnable postRunnable) {
        //Do nothing
    }

    public InputStream getInputStream() throws IOException {
        return this.tarFileSystem.getTarFile().getInputStream(this.tarEntry);
    }

    private void extractParentPathAndSimpleName(String tarEntryName) {
        final String fullPath   = tarEntryName;
        final int    endIndex   = fullPath.length() - ((fullPath.charAt(fullPath.length() - 1) == '/') ? 1 : 0);
        final int    beginIndex = fullPath.lastIndexOf('/', endIndex - 1) + 1;

        this.name       = fullPath.substring(beginIndex, endIndex);
        this.parentPath = fullPath.substring(0, beginIndex);
    }

    private byte[] getFileContents() {
        InputStream inputStream = null;

        try {
            inputStream = this.getInputStream();

            final List<Pair<byte[], Integer>> blockList = new ArrayList<Pair<byte[], Integer>>();
            byte[]                            block     = new byte[Files.BUFFER_SIZE];
            int                               numBytes  = inputStream.read(block);
            int                               size      = 0;

            while (numBytes >= 0) {
                blockList.add(new Pair<byte[], Integer>(block, numBytes));
                size += numBytes;

                block    = new byte[Files.BUFFER_SIZE];
                numBytes = inputStream.read(block);
            }

            return flatten(blockList, size);

        } catch (IOException e) {
            return new byte[0];
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    CompareDirectoryPlugin.getLogger().error(e);
                }
            }
        }
    }

    /**
     * Puts the contents in the list of byte arrays into a single byte array.
     * If the list contains only one byte array, this array is returned.
     * @param blockList the list of byte arrays to be flattened
     * @param size        the returned byte array length
     * @return the flattened byte array
     */
    private static byte[] flatten(List<Pair<byte[], Integer>> blockList, int size) {
        final int numBlocks = blockList.size();

        if (numBlocks == 0) {
            return new byte[0];
        }

        if (numBlocks == 1) {
            final Pair<byte[], Integer> block = blockList.get(0);
            final byte[]                bytes = block.getFirst();

            if (block.getSecond() == bytes.length) {
                return bytes;
            }
        }

        final byte[] flattenedContent = new byte[size];
        int          index            = 0;

        for (final Pair<byte[], Integer> block : blockList) {
            final Integer blockSize = block.getSecond();

            System.arraycopy(block.getFirst(), 0, flattenedContent, index, blockSize);
            index += blockSize;
        }

        return flattenedContent;
    }
}
