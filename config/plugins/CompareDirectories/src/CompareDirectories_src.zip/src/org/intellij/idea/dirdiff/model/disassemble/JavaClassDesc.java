/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import gnu.trove.THashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * A structured string representation of a Java class.
 */
public class JavaClassDesc implements Comparable<JavaClassDesc> {

    private String                           className;
    private String                           text;
    private final List<JavaClassMemberDesc>  members;
    private int                              accessFlags;
    private Map<String, JavaClassMemberDesc> lambdaCallers;

    public JavaClassDesc() {
        this.members = new ArrayList<JavaClassMemberDesc>();
    }

    public String getClassName() {
        return this.className;
    }

    /*package*/ void setClassName(String className) {
        this.className = className;
    }

    public String getText() {
        return this.text;
    }

    /*package*/ void setText(String text) {
        this.text = text;
    }

    public List<JavaClassMemberDesc> getMembers() {
        return this.members;
    }

    public JavaClassMemberDesc getMember(int index) {
        return this.members.get(index);
    }

    @Nullable public JavaClassMemberDesc getMember(@Nullable String name) {
        if (name != null) {
            for (JavaClassMemberDesc member : this.members) {
                if (member.hasSignature(name)) {
                    return member;
                }
            }
        }
        return null;
    }

    /*package*/ JavaClassMemberDesc addMember(String name, JavaClassMemberDesc.Type type, int accessFlags, int start) {
        final JavaClassMemberDesc member = new JavaClassMemberDesc(this, name, type, accessFlags, start);
        this.members.add(member);
        return member;
    }

    /*package*/ boolean removeMember(JavaClassMemberDesc member) {
        return this.members.remove(member);
    }

    public int compareTo(@NotNull JavaClassDesc other) {
        return this.className.compareTo(other.className);
    }

    @Override public String toString() {
        return this.className;
    }

    public void shiftMemberIndices(int shift, int startIndex) {
        for (JavaClassMemberDesc member : this.members) {
            member.shift(shift, startIndex);
        }
    }

    public void sortMembers() {
        Collections.sort(this.members);
    }

    public void setAccessFlags(int accessFlags) {
        this.accessFlags = accessFlags;
    }

    public final void addLambdaCaller(@NotNull String lambdaName, @NotNull JavaClassMemberDesc methodDesc) {
        if (this.lambdaCallers == null) {
            this.lambdaCallers = new THashMap<String, JavaClassMemberDesc>();
        }
        this.lambdaCallers.put(lambdaName, methodDesc);
    }

    @Nullable public final JavaClassMemberDesc getLambdaCaller(@NotNull String lambdaName) {
        return (this.lambdaCallers == null) ? null : this.lambdaCallers.get(lambdaName);
    }

    public boolean isClass() {
        return (!(this.isInterface() || this.isEnum() || this.isAnnotation()));
    }

    public boolean isAbstractStatic() {
        return (this.isAbstract() && this.isStatic());
    }

    public boolean isInterface() {
        return AsmUtil.isInterface(this.accessFlags);
    }

    public boolean isEnum() {
        return AsmUtil.isEnum(this.accessFlags);
    }

    public boolean isAnnotation() {
        return AsmUtil.isAnnotation(this.accessFlags);
    }

    public boolean isAbstract() {
        return AsmUtil.isAbstract(this.accessFlags);
    }

    public boolean isStatic() {
        return AsmUtil.isStatic(this.accessFlags);
    }

    public boolean isFinal() {
        return AsmUtil.isFinal(this.accessFlags);
    }

    public boolean isDeprecated() {
        return AsmUtil.isDeprecated(this.accessFlags);
    }
}