/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.model.ArchiveFile;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ReadableFile;

import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.TextComponentAccessor;
import com.intellij.openapi.ui.VerticalFlowLayout;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.ui.ComboboxWithBrowseButton;

/**
 */
public class SelectDialogWrapper extends DialogWrapper {

    private final DialogPanel panel;

    public SelectDialogWrapper(Project project, String leftPath, String rightPath,
                               boolean readOnlyLeft, boolean readOnlyRight,
                               List<String> lastLeftPaths, List<String> lastRightPaths,
                               boolean compareAnyFile) {
        super(project, false);
        this.panel = new DialogPanel(leftPath, rightPath, readOnlyLeft, readOnlyRight,
                                     lastLeftPaths, lastRightPaths, compareAnyFile);
        this.setResizable(true);
        this.setTitle(CompareDirectoryBundle.message(compareAnyFile ? "select.title.file" : "select.title.dir"));
        this.init();
    }

    @Override protected JComponent createCenterPanel() {
        return this.panel;
    }

    @Override public JComponent getPreferredFocusedComponent() {
        return this.panel.left.filePath;
    }

    @Override public boolean isOKActionEnabled() {
        return (this.panel.left .getSelectedFile() != null &&
                this.panel.right.getSelectedFile() != null);
    }

    public File getLeftDirectory() {
        return this.panel.left.getSelectedFile();
    }

    public File getRightDirectory() {
        return this.panel.right.getSelectedFile();
    }

    public boolean isByteComparison() {
        return this.panel.byteComparisonCheckBox.isSelected();
    }

    public boolean isClassAnalysis() {
        return this.panel.classAnalysisCheckBox.isSelected();
    }

    private static class DialogPanel extends JPanel {
        private final DialogPanelElement  left;
        private final DialogPanelElement  right;
        private final JCheckBox           byteComparisonCheckBox;
        private final JCheckBox           classAnalysisCheckBox;

        public DialogPanel(String       leftFilePath,
                           String       rightFilePath,
                           boolean      readOnlyLeft,
                           boolean      readOnlyRight,
                           List<String> lastLeftPaths,
                           List<String> lastRightPaths,
                           boolean      compareAnyFile) {
            super(new BorderLayout(5, 0));
            this.setBorder(BorderFactory.createTitledBorder(CompareDirectoryBundle.message("select.border")));

            final Container comboboxPanel = new JPanel(new VerticalFlowLayout());
            final Container labelPanel    = new JPanel(new VerticalFlowLayout());
            final Insets    labelInsets   = new Insets(5, 5, 5, 0);

            this.left  = new DialogPanelElement((compareAnyFile ? "select.left.browse-file.title"  : "select.left.browse-dir.title"),  leftFilePath,  readOnlyLeft,  lastLeftPaths,  compareAnyFile);
            this.right = new DialogPanelElement((compareAnyFile ? "select.right.browse-file.title" : "select.right.browse-dir.title"), rightFilePath, readOnlyRight, lastRightPaths, compareAnyFile);

            this.byteComparisonCheckBox = new JCheckBox(CompareDirectoryBundle.message("select.byte-comparison"), true);
            this.classAnalysisCheckBox  = new JCheckBox(CompareDirectoryBundle.message("select.class-analysis"),  true);

            this.byteComparisonCheckBox.addActionListener(new ActionListener() {
                private boolean classAnalysis;
                public void actionPerformed(ActionEvent event) {
                    final boolean selected = ((AbstractButton) event.getSource()).isSelected();

                    if (selected) {
                        DialogPanel.this.classAnalysisCheckBox.setSelected(this.classAnalysis);
                    } else {
                        this.classAnalysis = DialogPanel.this.classAnalysisCheckBox.isSelected();
                        DialogPanel.this.classAnalysisCheckBox.setSelected(false);
                    }
                    DialogPanel.this.classAnalysisCheckBox.setEnabled(selected);
                }
            });
            this.left .pack((compareAnyFile ? "select.left-file"  : "select.left-dir"),  labelPanel, comboboxPanel, labelInsets);
            this.right.pack((compareAnyFile ? "select.right-file" : "select.right-dir"), labelPanel, comboboxPanel, labelInsets);
            comboboxPanel.add(this.byteComparisonCheckBox);
            comboboxPanel.add(this.classAnalysisCheckBox);

            this.add(labelPanel,    BorderLayout.WEST);
            this.add(comboboxPanel, BorderLayout.CENTER);
        }
    }

    private static class DialogPanelElement {
        private final ComboboxWithBrowseButton  filePath;

        public DialogPanelElement(String       browseTitleKey,
                                  String       defaultFilePath,
                                  boolean      readOnlyPath,
                                  List<String> lastPaths,
                                  boolean      compareAnyFile) {
            final String                browseTitle           = CompareDirectoryBundle.message(browseTitleKey);
            final FileChooserDescriptor fileChooserDescriptor = createSingleJavaPathDescriptor(compareAnyFile);
            final Dimension             size;

            this.filePath = new ComboboxWithBrowseButton();

            final JComboBox comboBox    = this.filePath.getComboBox();
            final int       columnWidth = comboBox.getFontMetrics(comboBox.getFont()).charWidth('m');

            if (defaultFilePath != null) {
                comboBox.addItem(defaultFilePath);
                comboBox.setSelectedItem(defaultFilePath);
            }

            size = comboBox.getPreferredSize();
            size.width = Integer.parseInt(CompareDirectoryBundle.message("select.textfield.width")) * columnWidth;
            comboBox.setPreferredSize(size);
            comboBox.setEditable(!readOnlyPath);

            for (final String path : lastPaths) {
                final ReadableFile readableFile = FileTreeNode.getReadableFile(path);

                if (readableFile.exists()) {
                    comboBox.addItem(path);
                }

                // Never forget to close readable file to prevent system locks from remaining on the file
                readableFile.close();
            }

            this.filePath.setButtonEnabled(!readOnlyPath);
            this.filePath.addBrowseFolderListener(browseTitle, null, null, fileChooserDescriptor,
                                                  TextComponentAccessor.STRING_COMBOBOX_WHOLE_TEXT);
        }

        public void pack(String labelTextKey, Container labelPanel, Container comboBoxPanel,
                         final Insets labelInsets) {
            final Container insetsPanel = new JPanel(new BorderLayout()) {
                    @Override public Insets getInsets() { return labelInsets; }
                };

            labelPanel.add(insetsPanel);

            final JLabel label = new JLabel(CompareDirectoryBundle.message(labelTextKey));
            insetsPanel.add(label, BorderLayout.WEST);

            label.setLabelFor(this.filePath.getComboBox());
            comboBoxPanel.add(this.filePath, BorderLayout.CENTER);
        }

        private static FileChooserDescriptor createSingleJavaPathDescriptor(final boolean compareAnyFile) {
            return new FileChooserDescriptor(true, true, true, false, true, false) {
                /**
                 * Defines whether file can be chosen or not
                 */
                @Override public boolean isFileSelectable(VirtualFile file) {
                    return (compareAnyFile ||
                            super.isFileSelectable(file) ||
                            ArchiveFile.isTarFileExtension(file.getName()));
                }

                /**
                 * Defines whether file is visible in the tree
                 */
                @Override public boolean isFileVisible(VirtualFile file, boolean showHiddenFiles) {
                    return (compareAnyFile ||
                            super.isFileVisible(file, showHiddenFiles) ||
                            ArchiveFile.isTarFileExtension(file.getName()));
                }
            };
        }

        public File getSelectedFile() {
            String text = (String) this.filePath.getComboBox().getEditor().getItem();

            if (text == null ||  text.trim().length() == 0) {
                text = (String) this.filePath.getComboBox().getSelectedItem();
            }

            return ((text == null || text.trim().length() == 0) ? null : new File(text));
        }
    }
}
