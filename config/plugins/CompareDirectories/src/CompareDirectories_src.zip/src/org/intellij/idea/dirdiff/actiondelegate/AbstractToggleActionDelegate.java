/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileTreeModel;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.TreeNodeFilter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 */
@SuppressWarnings({"UnusedDeclaration", "MethodMayBeStatic"})
public abstract class AbstractToggleActionDelegate extends AbstractActionDelegate {

    public abstract boolean isSelected (@Nullable ICompareDirectoryPanel panel);
    public abstract void    setSelected(boolean state, @Nullable ICompareDirectoryPanel panel);

    public final void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        throw new UnsupportedOperationException("Cannot call apply() on toggle actions");
    }

    protected static void addRemoveFilter(@NotNull ICompareDirectoryPanel panel,
                                          boolean                         remove,
                                          @NotNull TreeNodeFilter         filter) {
        final FileTreeModel treeModel = panel.getTreeModel();

        if (remove) {
            treeModel.removeFilter(filter);
        } else {
            treeModel.addFilter(filter);
        }
        panel.applyFilters(treeModel.getRoot());

        if (panel.isComparisonOver()) {
            panel.refreshTree(true);
        }
    }
}