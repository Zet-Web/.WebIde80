/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;

/**
 */
public class LocalFileSystemFile extends File implements ReadableFile {

    private boolean binary;

    public LocalFileSystemFile(String pathname) {
        super(pathname);
    }

    public LocalFileSystemFile(String parent, String child) {
        super(parent, child);
    }

    public LocalFileSystemFile(File parent, String child) {
        super(parent, child);
    }

    public String getParentPath() {
        final String path = this.getPath();

        return path.substring(0, path.length() - this.getName().length() - 1);
    }

    public InputStream getInputStream() throws IOException {
        return new FileInputStream(this);
    }

    public String getExtension() {
        final String name  = this.getName();
        final int    index = name.lastIndexOf('.') + 1;

        return ((index == 0) ? "" : name.substring(index, name.length()));
    }

    public FileType getFileType() {
        return FileTypeManager.getInstance().getFileTypeByFileName(this.getPath());
    }

    public VirtualFile getVirtualFile() {
        return LocalFileSystem.getInstance().refreshAndFindFileByIoFile(this);
    }

    public ReadableFile getAncestor(int subPathLength) {
        final String path = this.getPath();
        return new LocalFileSystemFile(path.substring(0, path.length() - subPathLength));
    }

    public boolean hasCrc() {
        return false;
    }

    public long getCrc() {
        return 0;
    }

    public boolean isCompressedFile() {
        // We need to check isDirectory() because IDEA file type manager is fooled
        // by directories which have the archive type extension as file name extension
        // (e.g. a directory named 'foobar.jar').
        return (!this.isDirectory() &&
                (this.getFileType().equals(StdFileTypes.ARCHIVE)) ||
                 ArchiveFile.isTarFileExtension(this.getName()));
    }

    public boolean isInCompressedFile() {
        return false;
    }

    public File getRealFile() {
        return this;
    }

    public boolean hasDescendant(String path, boolean strict) {
        if (path == null) {
            return false;
        }

        final String filePath       = this.getPath();
        final int    filePathLength = filePath.length();

        return (path.startsWith(filePath)                    &&
                (!strict || path.length() != filePathLength) &&
                (File.separator                 .startsWith(path, filePathLength) ||
                 ZipEntryFile.ZIP_PATH_SEPARATOR.startsWith(path, filePathLength)));
    }

    public void releaseLock() {}

    public void close() {}

    public boolean isBinary() {
        return this.binary;
    }

    public void setBinary(boolean binary) {
        this.binary = binary;
    }

    public void finalizeIt() {}
}
