/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import com.intellij.openapi.vfs.VirtualFile;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;
import org.intellij.idea.dirdiff.util.Commands;
import org.intellij.idea.dirdiff.view.PanelConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FileTreeModel extends DefaultTreeModel {

    /** Tree model filters */
    private final List<TreeNodeFilter> filters;

    /** Tree model listeners */
    private final List<TreeModelListener> listeners;

    /** Tree model listeners */
    private final Collection<ComparedTreeNode> mergedNodes;

    /** The regexps of the files to be automatically ignored */
    private final Pattern[] excludedFileMasks;

    /** The allowed diffs */
    private final AllowedDiff[] allowedDiffs;

    /** Are differences in comments considered non-significant or not? */
    private boolean diffsInCommentsNonSignificant;

    /** The left-file count */
    private int numLeftFiles;

    /** The right-file count */
    private int numRightFiles;

    public static final Comparator childNameComparator       = new NodeNameComparator();
    public static final Comparator leftChildNameComparator   = new NodeLeftNameComparator();
    public static final Comparator rightChildNameComparator  = new NodeRightNameComparator();
    public static final Comparator javaClassMemberComparator = new JavaClassMemberComparator();

    public final RelativeNodePathComparator relativePathComparator = new RelativeNodePathComparator();

    public FileTreeModel(PanelConfiguration configuration) {
        super(null);

        this.listeners   = new ArrayList<TreeModelListener>();
        this.filters     = new ArrayList<TreeNodeFilter>();
        this.mergedNodes = new ArrayList<ComparedTreeNode>();
        this.setRoot(null);

        if (configuration != null) {
            for (TreeNodeFilter filter : TreeNodeFilters.ALL_FILTERS) {
                if (!configuration.isFilterVisible(filter)) {
                    this.addFilter(filter);
                }
            }
            this.excludedFileMasks             = configuration.getIgnoredFileMaskPatterns();
            this.allowedDiffs                  = configuration.getAllowedDiffPatterns();
            this.diffsInCommentsNonSignificant = configuration.areDiffsInCommentsNonSignificant();
        } else {
            this.excludedFileMasks             = PanelConfiguration.EMPTY_PATTERN_ARRAY;
            this.allowedDiffs                  = PanelConfiguration.EMPTY_ALLOWED_DIFF_ARRAY;
        }
    }

    public int getNumLeftFiles() {
        return this.numLeftFiles;
    }

    public int getNumRightFiles() {
        return this.numRightFiles;
    }

    public void resetNumFiles() {
        this.numLeftFiles  = 0;
        this.numRightFiles = 0;
    }

    void incrementNumFiles(FileStateEnum state) {
        if (state != FileStateEnum.LEFT_ONLY)  { this.numRightFiles++; }
        if (state != FileStateEnum.RIGHT_ONLY) { this.numLeftFiles ++; }
    }

    public Pattern[] getExcludedFileMasks() {
        return this.excludedFileMasks;
    }

    public boolean isMatchWithExcludedFileMasks(CharSequence path) {
        for (Pattern fileMask : this.excludedFileMasks) {
            if (fileMask.matcher(path).matches()) {
                return true;
            }
        }
        return false;
    }

    public boolean isAnyMatchWithExcludedFileMasks(CharSequence path1, CharSequence path2) {
        for (Pattern fileMask : this.excludedFileMasks) {
            if (fileMask.matcher(path1).matches() || fileMask.matcher(path2).matches()) {
                return true;
            }
        }
        return false;
    }

    public boolean matchAllowedDiffs(ComparedTreeNode node, String leftDiffedText, String rightDiffedText) {
        for (AllowedDiff allowedDiff : this.allowedDiffs) {
            if (allowedDiff.match(node, leftDiffedText, rightDiffedText)) {
                return true;
            }
        }
        return false;
    }

    public boolean isMatchableAllowedDiff(ComparedTreeNode node) {
        for (AllowedDiff allowedDiff : this.allowedDiffs) {
            if (allowedDiff.isMatchable(node)) {
                return true;
            }
        }
        return false;
    }

    public boolean areDiffsInCommentsNonSignificant() {
        return this.diffsInCommentsNonSignificant;
    }

    public void setDiffsInCommentsNonSignificant(boolean diffsInCommentsNonSignificant) {
        this.diffsInCommentsNonSignificant = diffsInCommentsNonSignificant;
    }

    public void retrieveStatistics(TreeStatistics statistics) {
        statistics.reset();
        ((ComparedTreeNode) this.root).getStatistics(statistics);
        statistics.setDone(true);
    }

    public void setRoot(@Nullable ComparedTreeNode root) {
        if (root == null) {
            root = new VoidTreeNode(this);
        }

        this.root = root;
        this.resetNumFiles();
        this.mergedNodes.clear();
    }

    @Override
    @NotNull public ComparedTreeNode getRoot() {
        return (ComparedTreeNode) this.root;
    }

    public static Iterable<ComparedTreeNode> getChildren(ComparedTreeNode root) {
        return root.getFilteredChildren();
    }

    @Override public ComparedTreeNode getChild(Object parent, int index) {
        return ((ComparedTreeNode) parent).getFilteredChildAt(index);
    }

    @Override public int getChildCount(Object parent) {
        return ((ComparedTreeNode) parent).getFilteredChildCount();
    }

    @Override public boolean isLeaf(Object node) {
        return !((ComparedTreeNode) node).hasFilteredChildren();
    }

    @Override public void addTreeModelListener(TreeModelListener listener) {
        if (!this.listeners.contains(listener)) {
            this.listeners.add(listener);
        }
    }

    @Override public void removeTreeModelListener(TreeModelListener listener) {
        this.listeners.remove(listener);
    }

    @Override public int getIndexOfChild(Object parent, Object child) {
        return ((ComparedTreeNode) parent).indexOfFiltered((ComparedTreeNode) child);
    }

    public void treeChanged() {
        if (this.root != null) {
            this.valueForPathChanged(new TreePath(this.root), this.root);
        }
    }

    @Override public void valueForPathChanged(TreePath path, Object newValue) {
        final TreeModelEvent          event     = new TreeModelEvent(newValue, path);
        final List<TreeModelListener> listeners = this.listeners;

        Commands.invoke(new Runnable() {
                public void run() {
                    try {
                        //--- Don't use Iterator or for-each loop to prevent any
                        //--- ConcurrentModificationException from being thrown
                        //noinspection ForLoopReplaceableByForEach
                        for (int index = 0; index < listeners.size(); index++) {
                            listeners.get(index).treeNodesChanged(event);
                        }
                    } catch (NullPointerException e) {
                        // Sometimes it happens for an unknown reason inside treeNodesChanged()
                        // because JTree.treeState becomes null while it never should.
                        // Just ignore the exception and wait for the next graphical refresh.
                    }
                }
            });
    }

    public void addFilter(TreeNodeFilter filter) {
        if (!this.filters.contains(filter)) {
            this.filters.add(filter);
        }
    }

    public void removeFilter(TreeNodeFilter filter) {
        this.filters.remove(filter);
    }

    public boolean hasNoFilters() {
        return (this.filters == null || this.filters.isEmpty());
    }

    public List<TreeNodeFilter> getFilters() {
        return this.filters;
    }

    public Collection<ComparedTreeNode> getMergedNodes() {
        return this.mergedNodes;
    }

    public void addMergedNode(ComparedTreeNode node) {
        if (node.isMerged()) {
            this.mergedNodes.add(node);
        }
    }

    public void removeMergedNode(ComparedTreeNode node) {
        if (node.isMerged()) {
            this.mergedNodes.remove(node);
        }
    }

    public void reapplyNodeMerging(FileTreeNode ancestorNode) {
        Collection<ComparedTreeNode> newMergedNodes = null;

        final FileTreeNode rootNode = (FileTreeNode) this.root;

        for (final ComparedTreeNode mergedNode : this.mergedNodes) {
            if (mergedNode == ancestorNode) {
                if (newMergedNodes == null) {
                    newMergedNodes = new ArrayList<ComparedTreeNode>();
                }
                newMergedNodes.add(mergedNode);
            } else {
                ComparedTreeNode leftSideNode  = findNode(rootNode, mergedNode.getLeftFile ().getPath(), true);
                ComparedTreeNode rightSideNode = findNode(rootNode, mergedNode.getRightFile().getPath(), false);


                if (leftSideNode != null && rightSideNode != null &&
                    leftSideNode .getState() == FileStateEnum.LEFT_ONLY &&
                    rightSideNode.getState() == FileStateEnum.RIGHT_ONLY) {

                    // Mergeable nodes have been found with the same path => reapply merging
                    leftSideNode = leftSideNode.mergeWithNode(rightSideNode);

                    if (leftSideNode != null) {
                        if (newMergedNodes == null) {
                            newMergedNodes = new ArrayList<ComparedTreeNode>();
                        }
                        newMergedNodes.add(leftSideNode);
                    }
                }
            }
        }

        // Update mergedNodes list after the end of iteration.
        if (newMergedNodes != null) {
            this.mergedNodes.clear();
            this.mergedNodes.addAll(newMergedNodes);
        }
    }

    public void swapLeftRight() {
        // Updates the side-only node state.
        ((ComparedTreeNode) this.root).swapLeftRight();

        // Swaps numLeftFiles and numRightFiles.
        final int temp     = this.numLeftFiles;

        this.numLeftFiles  = this.numRightFiles;
        this.numRightFiles = temp;
    }

    public Iterable<ComparedTreeNode> getLeaves() {
        return new Iterable<ComparedTreeNode>() {
                public Iterator<ComparedTreeNode> iterator() {
                    return new DescendentNodeIterator((ComparedTreeNode) FileTreeModel.this.root, true);
                }
            };
    }

    public FileTreeNode createRootNode(ReadableFile leftFile, ReadableFile rightFile) {
        if (leftFile == null) {
            if (rightFile == null) {
                return new FileTreeNode(CompareDirectoryBundle.message("node.root"),
                                        null, this, null, null, FileStateEnum.IDENTICAL);
            } else {
                return FileTreeNode.getFileTreeNode(null, this, rightFile, false, FileStateEnum.RIGHT_ONLY);
            }
        } else {
            if (rightFile == null) {
                return FileTreeNode.getFileTreeNode(null, this, leftFile,  false, FileStateEnum.LEFT_ONLY);
            } else {
                final String leftFileName  = leftFile .getName();
                final String rightFileName = rightFile.getName();
                final String rootItemName  = (leftFileName.equals(rightFileName) ? leftFileName : CompareDirectoryBundle.message("node.vs", leftFileName, rightFileName));

                return new FileTreeNode(rootItemName, null, this, leftFile, rightFile);
            }
        }
    }

    @Nullable
    public ComparedTreeNode findNode(VirtualFile searchedVirtualFile) {
        final String       filePath = Files.denormalizeFilePath(searchedVirtualFile.getPath());
        final FileTreeNode rootNode = (FileTreeNode) this.root;

        ComparedTreeNode node = findNode(rootNode, filePath, true);
        if (node == null) {
            node = findNode(rootNode, filePath, false);
        }
        return node;
    }

    @Nullable
    private static ComparedTreeNode findNode(FileTreeNode rootNode, String searchedFilePath, boolean isLeft) {
        final ReadableFile nodeFile     = (isLeft ? rootNode.getLeftFile() : rootNode.getRightFile());
        final String       nodeFilePath = nodeFile.getPath();
        boolean            goOnParsing  = searchedFilePath.startsWith(nodeFilePath);
        ComparedTreeNode   node         = (goOnParsing ? rootNode : null);

        int index = nodeFilePath.length() + (nodeFile.isCompressedFile() ? ZipEntryFile.ZIP_PATH_SEPARATOR_LENGTH : ZipEntryFile.PATH_SEPARATOR_LENGTH);

        while (goOnParsing) {
            searchedFilePath = searchedFilePath.substring(index, searchedFilePath.length());
            index            = searchedFilePath.indexOf(File.separatorChar) + ZipEntryFile.PATH_SEPARATOR_LENGTH;

            if (index  == 0) {
                index    = searchedFilePath.length();
                goOnParsing = false;
            }
            String name = searchedFilePath.substring(0, index);

            if (name.endsWith(ZipEntryFile.ZIP_PATH_SEPARATOR)) {
                name = name.substring(0, name.length() - ZipEntryFile.ZIP_PATH_SEPARATOR_LENGTH);
            } else if (name.endsWith(File.separator)) {
                name = name.substring(0, name.length() - ZipEntryFile.PATH_SEPARATOR_LENGTH);
            }

            final int childNodeIndex = (isLeft ? node.leftIndexOf(name) : node.rightIndexOf(name));
            if (childNodeIndex >= 0) {
                node = (ComparedTreeNode) node.getChildAt(childNodeIndex);
                if (node == null || !node.isNotFiltered()) {
                    return null;
                }
            }
        }

        return node;
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    private static class NodeNameComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            return ((ComparedTreeNode) o1).getName().compareTo((String) o2);
        }
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    private static class NodeLeftNameComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            return ((ComparedTreeNode) o1).getLeftFile().getName().compareTo((String) o2);
        }
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    private static class NodeRightNameComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            final ComparedTreeNode treeNode     = (ComparedTreeNode) o1;
            final ReadableFile     comparedFile = (treeNode.isMerged() ? treeNode.getLeftFile()
                                                                       : treeNode.getRightFile());

            return comparedFile.getName().compareTo((String) o2);
        }
    }

    public final class RelativeNodePathComparator implements Comparator<ReadableFile> {
        public int compare(ReadableFile o1, ReadableFile o2) {
            return this.compare((FileTreeNode) FileTreeModel.this.root, o1, o2);
        }

        public int compare(FileTreeNode ancestorNode, ReadableFile o1, ReadableFile o2) {
            final String leftRelativePath  = ((o1 == null) ? null : ancestorNode.getDescendantRelativePath(o1, true));
            final String rightRelativePath = ((o2 == null) ? null : ancestorNode.getDescendantRelativePath(o2, false));


            return (o1 == null ? ((o2 == null) ? 0 : +1) :
                    o2 == null ? -1
                               : leftRelativePath.compareTo(rightRelativePath));
        }
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    private static class JavaClassMemberComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            return (o1.getClass() == o2.getClass() && o1 instanceof Comparable)           ? ((Comparable) o1).compareTo(o2) :
                   (o1 instanceof JavaFieldTreeNode && o2 instanceof JavaClassMemberDesc) ? ((JavaFieldTreeNode) o1).getLeftMember().compareTo((JavaClassMemberDesc) o2) :
                   (o1 instanceof ClassFileTreeNode)                                      ? -1
                                                                                          : +1;
        }
    }

    private static class VoidTreeNode extends ComparedTreeNode {
        private VoidTreeNode(FileTreeModel model) {
            super("", null, model, FileStateEnum.IDENTICAL);
        }

        public ReadableFile       getLeftFile       () { return null; }
        public ReadableFile       getRightFile      () { return null; }
        public FileStateEnum      updateInitialState() { return null; }
        public boolean            isIgnored         () { return false; }
        public boolean            isMerged          () { return false; }
        public ComparedTreeNode[] split             () { return new ComparedTreeNode[0]; }
        public int                compareTimestamps () { return 0; }
        public void               finalizeIt        () {}

        public ComparedTreeNode   mergeWithNode     (ComparedTreeNode rightNode) { return this; }

        @NotNull
        public FileStateEnum computeState(Interruptible interruptible) { return this.state; }
    }
}
