/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Queue;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.intellij.idea.dirdiff.model.fs.ArchiveFileEntry;
import org.jetbrains.annotations.Nullable;

import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.util.ArrayUtil;

/**
 * The thread doing the comparison
 */
public class CompareThread extends Thread implements Interruptible {

    /** 87: Magic number to have frequent-enough-but-not-too-much updates */
    private static final int LOW_PROGRESS_UPDATE_FREQ = 87;

    /** 37: Magic number to have a bit more frequent updates */
    private static final int MED_PROGRESS_UPDATE_FREQ = 37;

    /** 13: Magic number to have frequent updates */
    private static final int HIGH_PROGRESS_UPDATE_FREQ = 13;

    private FileTreeNode           treeRoot;
    private FileTreeNode           node;
    private ICompareDirectoryPanel panel;
    private boolean                rebuildTreeStructure;
    private ComparisonParameters   parameters;
    private int                    numAdditionalLeftFiles;
    private int                    numAdditionalRightFiles;
    private Interruptible[]        interruptibles;

    @SuppressWarnings({"HardCodedStringLiteral"})
    public CompareThread() {
        super("CompareDirectoryThread");
    }

    public CompareThread(ICompareDirectoryPanel panel,
                         FileTreeNode           treeRoot,
                         FileTreeNode           nodeToBeRefreshed,
                         boolean                rebuildTreeStructure,
                         ComparisonParameters   parameters) {
        this();
        this.panel                = panel;
        this.treeRoot             = treeRoot;
        this.node                 = nodeToBeRefreshed;
        this.rebuildTreeStructure = rebuildTreeStructure;
        this.parameters           = parameters;
        this.interruptibles       = new Interruptible[] { new Interruptible() {
                    public boolean hasBeenInterrupted() {
                        return CompareThread.this.panel.isComparisonOver();
                    }
                }
            };
    }

    public void setTree(FileTreeNode treeRoot) {
        this.treeRoot = treeRoot;
    }

    public void stopThread() {
        this.panel.stopComparison();
    }

    public boolean hasBeenInterrupted() {
        for (Interruptible interruptible : this.interruptibles) {
            if (interruptible.hasBeenInterrupted()) {
                return true;
            }
        }
        return false;
    }

    public void addInterruptible(Interruptible interruptible) {
        this.interruptibles = ArrayUtil.append(this.interruptibles, interruptible, Interruptible.class);
    }

    @Override public void run() {
        try {
            if (this.rebuildTreeStructure) {
                this.panel.setProgressBarMaximum(-1, "progress.parsing");
                this.node.closeChildrenFiles();
                this.node.removeAllChildren();
                this.node.getModel().resetNumFiles();
                this.numAdditionalLeftFiles  = 0;
                this.numAdditionalRightFiles = 0;

                this.checkSideOnlyNodeStatus();
                this.createSubNodes(this.node);
            }

            if (this.parameters.isClassAnalysisOnly()) {
                this.compareClassNodes(this.node);
            } else if (this.parameters.isByteComparison()) {
                this.performByteComparison();
                if (this.parameters.isClassAnalysis()) {
                    this.compareClassNodes(this.node);
                }
                this.reapplyNodeMerging();
            } else {
                this.node.updateInitialState();
            }
        } catch (Throwable t) {
            t.printStackTrace();
            CompareDirectoryPlugin.getLogger().error(t);
            this.panel.getManager().showErrorMessage(CompareDirectoryBundle.message("error.comparison"), CompareDirectoryBundle.message("error.title"));
        } finally {
            this.panel.stopComparison();
        }
        this.panel.refreshTree(true);
    }

    private void checkSideOnlyNodeStatus() {
        final FileStateEnum state = this.node.getState();

        if (state.isSideOnly()) {
            final boolean      isLeftOnly = (state == FileStateEnum.LEFT_ONLY);
            final ReadableFile otherFile  = this.node.getOtherSideFile(isLeftOnly);

            if (otherFile.getRealFile().exists()) {
                if (isLeftOnly) {
                    this.node.setRightFile(otherFile);
                } else {
                    this.node.setLeftFile (otherFile);
                }
                this.node.setState(FileTreeNode.getInitialState(this.node.getLeftFile(), this.node.getRightFile()));
            }
        } else {
            final ReadableFile  leftFile        = this.node.getLeftFile();
            final ReadableFile  rightFile       = this.node.getRightFile();
            final boolean       leftFileExists  = leftFile .getRealFile().exists();
            final boolean       rightFileExists = rightFile.getRealFile().exists();
            final FileStateEnum newState;

            newState = (leftFileExists  && !rightFileExists ? FileStateEnum.LEFT_ONLY  :
                        rightFileExists && !leftFileExists  ? FileStateEnum.RIGHT_ONLY
                                                            : FileTreeNode.getInitialState(leftFile, rightFile));

            if (newState.isSideOnly()) {
                if (leftFileExists) {
                    this.node.setRightFile(leftFile);
                } else {
                    this.node.setLeftFile(rightFile);
                }
            }
            this.node.setState(newState);
        }
    }

    private void createSubNodes(FileTreeNode node) throws IOException {
        final ReadableFile leftFile  = node.getLeftFile();
        final ReadableFile rightFile = node.getRightFile();

        if (node.getState().isSideOnly()) {
            this.createSubNodes(node, node.getState());
        } else {
            final boolean isLeftDirectory  = leftFile .isDirectory();
            final boolean isRightDirectory = rightFile.isDirectory();
            final boolean isLeftZipFile    = leftFile .isCompressedFile();
            final boolean isRightZipFile   = rightFile.isCompressedFile();
            final boolean isLeftInZipFile  = leftFile .isInCompressedFile();
            final boolean isRightInZipFile = rightFile.isInCompressedFile();

            if ((isLeftDirectory || isLeftZipFile) ^ (isRightDirectory || isRightZipFile)) {
                this.createDifferentFileSubNodes(node);
            } else if ((isLeftDirectory || isLeftZipFile || isLeftInZipFile) && (isRightDirectory || isRightZipFile || isRightInZipFile)) {
                final ReadableFile[] leftChildren  = (isLeftZipFile  || isLeftInZipFile  ? this.getZipEntries(leftFile,  true)  : this.getDirectoryFiles(leftFile .getRealFile(), true,  isRightZipFile));
                final ReadableFile[] rightChildren = (isRightZipFile || isRightInZipFile ? this.getZipEntries(rightFile, false) : this.getDirectoryFiles(rightFile.getRealFile(), false, isLeftZipFile));

                this.createSameSubNodes(node, leftChildren, rightChildren);

                final Iterable<ComparedTreeNode> children = node.getChildren();

                if (!(this.hasBeenInterrupted() || isLeftZipFile || isLeftInZipFile || isRightZipFile || isRightInZipFile || children == null)) {
                    for (ComparedTreeNode childNode : children) {
                        this.createSubNodes((FileTreeNode) childNode);
                        if (this.hasBeenInterrupted()) { return; }
                    }
                }
            }
        }
    }

    private void createSameSubNodes(FileTreeNode node, ReadableFile[] leftChildren, ReadableFile[] rightChildren) {
        final FileTreeModel.RelativeNodePathComparator relativePathComparator = this.panel.getTreeModel().relativePathComparator;
        int                                            leftIndex              = 0;
        int                                            rightIndex             = 0;

        while (leftIndex  < leftChildren .length ||
               rightIndex < rightChildren.length) {
            final ReadableFile leftChild    = ((leftIndex  < leftChildren .length) ? leftChildren [leftIndex]  : null);
            final ReadableFile rightChild   = ((rightIndex < rightChildren.length) ? rightChildren[rightIndex] : null);
            final int          comparison   = relativePathComparator.compare(node, leftChild, rightChild);
            final boolean      isLeftClass  = (leftChild  == null || StdFileTypes.CLASS.equals(leftChild .getFileType()));
            final boolean      isRightClass = (rightChild == null || StdFileTypes.CLASS.equals(rightChild.getFileType()));
            final FileTreeNode childNode;

            if (comparison == 0) {
                childNode = FileTreeNode.getFileTreeNode(node, node.getModel(), leftChild, rightChild, isLeftClass || isRightClass);
                leftIndex++;
                rightIndex++;
            } else if (comparison < 0) {
                childNode = FileTreeNode.getFileTreeNode(node, node.getModel(), leftChild,  isLeftClass,  FileStateEnum.LEFT_ONLY);
                leftIndex++;
            } else {
                childNode = FileTreeNode.getFileTreeNode(node, node.getModel(), rightChild, isRightClass, FileStateEnum.RIGHT_ONLY);
                rightIndex++;
            }

            node.addChildNode(childNode);
            this.panel.incrementProgressBar(false, false);
            this.panel.refreshProgressBar(this.numAdditionalLeftFiles, this.numAdditionalRightFiles);

            if (this.hasBeenInterrupted()) { return; }
        }

        node.moveInnerClassNodes();
        this.numAdditionalLeftFiles  = 0;
        this.numAdditionalRightFiles = 0;
    }

    private void createDifferentFileSubNodes(FileTreeNode node) throws IOException {
        final ReadableFile leftFile      = node.getLeftFile();
        final ReadableFile rightFile     = node.getRightFile();
        final boolean      isClass       = (StdFileTypes.CLASS.equals(leftFile .getFileType()) &&
                                            StdFileTypes.CLASS.equals(rightFile.getFileType()));
        final FileTreeNode leftFileNode  = FileTreeNode.getFileTreeNode(node, node.getModel(), leftFile,  isClass, FileStateEnum.LEFT_ONLY);
        final FileTreeNode rightFileNode = FileTreeNode.getFileTreeNode(node, node.getModel(), rightFile, isClass, FileStateEnum.RIGHT_ONLY);

        node.addChildNode(leftFileNode);
        node.addChildNode(rightFileNode);
        this.panel.incrementProgressBar(false, false);
        this.panel.incrementProgressBar(true,  false);

        this.createSubNodes(leftFileNode);
        if (this.hasBeenInterrupted()) { return; }
        this.createSubNodes(rightFileNode);

        leftFileNode .moveInnerClassNodes();
        rightFileNode.moveInnerClassNodes();
    }

    private void createSubNodes(FileTreeNode node, FileStateEnum state) {
        final ReadableFile file = node.getLeftFile();

        if (file.isDirectory()) {
            final ReadableFile[] children = this.getDirectoryFiles(file.getRealFile(), (state == FileStateEnum.LEFT_ONLY), false);

            node.initChildren(children.length);
            for (ReadableFile fileChild : children) {
                final boolean      isClass   = StdFileTypes.CLASS.equals(fileChild.getFileType());
                final FileTreeNode childNode = FileTreeNode.getFileTreeNode(node, node.getModel(), fileChild, isClass, state);

                node.addChildNode(childNode);
                this.panel.incrementProgressBar(true, false);
                if (this.hasBeenInterrupted()) { return; }
                this.createSubNodes(childNode, state);
            }
        }
    }

    private ReadableFile[] getDirectoryFiles(File file, boolean isLeft, boolean deep) {
        final ReadableFile[] files;

        if (deep) {
            final List<ReadableFile> fileList = this.getDeepDirectoryFiles(file, isLeft, new ArrayList<ReadableFile>());

            files = fileList.toArray(new ReadableFile[fileList.size()]);
        } else {
            files = this.getLocalFileSystemFiles(file.listFiles(), isLeft);
        }

        if (files != null) {
            Arrays.sort(files, FileTreeNode.pathComparator);
        }
        return files;
    }

    private List<ReadableFile> getDeepDirectoryFiles(File file, boolean isLeft, List<ReadableFile> foundFiles) {
        final ReadableFile[] files = this.getLocalFileSystemFiles(file.listFiles(), isLeft);

        if (files != null) {
            Arrays.sort(files, FileTreeNode.pathComparator);
            foundFiles.addAll(Arrays.asList(files));
            for (ReadableFile fileChild : files) {
                if (fileChild.isDirectory()) {
                    this.getDeepDirectoryFiles(fileChild.getRealFile(), isLeft, foundFiles);
                }
            }
        }
        return foundFiles;
    }

    @Nullable private ReadableFile[] getLocalFileSystemFiles(File[] fileList, boolean isLeft) {
        ReadableFile[] innerFiles = null;

        if (fileList != null) {
            innerFiles = new ReadableFile[fileList.length];
            this.addAdditionalLeftRightFiles(isLeft, fileList.length);

            for (int index = fileList.length; --index >= 0; ) {
                innerFiles[index] = new LocalFileSystemFile(fileList[index].getPath());
            }

            this.panel.refreshProgressBar(isLeft ? innerFiles.length : 0,
                                          isLeft ? 0 : innerFiles.length);
        }
        return innerFiles;
    }

    private ReadableFile[] getZipEntries(ReadableFile file, boolean isLeft) throws IOException {
        final List<ZipEntryFile> entryList = new ArrayList<ZipEntryFile>();
        final ReadableFile[]     entries;

        this.addZipEntries(file, entryList, isLeft);
        entries = entryList.toArray(new ReadableFile[entryList.size()]);

        Arrays.sort(entries, FileTreeNode.pathComparator);
        return entries;
    }

    private void addZipEntries(ReadableFile file, List<ZipEntryFile> entryList, boolean isLeft) throws IOException {
        int                numEntries       = 0;
        final boolean      isFileCompressed = file.isCompressedFile();
        final ArchiveFile  archiveFile      = (isFileCompressed ? new ArchiveFile(file.getRealFile())
                                                                : ((ZipEntryFile) file).getArchiveFile());

        for (ArchiveFileEntry entry : archiveFile.entries()) {
            final String entryName = entry.getName();

            if ((isFileCompressed || file.hasDescendant(entryName, true)) && !entryName.endsWith("/")) {
                final ZipEntryFile entryFile = new ZipEntryFile(file, archiveFile, entry);
                final int          index     = Collections.binarySearch(entryList, entryFile);

                if (index < 0) {
                    entryList.add(-(index + 1), entryFile);
                    numEntries++;

                    if ((numEntries % LOW_PROGRESS_UPDATE_FREQ) == 0) {
                        this.addAdditionalLeftRightFiles(isLeft, LOW_PROGRESS_UPDATE_FREQ);
                        this.panel.refreshProgressBar(this.numAdditionalLeftFiles, this.numAdditionalRightFiles);
                    }
                }
                if (this.hasBeenInterrupted()) { return; }

                if (entryFile.isCompressedFile() && entryFile.extractEntry()) {
                    this.panel.refreshProgressBar(this.numAdditionalLeftFiles, this.numAdditionalRightFiles);
                    this.addZipEntries(entryFile, entryList, isLeft);
                }
            }
        }
    }

    private void addAdditionalLeftRightFiles(boolean isLeft, int numAdditional) {
        if (isLeft) {
            this.numAdditionalLeftFiles  += numAdditional;
        } else {
            this.numAdditionalRightFiles += numAdditional;
        }
    }

    private void performByteComparison() {
        this.panel.setProgressBarMaximum(this.treeRoot.getNumDescendentNodes(), "progress.analysing");
        if (!this.hasBeenInterrupted()) {
            this.computeNodeState(this.node, false);
        }
    }

    public FileStateEnum computeNodeState(ComparedTreeNode node, boolean forceRecompute) {
        final int           numChildren = node.getChildCount();
        final FileStateEnum oldState    = node.getState();
        FileStateEnum       state;

        if (!(node instanceof FileTreeNode)) {
            state = node.computeState(this);
        } else {
            final FileTreeNode fileNode = (FileTreeNode) node;

            if (numChildren == 0 && !(fileNode.getLeftFile().isDirectory() && fileNode.getRightFile().isDirectory())) {
                state = node.getState();
                if (state.isInitial() || forceRecompute) {
                    state = node.computeState(this);
                }
            } else {
                // Case of directory.
                state = (oldState.isInitial() || oldState == FileStateEnum.DIFFERENT
                                ? FileStateEnum.IDENTICAL
                                : oldState);

                for (int index = 0; index < numChildren; index++) {
                    final ComparedTreeNode child      = (ComparedTreeNode) node.getChildAt(index);
                    FileStateEnum          childState = child.getState();

                    // Don't compute state for left-only or right-only nodes.
                    if (childState.isInitial()) {
                        childState = this.computeNodeState(child, forceRecompute);
                    } else {
                        this.panel.incrementProgressBar(true, false);
                    }
                    if (childState != state) {
                        if (childState == FileStateEnum.DIFFERENT_IN_BLANKS && state == FileStateEnum.IDENTICAL) {
                            state = FileStateEnum.DIFFERENT_IN_BLANKS;
                        } else if (childState == FileStateEnum.DIFFERENT_IN_COMMENTS &&
                                   (state == FileStateEnum.IDENTICAL || state == FileStateEnum.DIFFERENT_IN_BLANKS)) {
                            state = FileStateEnum.DIFFERENT_IN_COMMENTS;
                        } else if (childState == FileStateEnum.DIFFERENT_NON_SIGNIFICANT &&
                                   (state == FileStateEnum.IDENTICAL || state == FileStateEnum.DIFFERENT_IN_BLANKS)) {
                            state = FileStateEnum.DIFFERENT_NON_SIGNIFICANT;
                        } else if (childState.isDifferent()) {
                            state = FileStateEnum.DIFFERENT;
                        }
                    }

                    if (this.hasBeenInterrupted()) { break; }
                }
            }
        }

        node.setState(state);
        if (oldState != state) {
            this.panel.redrawNode(node);
        }
        this.panel.incrementProgressBar(true, this.panel.getProgressBarValue() % HIGH_PROGRESS_UPDATE_FREQ == 0);

        return state;
    }

    /**
     * Reapply node merging on every instance of <code>FileTreeNode</code> that changed.
     */
    private void reapplyNodeMerging() {
        final FileTreeModel                model          = this.node.getModel();
        final Collection<ComparedTreeNode> oldMergedNodes = new ArrayList<ComparedTreeNode>(model.getMergedNodes());

        model.reapplyNodeMerging(this.node);

        final Collection<ComparedTreeNode> newMergedNodes = new ArrayList<ComparedTreeNode>(model.getMergedNodes());

        newMergedNodes.removeAll(oldMergedNodes);
        if (!newMergedNodes.isEmpty()) {
            for (ComparedTreeNode mergedNode : newMergedNodes) {
                if (mergedNode instanceof FileTreeNode) {
                    this.panel.refreshSubTree((FileTreeNode) mergedNode, true, false, this.parameters);
                }
            }
            this.panel.refreshTree(true);
        }
    }

    private void compareClassNodes(ComparedTreeNode node) {
        this.panel.setProgressBarMaximum(-1, "progress.decompiling");

        final List<ClassFileTreeNode> classNodes = new ArrayList<ClassFileTreeNode>();

        for (ComparedTreeNode leaf : node.getDescendentNodes(false, false)) {
            if (leaf instanceof ClassFileTreeNode) {
                classNodes.add((ClassFileTreeNode) leaf);
            }
        }

        final MyClassVisitorContext classVisitorContext = this.panel.getManager().getClassVisitorContext();

        this.panel.setProgressBarMaximum(classNodes.size(), "progress.decompiling");

        // Compare class nodes
        for (ClassFileTreeNode classNode : classNodes) {
            classNode.analyze(classVisitorContext, false, true);
            this.panel.incrementProgressBar(true, this.panel.getProgressBarValue() % MED_PROGRESS_UPDATE_FREQ == 0);
            if (this.hasBeenInterrupted()) {
                return;
            }
        }
    }
}
