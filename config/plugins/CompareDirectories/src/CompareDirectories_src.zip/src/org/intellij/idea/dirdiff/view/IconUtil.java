/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.net.URL;

import javax.swing.ImageIcon;

import org.jetbrains.annotations.NonNls;
import org.intellij.idea.dirdiff.CompareDirectoryBundle;

/**
 */
public class IconUtil {
    @NonNls private static final String ICON_PATH = "/org/intellij/idea/dirdiff/icons/";

    private IconUtil() {}

    /**
     * Returns an Icon, or null if the path was invalid.
     * @param path the path of the image icon
     * @return the ImageIcon instance
     */
    public static ImageIcon createIcon(String path) {
        final boolean isAbsolutePath = (path.charAt(0) == '/');
        final String  absolutePath   = (isAbsolutePath ? path : ICON_PATH + path);
        final URL     imageUrl       = FileNodeRenderer.class.getResource(absolutePath);

        return ((imageUrl == null) ? null : new ImageIcon(imageUrl));
    }

    /**
     * Returns an Icon, or null if the path key was invalid.
     * @param bundleKey the bundle key whose value is the path of the image icon
     * @return the ImageIcon instance
     */
    public static ImageIcon createIconWithKey(String bundleKey) {
        return createIcon(CompareDirectoryBundle.message(bundleKey));
    }
}
