/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.action;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.List;

import org.intellij.idea.dirdiff.view.CompareDirectoryPanel;
import org.intellij.idea.dirdiff.view.SettingsDialog;
import org.jetbrains.annotations.NonNls;

import com.intellij.openapi.actionSystem.AnActionEvent;

/**
 */
public class EditSettingsAction extends AbstractCompareDirectoryAction {

    public EditSettingsAction() {}

    public EditSettingsAction(final CompareDirectoryPanel panel, @NonNls final String actionKey) {
        super(panel, actionKey);
    }

    @Override public void actionPerformed(AnActionEvent event) {
        final CompareDirectoryPanel panel = this.getPanel(event);

        if (panel != null) {
            final List<String>   oldIgnoredFiles              = panel.getConfiguration().getIgnoredFileMasks();
            final List<String>   oldAllowedDiffs              = panel.getConfiguration().getAllowedDiffMasks();
            final boolean        diffsInCommentNonSignificant = panel.getConfiguration().areDiffsInCommentsNonSignificant();
            final SettingsDialog infoDialog                   = new SettingsDialog(oldIgnoredFiles, oldAllowedDiffs, diffsInCommentNonSignificant);
            final Dimension      screenSize                   = Toolkit.getDefaultToolkit().getScreenSize();
            final Dimension      dialogSize                   = infoDialog.getPreferredSize();

            infoDialog.pack();
            infoDialog.setLocation((screenSize.width  - dialogSize.width)  / 2,
                                   (screenSize.height - dialogSize.height) / 2);

            infoDialog.setVisible(true);

            final List<String> newIgnoredFiles      = infoDialog.getIgnoredFileList();
            final List<String> newAllowedDiffs      = infoDialog.getAllowedDiffList();
            final boolean      newDiffsInCommentsNS = infoDialog.areDiffsInCommentsNonSignificant();
            boolean            changed              = false;

            if (oldIgnoredFiles != newIgnoredFiles) {
                panel.getConfiguration().setIgnoredFileMasks(newIgnoredFiles);
                changed = true;
            }
            if (oldAllowedDiffs != newAllowedDiffs) {
                panel.getConfiguration().setAllowedDiffMasks(newAllowedDiffs);
                changed = true;
            }
            if (diffsInCommentNonSignificant != newDiffsInCommentsNS) {
                panel.getConfiguration().setDiffsInCommentsNonSignificant(newDiffsInCommentsNS);
                panel.getTreeModel()    .setDiffsInCommentsNonSignificant(newDiffsInCommentsNS);
                changed = true;
            }

            if (changed) {
                panel.refreshTree(true);
            }
        }
    }
}