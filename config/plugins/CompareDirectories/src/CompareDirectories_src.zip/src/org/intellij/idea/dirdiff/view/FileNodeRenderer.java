/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.plaf.basic.BasicGraphicsUtils;
import javax.swing.tree.DefaultTreeCellRenderer;

import com.intellij.ui.JBColor;
import com.intellij.util.PlatformIcons;
import org.intellij.idea.dirdiff.model.ClassFileTreeNode;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.JavaFieldTreeNode;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassDesc;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;

import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.util.IconLoader;

/**
 */
public class FileNodeRenderer extends DefaultTreeCellRenderer {
    private static Font plainFont;
    private static Icon rootOpenedIcon;
    private static Icon rootClosedIcon;
    private static Icon folderOpenedIcon;
    private static Icon folderClosedIcon;
    private static Icon zipFileOpenedIcon;
    private static Icon zipFileClosedIcon;
    private static Icon identicalIcon;
    private static Icon differentIcon;
    private static Icon differentBlanksIcon;
    private static Icon differentNonSignificantIcon;
    private static Icon leftOnlyIcon;
    private static Icon rightOnlyIcon;
    private static Icon probablyDifferentIcon_leftNewer;
    private static Icon probablyDifferentIcon_rightNewer;
    private static Icon probablyIdenticalIcon_leftNewer;
    private static Icon probablyIdenticalIcon_rightNewer;
    private static Icon mostProbablyIdenticalIcon;

    private static final Icon classIcon               = PlatformIcons.CLASS_ICON;
    private static final Icon abstractClassIcon       = PlatformIcons.ABSTRACT_CLASS_ICON;
    private static final Icon enumClassIcon           = PlatformIcons.ENUM_ICON;
    private static final Icon annotationClassIcon     = PlatformIcons.ANNOTATION_TYPE_ICON;
    private static final Icon specialMethodIcon       = IconLoader.getIcon("/nodes/static.png");
    private static final Icon interfaceIcon           = PlatformIcons.INTERFACE_ICON;
    private static final Icon fieldIcon               = PlatformIcons.FIELD_ICON;
    private static final Icon methodIcon              = PlatformIcons.METHOD_ICON;
    private static final Icon lambdaIcon              = PlatformIcons.FUNCTION_ICON;
    private static final Icon abstractMethodIcon      = PlatformIcons.ABSTRACT_METHOD_ICON;
    private static final Icon staticMarkIcon          = IconLoader.getIcon("/nodes/staticMark.png");
    private static final Icon finalMarkIcon           = IconLoader.getIcon("/nodes/finalMark.png");
    private static final Icon finalFieldIcon          = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.FIELD_ICON,  finalMarkIcon);
    private static final Icon staticFieldIcon         = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.FIELD_ICON,  staticMarkIcon);
    private static final Icon staticFinalFieldIcon    = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.FIELD_ICON,  staticMarkIcon, finalMarkIcon);
    private static final Icon finalMethodIcon         = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.METHOD_ICON, finalMarkIcon);
    private static final Icon staticMethodIcon        = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.METHOD_ICON, staticMarkIcon);
    private static final Icon staticClassIcon         = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, PlatformIcons.CLASS_ICON,  staticMarkIcon);
    private static final Icon abstractStaticClassIcon = new CompoundIcon(CompoundIcon.Axis.Z_AXIS, abstractClassIcon, staticMarkIcon);

    private static final JBColor darkRed    = new JBColor(new Color(128, 0, 0),   new Color(255, 128, 128));
    private static final JBColor darkGreen  = new JBColor(new Color(0, 128, 0),   new Color(128, 255, 128));
    private static final JBColor darkBlue   = new JBColor(new Color(0, 0, 128),   new Color(128, 128, 255));
    private static final JBColor maroon     = new JBColor(new Color(128, 128, 0), new Color(255, 255,   0));
    private static final JBColor darkYellow = new JBColor(new Color(192, 192, 0), new Color(255, 255, 128));

    private Icon  nodeStateIcon;
    /** Background color of the tree. */
    private Color treeBGColor;
    /** Color to draw the focus indicator in, determined from the background color. */
    private Color focusBGColor;

    private boolean hasFocus;

    private boolean strikeThrough;


    @Override public Component getTreeCellRendererComponent(JTree   tree,
                                                            Object  value,
                                                            boolean selected,
                                                            boolean expanded,
                                                            boolean leaf,
                                                            int     row,
                                                            boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, selected,
                                           expanded, leaf, row, false);

        final ComparedTreeNode  node  = (ComparedTreeNode) value;
        final FileStateEnum     state = node.getState();
        final Icon              icon;

        if (rootOpenedIcon == null) {
            initialiseIcons();
        }
        if (plainFont == null) {
            initialiseFonts(this.getFont());
        }

        this.nodeStateIcon = getStateIcon(node);
        icon               = getTypeIcon(node, expanded, leaf);
        if (icon != null) {
            this.setIcon(icon);
        }

        this.hasFocus = hasFocus;
        this.setForeground(selected ? JBColor.black : getForegroundColor(state));
        this.setBackgroundSelectionColor(JBColor.lightGray);
        this.setBorderSelectionColor(null);
        this.setFont(plainFont);
        this.strikeThrough = node.isExcluded(); // Excluded nodes are rendered with strike-through fonts.
        this.setToolTipText(state.getText());

        return this;
    }

    private static Icon getTypeIcon(ComparedTreeNode node, boolean expanded, boolean leaf) {
        if (node == null) {
            return null;
        } else if (node instanceof JavaFieldTreeNode) {
            return getJavaClassMemberIcon(((JavaFieldTreeNode) node).getLeftMember());
        } else if (node instanceof FileTreeNode &&
                   !node.getLeftFile().isDirectory() &&
                   (leaf || node instanceof ClassFileTreeNode)) {
            final FileType fileType = ((FileTreeNode) node).getFileType();
            return (node instanceof ClassFileTreeNode)
                        ? getJavaClassIcon(((ClassFileTreeNode) node).getLeftClassDesc())
                        : fileType.getIcon();
        } else if (node.getParent() == null) {
            return (expanded ? rootOpenedIcon    : rootClosedIcon);
        } else if (node.getLeftFile().isCompressedFile()) {
            return (expanded ? zipFileOpenedIcon : zipFileClosedIcon);
        } else {
            return (expanded ? folderOpenedIcon  : folderClosedIcon);
        }
    }

    @Override public void paint(Graphics g) {
        int iconWidth = 0;

        if (this.nodeStateIcon != null) {
            iconWidth = this.nodeStateIcon.getIconWidth() + 2;
            if (g.getClipBounds().x <= iconWidth) {
                this.nodeStateIcon.paintIcon(null, g, 0, 0);
            }
            g.translate(iconWidth, 0);
        }
        super.paint(g);

        final boolean isLeftToRight = this.getComponentOrientation().isLeftToRight();
        final int     imageOffset   = ((this.hasFocus || this.strikeThrough) ? this.getLabelStart() : 0);
        final int     x             = (isLeftToRight ? imageOffset : 0);

        if (this.strikeThrough) {
            final FontMetrics fontMetrics = g.getFontMetrics();
            final int         height      = fontMetrics.getLeading() + fontMetrics.getDescent() +
                                            fontMetrics.getAscent() / 2;

            g.drawLine(x, height, this.getWidth() - imageOffset, height);
        }

        if (this.hasFocus) {
            this.paintFocus(g, x, 0, this.getWidth() - imageOffset - iconWidth, this.getHeight());
        }
    }

    private void paintFocus(Graphics g, int x, int y, int w, int h) {
        final Color bsColor = this.getBorderSelectionColor();

        if (bsColor != null && this.selected) {
            g.setColor(bsColor);
            g.drawRect(x, y, w - 1, h - 1);
        }

        Color color;

        if (this.selected) {
            color = this.getBackgroundSelectionColor();
        } else {
            color = this.getBackgroundNonSelectionColor();
            if (color == null) {
                color = this.getBackground();
            }
        }

        if (this.treeBGColor != color) {
            this.treeBGColor  = color;
            this.focusBGColor = new JBColor(~color.getRGB(), ~color.getRGB());
        }
        g.setColor(this.focusBGColor);
        BasicGraphicsUtils.drawDashedRect(g, x, y, w, h);
    }

    private int getLabelStart() {
        final Icon currentIcon = this.getIcon();

        if (currentIcon == null || this.getText() == null) {
            return 0;
        }
        return currentIcon.getIconWidth() + Math.max(0, this.getIconTextGap() - 1);
    }

    @Override public Dimension getPreferredSize() {
        final Dimension size = super.getPreferredSize();

        if (this.nodeStateIcon != null) {
            final int iconWidth  = this.nodeStateIcon.getIconWidth();
            final int iconHeight = this.nodeStateIcon.getIconHeight();

            size.width += iconWidth + 2;
            size.height = Math.max(size.height, iconHeight);
        }

        return size;
    }

    private static void initialiseIcons() {
        rootOpenedIcon                   = IconUtil.createIconWithKey("icon.root.open");
        rootClosedIcon                   = IconUtil.createIconWithKey("icon.root.closed");
        folderOpenedIcon                 = IconUtil.createIconWithKey("icon.folder.open");
        folderClosedIcon                 = IconUtil.createIconWithKey("icon.folder.closed");
        zipFileOpenedIcon                = IconUtil.createIconWithKey("icon.zip-file.open");
        zipFileClosedIcon                = IconUtil.createIconWithKey("icon.zip-file.closed");

        identicalIcon                    = IconUtil.createIconWithKey("icon.state.identical");
        differentIcon                    = IconUtil.createIconWithKey("icon.state.different");
        differentBlanksIcon              = IconUtil.createIconWithKey("icon.state.different-blanks");
        differentNonSignificantIcon      = IconUtil.createIconWithKey("icon.state.different-non-significant");
        leftOnlyIcon                     = IconUtil.createIconWithKey("icon.state.left-only");
        rightOnlyIcon                    = IconUtil.createIconWithKey("icon.state.right-only");
        probablyIdenticalIcon_leftNewer  = IconUtil.createIconWithKey("icon.state.probably-identical.left-newer");
        probablyIdenticalIcon_rightNewer = IconUtil.createIconWithKey("icon.state.probably-identical.right-newer");
        probablyDifferentIcon_leftNewer  = IconUtil.createIconWithKey("icon.state.probably-different.left-newer");
        probablyDifferentIcon_rightNewer = IconUtil.createIconWithKey("icon.state.probably-different.right-newer");
        mostProbablyIdenticalIcon        = IconUtil.createIconWithKey("icon.state.most-probably-identical");
    }

    private static void initialiseFonts(Font font) {
        plainFont = font;
    }

    private static Color getForegroundColor(FileStateEnum state) {
        return (state.isInitial()                                ? JBColor.darkGray :
                state == FileStateEnum.LEFT_ONLY                 ? darkBlue       :
                state == FileStateEnum.RIGHT_ONLY                ? darkGreen      :
                state == FileStateEnum.DIFFERENT                 ? darkRed        :
                state == FileStateEnum.DIFFERENT_IN_BLANKS       ? maroon         :
                state == FileStateEnum.DIFFERENT_NON_SIGNIFICANT ? darkYellow
                                                                 : JBColor.black);
    }

    private static Icon getStateIcon(ComparedTreeNode node) {
        switch (node.getState()) {
            case IDENTICAL:                 return identicalIcon;
            case DIFFERENT:                 return differentIcon;
            case DIFFERENT_IN_BLANKS:       return differentBlanksIcon;
            case DIFFERENT_IN_COMMENTS:     return differentNonSignificantIcon;
            case DIFFERENT_NON_SIGNIFICANT: return differentNonSignificantIcon;
            case LEFT_ONLY:                 return leftOnlyIcon;
            case RIGHT_ONLY:                return rightOnlyIcon;
            case MOST_PROBABLY_IDENTICAL:   return mostProbablyIdenticalIcon;
            case PROBABLY_IDENTICAL:        return (node.getLeftFile().lastModified() > node.getRightFile().lastModified())
                                                          ? probablyIdenticalIcon_leftNewer
                                                          : probablyIdenticalIcon_rightNewer;
            case PROBABLY_DIFFERENT:        return (node.getLeftFile().lastModified() > node.getRightFile().lastModified())
                                                          ? probablyDifferentIcon_leftNewer
                                                          : probablyDifferentIcon_rightNewer;
            case PSI_ELEMENT:               return null;
            default:                        return null;
        }
    }

    private static Icon getJavaClassIcon(JavaClassDesc javaClass) {
        if (javaClass == null) {
            return classIcon;
        }
        return (javaClass.isEnum()           ? enumClassIcon           :
                javaClass.isInterface()      ? interfaceIcon           :
                javaClass.isAnnotation()     ? annotationClassIcon     :
                javaClass.isAbstractStatic() ? abstractStaticClassIcon :
                javaClass.isAbstract()       ? abstractClassIcon       :
                javaClass.isStatic()         ? staticClassIcon
                                             : classIcon);
    }

    private static Icon getJavaClassMemberIcon(JavaClassMemberDesc member) {
        switch (member.getType()) {
            case FIELD:
                if (member.isStatic()) {
                    return (member.isFinal() ? staticFinalFieldIcon : staticFieldIcon);
                } else {
                    return (member.isFinal() ? finalFieldIcon       : fieldIcon);
                }

            case METHOD:
                return (member.isAbstract() ? abstractMethodIcon :
                        member.isLambda()   ? lambdaIcon         :
                        member.isStatic()   ? staticMethodIcon   :
                        member.isFinal()    ? finalMethodIcon
                                            : methodIcon);

            case CONSTRUCTOR:
                return methodIcon;

            case META_FIELD:
            case SPECIAL:
                return specialMethodIcon;
        }
        return null;
    }
}
