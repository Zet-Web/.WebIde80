/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

class JavaInstructions {

    /**
     * The Java Virtual Machine opcodes with their bytecode mnemonic and code to be run.
     * Note: Not all JVM opcodes are listed here as ASM library converts some of them into one of these.
     */
    public static final JavaInstruction[] INSTRUCTIONS = {
            new JavaInstruction       ("NOP"),
            new PushConstInstruction  ("ACONST_NULL", VarType.OBJECT, "null"),
            new PushConstInstruction  ("ICONST_M1",   VarType.INT,    "-1"),
            new PushConstInstruction  ("ICONST_0",    VarType.INT,    "0"),
            new PushConstInstruction  ("ICONST_1",    VarType.INT,    "1"),
            new PushConstInstruction  ("ICONST_2",    VarType.INT,    "2"),
            new PushConstInstruction  ("ICONST_3",    VarType.INT,    "3"),
            new PushConstInstruction  ("ICONST_4",    VarType.INT,    "4"),
            new PushConstInstruction  ("ICONST_5",    VarType.INT,    "5"),
            new PushConstInstruction  ("LCONST_0",    VarType.LONG,   "0L"),
            new PushConstInstruction  ("LCONST_1",    VarType.LONG,   "1L"),
            new PushConstInstruction  ("FCONST_0",    VarType.FLOAT,  "0.0f"),
            new PushConstInstruction  ("FCONST_1",    VarType.FLOAT,  "1.0f"),
            new PushConstInstruction  ("FCONST_2",    VarType.FLOAT,  "2.0f"),
            new PushConstInstruction  ("DCONST_0",    VarType.DOUBLE, "0.0"),
            new PushConstInstruction  ("DCONST_1",    VarType.DOUBLE, "1.0"),
            new PushLiteralInstruction("BIPUSH",      VarType.BYTE),
            new PushLiteralInstruction("SIPUSH",      VarType.SHORT),
            new PushLiteralInstruction("LDC",         VarType.OBJECT),
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            new PushVarInstruction    ("ILOAD", VarType.INT),
            new PushVarInstruction    ("LLOAD", VarType.LONG),
            new PushVarInstruction    ("FLOAD", VarType.FLOAT),
            new PushVarInstruction    ("DLOAD", VarType.DOUBLE),
            new PushVarInstruction    ("ALOAD", VarType.OBJECT),
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            new PushArrayElementInstruction("IALOAD", VarType.INT),
            new PushArrayElementInstruction("LALOAD", VarType.LONG),
            new PushArrayElementInstruction("FALOAD", VarType.FLOAT),
            new PushArrayElementInstruction("DALOAD", VarType.DOUBLE),
            new PushArrayElementInstruction("AALOAD", VarType.OBJECT),
            new PushArrayElementInstruction("BALOAD", VarType.BYTE),
            new PushArrayElementInstruction("CALOAD", VarType.CHAR),
            new PushArrayElementInstruction("SALOAD", VarType.SHORT),
            new PopVarInstruction          ("ISTORE", VarType.INT),
            new PopVarInstruction          ("LSTORE", VarType.LONG),
            new PopVarInstruction          ("FSTORE", VarType.FLOAT),
            new PopVarInstruction          ("DSTORE", VarType.DOUBLE),
            new PopVarInstruction          ("ASTORE", VarType.OBJECT),
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            JavaInstruction.NULL,
            new PopArrayElementInstruction("IASTORE", VarType.INT),
            new PopArrayElementInstruction("LASTORE", VarType.LONG),
            new PopArrayElementInstruction("FASTORE", VarType.FLOAT),
            new PopArrayElementInstruction("DASTORE", VarType.DOUBLE),
            new PopArrayElementInstruction("AASTORE", VarType.OBJECT),
            new PopArrayElementInstruction("BASTORE", VarType.BYTE),
            new PopArrayElementInstruction("CASTORE", VarType.CHAR),
            new PopArrayElementInstruction("SASTORE", VarType.SHORT),
            new PopInstruction            ("POP",     VarType.INT),
            new PopInstruction            ("POP2",    VarType.LONG),
            new DuplicateInstruction      ("DUP",     VarType.INT,  1),
            new DuplicateInstruction      ("DUP_X1",  VarType.INT,  2),
            new DuplicateInstruction      ("DUP_X2",  VarType.INT,  3),
            new DuplicateInstruction      ("DUP2",    VarType.LONG, 1),
            new DuplicateInstruction      ("DUP2_X1", VarType.LONG, 2),
            new DuplicateInstruction      ("DUP2_X2", VarType.LONG, 3),
            new SwapInstruction           ("SWAP"),
            new BinaryOperator            ("IADD",    VarType.INT,    "+"),
            new BinaryOperator            ("LADD",    VarType.LONG,   "+"),
            new BinaryOperator            ("FADD",    VarType.FLOAT,  "+"),
            new BinaryOperator            ("DADD",    VarType.DOUBLE, "+"),
            new BinaryOperator            ("ISUB",    VarType.INT,    "-"),
            new BinaryOperator            ("LSUB",    VarType.LONG,   "-"),
            new BinaryOperator            ("FSUB",    VarType.FLOAT,  "-"),
            new BinaryOperator            ("DSUB",    VarType.DOUBLE, "-"),
            new BinaryOperator            ("IMUL",    VarType.INT,    "*"),
            new BinaryOperator            ("LMUL",    VarType.LONG,   "*"),
            new BinaryOperator            ("FMUL",    VarType.FLOAT,  "*"),
            new BinaryOperator            ("DMUL",    VarType.DOUBLE, "*"),
            new BinaryOperator            ("IDIV",    VarType.INT,    "/"),
            new BinaryOperator            ("LDIV",    VarType.LONG,   "/"),
            new BinaryOperator            ("FDIV",    VarType.FLOAT,  "/"),
            new BinaryOperator            ("DDIV",    VarType.DOUBLE, "/"),
            new BinaryOperator            ("IREM",    VarType.INT,    "rem"),
            new BinaryOperator            ("LREM",    VarType.LONG,   "rem"),
            new BinaryOperator            ("FREM",    VarType.FLOAT,  "rem"),
            new BinaryOperator            ("DREM",    VarType.DOUBLE, "rem"),
            new  UnaryOperator            ("INEG",    VarType.INT,    "-"),
            new  UnaryOperator            ("LNEG",    VarType.LONG,   "-"),
            new  UnaryOperator            ("FNEG",    VarType.FLOAT,  "-"),
            new  UnaryOperator            ("DNEG",    VarType.DOUBLE, "-"),
            new BinaryOperator            ("ISHR",    VarType.INT,    "<<"),
            new BinaryOperator            ("LSHR",    VarType.LONG,   "<<"),
            new BinaryOperator            ("ISHR",    VarType.INT,    ">>"),
            new BinaryOperator            ("LSHR",    VarType.LONG,   ">>"),
            new BinaryOperator            ("IUSHR",   VarType.INT,    ">>>"),
            new BinaryOperator            ("LUSHR",   VarType.LONG,   ">>>"),
            new BinaryOperator            ("IAND",    VarType.INT,    "&"),
            new BinaryOperator            ("LAND",    VarType.LONG,   "&"),
            new BinaryOperator            ("IOR",     VarType.INT,    "|"),
            new BinaryOperator            ("LOR",     VarType.LONG,   "|"),
            new BinaryOperator            ("IXOR",    VarType.INT,    "^"),
            new BinaryOperator            ("LXOR",    VarType.LONG,   "^"),
            new IncInstruction            ("IINC"),
            new ConvertOperator           ("I2L",     VarType.INT,    VarType.LONG),
            new ConvertOperator           ("I2F",     VarType.INT,    VarType.FLOAT),
            new ConvertOperator           ("I2D",     VarType.INT,    VarType.DOUBLE),
            new ConvertOperator           ("L2I",     VarType.LONG,   VarType.INT),
            new ConvertOperator           ("L2F",     VarType.LONG,   VarType.FLOAT),
            new ConvertOperator           ("L2D",     VarType.LONG,   VarType.DOUBLE),
            new ConvertOperator           ("F2I",     VarType.FLOAT,  VarType.INT),
            new ConvertOperator           ("F2L",     VarType.FLOAT,  VarType.LONG),
            new ConvertOperator           ("F2D",     VarType.FLOAT,  VarType.DOUBLE),
            new ConvertOperator           ("D2I",     VarType.DOUBLE, VarType.INT),
            new ConvertOperator           ("D2L",     VarType.DOUBLE, VarType.LONG),
            new ConvertOperator           ("D2F",     VarType.DOUBLE, VarType.FLOAT),
            new ConvertOperator           ("I2B",     VarType.INT,    VarType.BYTE),
            new ConvertOperator           ("I2C",     VarType.INT,    VarType.CHAR),
            new ConvertOperator           ("I2S",     VarType.INT,    VarType.SHORT),
            new CompareOperator           ("LCMP",    VarType.LONG),
            new CompareOperator           ("FCMPL",   VarType.FLOAT),
            new CompareOperator           ("FCMPG",   VarType.FLOAT),
            new CompareOperator           ("DCMPL",   VarType.DOUBLE),
            new CompareOperator           ("DCMPG",   VarType.DOUBLE),
            new IfCompareToZeroInstruction("IFEQ",      ComparisonOperator.EQ,  false),
            new IfCompareToZeroInstruction("IFNE",      ComparisonOperator.NEQ, false),
            new IfCompareToZeroInstruction("IFLT",      ComparisonOperator.LT,  false),
            new IfCompareToZeroInstruction("IFGE",      ComparisonOperator.GE,  false),
            new IfCompareToZeroInstruction("IFGT",      ComparisonOperator.GT,  false),
            new IfCompareToZeroInstruction("IFLE",      ComparisonOperator.LE,  false),
            new IfCompareInstruction      ("IF_ICMPEQ", ComparisonOperator.EQ,  VarType.INT),
            new IfCompareInstruction      ("IF_ICMPNE", ComparisonOperator.NEQ, VarType.INT),
            new IfCompareInstruction      ("IF_ICMPLT", ComparisonOperator.LT,  VarType.INT),
            new IfCompareInstruction      ("IF_ICMPGE", ComparisonOperator.GE,  VarType.INT),
            new IfCompareInstruction      ("IF_ICMPGT", ComparisonOperator.GT,  VarType.INT),
            new IfCompareInstruction      ("IF_ICMPLE", ComparisonOperator.LE,  VarType.INT),
            new IfCompareInstruction      ("IF_ACMPEQ", ComparisonOperator.EQ,  VarType.OBJECT),
            new IfCompareInstruction      ("IF_ACMPNE", ComparisonOperator.NEQ, VarType.OBJECT),
            new GotoInstruction           ("GOTO"),
            new FinallyInstruction        ("JSR"),
            new JavaInstruction           ("RET"),
            new SwitchInstruction         ("TABLESWITCH",     true),
            new SwitchInstruction         ("LOOKUPSWITCH",    false),
            new ReturnInstruction         ("IRETURN",         VarType.INT),
            new ReturnInstruction         ("LRETURN",         VarType.LONG),
            new ReturnInstruction         ("FRETURN",         VarType.FLOAT),
            new ReturnInstruction         ("DRETURN",         VarType.DOUBLE),
            new ReturnInstruction         ("ARETURN",         VarType.OBJECT),
            new ReturnInstruction         ("RETURN",          null),
            new GetFieldInstruction       ("GETSTATIC",       true),
            new PutFieldInstruction       ("PUTSTATIC",       true),
            new GetFieldInstruction       ("GETFIELD",        false),
            new PutFieldInstruction       ("PUTFIELD",        false),
            new InvokeInstruction         ("INVOKEVIRTUAL",   InvokeStyle.Virtual),
            new InvokeInstruction         ("INVOKESPECIAL",   InvokeStyle.Special),
            new InvokeInstruction         ("INVOKESTATIC",    InvokeStyle.Static),
            new InvokeInstruction         ("INVOKEINTERFACE", InvokeStyle.Interface),
            new InvokeInstruction         ("INVOKEDYNAMIC",   InvokeStyle.Dynamic),
            new NewInstruction            ("NEW",             false),
            new NewInstruction            ("NEWARRAY",        true),
            new NewInstruction            ("ANEWARRAY",       true),
            new ArrayLengthExpression     ("ARRAYLENGTH"),
            new ThrowInstruction          ("ATHROW"),
            new CheckCastOperator         ("CHECKCAST"),
            new InstanceOfOperator        ("INSTANCEOF"),
            new MonitorInstruction        ("MONITORENTER",    true),
            new MonitorInstruction        ("MONITOREXIT",     false),
            JavaInstruction.NULL,
            new NewInstruction            ("MULTIANEWARRAY",  true),
            new IfCompareToZeroInstruction("IFNULL",          ComparisonOperator.EQ,  true),
            new IfCompareToZeroInstruction("IFNONNULL",       ComparisonOperator.NEQ, true)
        };

    /**
     * The ASM handles for dynamic invocations.
     */
    public static final JavaInstruction[] HANDLES = {
            null,
            INSTRUCTIONS[Opcodes.GETFIELD],
            INSTRUCTIONS[Opcodes.GETSTATIC],
            INSTRUCTIONS[Opcodes.PUTFIELD],
            INSTRUCTIONS[Opcodes.PUTSTATIC],
            INSTRUCTIONS[Opcodes.INVOKEVIRTUAL],
            INSTRUCTIONS[Opcodes.INVOKESTATIC],
            INSTRUCTIONS[Opcodes.INVOKESPECIAL],
            new InvokeInstruction("NEWINVOKESPECIAL", InvokeStyle.Special),
            INSTRUCTIONS[Opcodes.INVOKEINTERFACE]
    };

    /**
     * Types for <code>operand</code> parameter of the
     * {@link org.jetbrains.asm4.MethodVisitor#visitIntInsn} method when
     * <code>opcode</code> is <code>NEWARRAY</code>.
     */
    public static final String[] TYPES = { "", "", "", "", "boolean", "char", "float", "double",
                                           "byte", "short", "int", "long" };

    private enum ComparisonOperator {
        EQ ("=="),
        NEQ("!="),
        LT ("<"),
        GE (">="),
        GT (">"),
        LE ("<=");

        static {
            // Cannot initialise the opposite operators in constructors
            // since it would lead to forward references in declarations
            EQ .opposite = NEQ;
            NEQ.opposite = EQ;
            LT .opposite = GE;
            GE .opposite = LT;
            GT .opposite = LE;
            LE .opposite = GT;
        }

        private final String       text;
        private ComparisonOperator opposite;

        ComparisonOperator(String text) {
            this.text = text;
        }

        public String getText() {
            return this.text;
        }

        public ComparisonOperator getOpposite() {
            return this.opposite;
        }
    }

    enum InvokeStyle { Virtual, Special, Static, Interface, Dynamic }

    private static class LabelStatement extends JavaInstruction {
        private final int number;

        public LabelStatement(String mnemonic, int number) {
            super(mnemonic);
            this.number = number;
        }
    }

    private static class PushConstInstruction extends JavaInstruction {
        private final VarType varType;
        private final String  constant;

        public PushConstInstruction(String mnemonic, VarType varType, String constant) {
            super(mnemonic);
            this.varType  = varType;
            this.constant = constant;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            methodVisitor.offerOperand(this.constant, this.varType);
        }
    }

    private static class PushLiteralInstruction extends JavaInstruction {
        private final VarType varType;

        public PushLiteralInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            methodVisitor.offerOperand((String) opcodeArgs[0], this.varType);
        }
    }

    private static class PushVarInstruction extends JavaInstruction {
        private final VarType varType;

        public PushVarInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String variableName = methodVisitor.getVariableName(this.varType, (Integer) opcodeArgs[0], true);

            methodVisitor.offerOperand(variableName, this.varType);
        }
    }

    private static class PushArrayElementInstruction extends JavaInstruction {
        private final VarType varType;

        public PushArrayElementInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String arrayIndex   = methodVisitor.pollOperand(VarType.INT);
            final String arrayVarName = methodVisitor.pollOperand(VarType.OBJECT);
            final String expression   = arrayVarName + '[' + arrayIndex + ']';

            methodVisitor.offerOperand(expression, this.varType);
        }
    }

    private static class PopVarInstruction extends JavaInstruction {
        private final VarType varType;

        public PopVarInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String variableName = methodVisitor.getVariableName(this.varType, (Integer) opcodeArgs[0], true);
            final String value        = methodVisitor.pollOperand(this.varType);

            methodVisitor.getPrinter().appendIndented(variableName, " = ", value, ";\n");
        }
    }

    private static class PopArrayElementInstruction extends JavaInstruction {
        private final VarType varType;

        public PopArrayElementInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String value        = methodVisitor.pollOperand(this.varType);
            final String arrayIndex   = methodVisitor.pollOperand(VarType.INT);
            final String arrayVarName = methodVisitor.pollOperand(VarType.OBJECT);

            methodVisitor.getPrinter().appendIndented(arrayVarName, "[", arrayIndex, "] = ", value, ";\n");
        }
    }

    private static class PopInstruction extends JavaInstruction {
        private final VarType varType;

        public PopInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String expression = methodVisitor.pollOperand(this.varType);

            methodVisitor.getPrinter().appendIndented(expression, ";\n");
        }
    }

    private static class DuplicateInstruction extends JavaInstruction {
        private final VarType varType;
        private final int     belowStackTop;

        public DuplicateInstruction(String mnemonic, VarType varType, int belowStackTop) {
            super(mnemonic);
            this.varType       = varType;
            this.belowStackTop = belowStackTop + (varType.isDoubleWord() ? 1 : 0);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String[] stackTop = new String[this.belowStackTop];

            for (int i = 0; i < this.belowStackTop; i++) {
                stackTop[i] = methodVisitor.pollOperand(VarType.INT);
            }

            if (this.varType.isDoubleWord()) {
                methodVisitor.offerOperand(stackTop[1], VarType.INT);
            }
            methodVisitor.offerOperand(stackTop[0], VarType.INT);

            for (int i = this.belowStackTop; --i >= 0; ) {
                methodVisitor.offerOperand(stackTop[i], VarType.INT);
            }
        }
    }

    private static class SwapInstruction extends JavaInstruction {
        private SwapInstruction(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String value1 = methodVisitor.pollOperand(VarType.INT);
            final String value2 = methodVisitor.pollOperand(VarType.INT);

            methodVisitor.offerOperand(value1, VarType.INT);
            methodVisitor.offerOperand(value2, VarType.INT);
        }
    }

    private static class UnaryOperator extends JavaInstruction {
        private final VarType varType;
        private final String  operator;

        public UnaryOperator(String mnemonic, VarType varType, String operator) {
            super(mnemonic);
            this.varType  = varType;
            this.operator = operator;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String operand = methodVisitor.pollOperand(this.varType);
            final String value   = this.operator + '(' + operand + ')';

            methodVisitor.offerOperand(value, this.varType);
        }
    }

    private static class BinaryOperator extends JavaInstruction {
        private final VarType varType;
        private final String  operator;

        public BinaryOperator(String mnemonic, VarType varType, String operator) {
            super(mnemonic);
            this.varType  = varType;
            this.operator = operator;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String operand2 = methodVisitor.pollOperand(this.varType);
            final String operand1 = methodVisitor.pollOperand(this.varType);
            final String value    = '(' + operand1 + this.operator + operand2 + ')';

            methodVisitor.offerOperand(value, this.varType);
        }
    }

    private static class IncInstruction extends JavaInstruction {
        private IncInstruction(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String variableName = methodVisitor.getVariableName(VarType.INT, (Integer) opcodeArgs[0], true);
            final int    increment    = (Integer) opcodeArgs[1];

            if (increment < 0) {
                if (increment == -1) {
                    methodVisitor.getPrinter().appendIndented(variableName, "--;\n");
                } else {
                    methodVisitor.getPrinter().appendIndented(variableName, " -= ", Integer.toString(-increment), ";\n");
                }
            } else {
                if (increment == 1) {
                    methodVisitor.getPrinter().appendIndented(variableName, "++;\n");
                } else {
                    methodVisitor.getPrinter().appendIndented(variableName, " += ", Integer.toString(increment), ";\n");
                }
            }
        }
    }

    private static class ConvertOperator extends JavaInstruction {
        private final VarType fromVarType;
        private final VarType toVarType;

        public ConvertOperator(String mnemonic, VarType fromVarType, VarType toVarType) {
            super(mnemonic);
            this.fromVarType = fromVarType;
            this.toVarType   = toVarType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String value = methodVisitor.pollOperand(this.fromVarType);

            methodVisitor.offerOperand('(' + this.toVarType.getTypeName() + ") " + value,
                                       this.toVarType);
        }
    }

    private static class CompareOperator extends JavaInstruction {
        private final VarType varType;

        public CompareOperator(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String operand2 = methodVisitor.pollOperand(this.varType);
            final String operand1 = methodVisitor.pollOperand(this.varType);

            // We do not know the operator yet (wait for the following if...)
            // => use CAFE-BABE char sequence as an operator placeholder
            methodVisitor.offerOperand(operand1 + " \uCAFE\uBABE " + operand2, VarType.INT);
        }
    }

    private static class IfCompareToZeroInstruction extends JavaInstruction {
        private final ComparisonOperator operator;
        private final boolean            isReference;

        public IfCompareToZeroInstruction(String mnemonic, ComparisonOperator operator, boolean isReference) {
            super(mnemonic);
            this.operator    = operator;
            this.isReference = isReference;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            String value = methodVisitor.pollOperand(VarType.INT);

            // Replace the CAFE-BABE operator placeholder with the real operator if any
            if (value.contains("\uCAFE\uBABE")) {
                value = value.replace("\uCAFE\uBABE", this.operator.getText());
            } else {
                value += ' ' + this.operator.getText() + (this.isReference ? " null" : " 0");
            }
            methodVisitor.getPrinter().appendIndented("if (", value, ") goto ", String.valueOf(opcodeArgs[0]), ";\n");
        }
    }

    private static class IfCompareInstruction extends JavaInstruction {
        private final ComparisonOperator operator;
        private final VarType            varType;

        public IfCompareInstruction(String mnemonic, ComparisonOperator operator, VarType varType) {
            super(mnemonic);
            this.operator = operator;
            this.varType  = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String operand2 = methodVisitor.pollOperand(this.varType);
            final String operand1 = methodVisitor.pollOperand(this.varType);

            methodVisitor.getPrinter().appendIndented("if (", operand1, " ", this.operator.getText(),
                                                      Printer.SPACE, operand2, ") goto ",
                                                      String.valueOf(opcodeArgs[0]), ";\n");
        }
    }

    private static class GotoInstruction extends JavaInstruction {
        private GotoInstruction(String mnemonic) {
            super(mnemonic);
        }
    }

    private static class FinallyInstruction extends JavaInstruction {
        private FinallyInstruction(String mnemonic) {
            super(mnemonic);
        }
    }

    private static class SwitchInstruction extends JavaInstruction {
        private final boolean table;

        private SwitchInstruction(String mnemonic, boolean table) {
            super(mnemonic);
            this.table = table;
        }
    }

    private static class ReturnInstruction extends JavaInstruction {
        private final VarType varType;

        public ReturnInstruction(String mnemonic, VarType varType) {
            super(mnemonic);
            this.varType = varType;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String value = (this.varType == null) ? null : methodVisitor.pollOperand(this.varType);

            methodVisitor.getPrinter().appendIndented("return");
            if (value != null) {
                methodVisitor.getPrinter().append(Printer.SPACE, value);
            }
            methodVisitor.getPrinter().append(";\n");
        }
    }

    private static class GetFieldInstruction extends JavaInstruction {
        private final boolean isStatic;

        public GetFieldInstruction(String mnemonic, boolean isStatic) {
            super(mnemonic);
            this.isStatic = isStatic;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String fieldName = (String) opcodeArgs[1];

            if (this.isStatic) {
                final String className = methodVisitor.classVisitor.ensureClassImported(AsmUtil.getQualified((String) opcodeArgs[0]));

                methodVisitor.offerOperand(className + '.' + fieldName, VarType.OBJECT);
            } else {
                final String object = methodVisitor.pollOperand(VarType.OBJECT) + '.' + fieldName;

                methodVisitor.offerOperand(object, VarType.valueOfType((String) opcodeArgs[0]));
            }
        }
    }

    private static class PutFieldInstruction extends JavaInstruction {
        private final boolean isStatic;

        public PutFieldInstruction(String mnemonic, boolean isStatic) {
            super(mnemonic);
            this.isStatic = isStatic;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String value     = methodVisitor.pollOperand(VarType.valueOfType((String) opcodeArgs[2]));
            final String fieldName = (String) opcodeArgs[1];

            if (this.isStatic) {
                final String className = methodVisitor.classVisitor.ensureClassImported(AsmUtil.getQualified((String) opcodeArgs[0]));

                methodVisitor.getPrinter().appendIndented(className, ".", fieldName, " = ", value, ";\n");
            } else {
                final String object = methodVisitor.pollOperand(VarType.OBJECT);

                methodVisitor.getPrinter().appendIndented(object, ".", fieldName, " = ", value, ";\n");
            }
        }
    }

    private static class InvokeInstruction extends JavaInstruction {
        private final InvokeStyle style;

        public InvokeInstruction(String mnemonic, InvokeStyle style) {
            super(mnemonic);
            this.style = style;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String   ownerClassName = AsmUtil.getQualified((String) opcodeArgs[0]);
            String         name           = (String) opcodeArgs[1];
            final String   desc           = (String) opcodeArgs[2];
            final Type     returnType     = Type.getReturnType   (desc);
            final Type[]   argumentTypes  = Type.getArgumentTypes(desc);
            final String[] arguments      = new String[argumentTypes.length];

            for (int i = arguments.length; --i >= 0; ) {
                arguments[i] = methodVisitor.pollOperand(VarType.valueOfType(argumentTypes[i]));
            }

            final String object = ((this.style == InvokeStyle.Static)
                                        ? methodVisitor.classVisitor.ensureClassImported(AsmUtil.getQualified((String) opcodeArgs[0]))
                                        : methodVisitor.pollOperand(VarType.OBJECT));
            final boolean isNewInstance = "new ".equals(object);

            final FullClassVisitor classVisitor = methodVisitor.classVisitor;

            if ("<init>".equals(name)) {
                // Prints out the constructor
                // Note: Is it a constructor definition or a call to "this" or "super" constructor?
                name = (ownerClassName == null                                               ? classVisitor.getSimpleClassName() :
                        ownerClassName.equals(classVisitor.getClassName()) && !isNewInstance ? "this" :
                        ownerClassName.equals(classVisitor.getSuperClassName())              ? "super"
                                                                                             : classVisitor.ensureClassImported(ownerClassName));
            }

            final StringBuilder argumentList = classVisitor.getClassVisitorContext().allocateBuilder().append('(');

            for (String argument : arguments) {
                if (argumentList.length() > 1) {
                    argumentList.append(", ");
                }
                argumentList.append(argument);
            }

            if (this.style != InvokeStyle.Special) {
                argumentList.insert(0, name)
                            .insert(0, '.')
                            .insert(0, object)
                            .append(')');

                methodVisitor.offerOperand(argumentList.toString(), VarType.valueOfType(returnType));
            } else if (isNewInstance) {
                argumentList.insert(0, name)
                            .insert(0, object)
                            .append(')');
                methodVisitor.pollOperand(VarType.OBJECT); // Remove "new " from operand stack.

                methodVisitor.offerOperand(argumentList.toString(), VarType.valueOfType(returnType));
            } else {
                methodVisitor.getPrinter().appendIndented(name, argumentList.toString(), ");\n");
            }
            classVisitor.getClassVisitorContext().disposeBuilder(argumentList);
        }
    }

    private static class NewInstruction extends JavaInstruction {
        private final boolean array;

        public NewInstruction(String mnemonic, boolean array) {
            super(mnemonic);
            this.array = array;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String type = methodVisitor.classVisitor.ensureClassImported(AsmUtil.getQualified((String) opcodeArgs[0]));

            if (this.array) {
                final String variableName = methodVisitor.generateVariableName(VarType.OBJECT, type);
                final String arrayLength  = methodVisitor.pollOperand(VarType.OBJECT);

                methodVisitor.getPrinter().appendIndented(type, Printer.SPACE, variableName,
                                                          " = new ", type, "[", arrayLength, "];", Printer.CR);
                methodVisitor.offerOperand(variableName, VarType.OBJECT);
            } else {
                methodVisitor.offerOperand("new " + type, VarType.OBJECT);
            }
        }
    }

    private static class ArrayLengthExpression extends JavaInstruction {
        private ArrayLengthExpression(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String array = methodVisitor.pollOperand(VarType.OBJECT);

            methodVisitor.offerOperand(array + ".length", VarType.INT);
        }
    }

    private static class ThrowInstruction extends JavaInstruction {
        private ThrowInstruction(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String object = methodVisitor.pollOperand(VarType.OBJECT);

            methodVisitor.getPrinter().appendIndented("throw ", object, ";\n");
        }
    }

    private static class CheckCastOperator extends JavaInstruction {
        private CheckCastOperator(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String object = methodVisitor.pollOperand(VarType.OBJECT);

            methodVisitor.offerOperand('(' + (String) opcodeArgs[0] + ") " + object, VarType.OBJECT);
        }
    }

    private static class InstanceOfOperator extends JavaInstruction {
        private InstanceOfOperator(String mnemonic) {
            super(mnemonic);
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            final String object = methodVisitor.pollOperand(VarType.OBJECT);

            methodVisitor.offerOperand(object + " instanceof " + opcodeArgs[0], VarType.INT);
        }
    }

    private static class MonitorInstruction extends JavaInstruction {
        private final boolean enter;

        public MonitorInstruction(String mnemonic, boolean enter) {
            super(mnemonic);
            this.enter = enter;
        }

        @Override public void apply(JavaMethodVisitor methodVisitor, Object... opcodeArgs) {
            if (this.enter) {
                final String object = methodVisitor.pollOperand(VarType.OBJECT);

                methodVisitor.getPrinter().appendIndented("synchronized (", object, ") {\n")
                             .indent();
            } else {
                methodVisitor.printer.unindent()
                             .appendIndented("}\n");
            }
        }
    }
}
