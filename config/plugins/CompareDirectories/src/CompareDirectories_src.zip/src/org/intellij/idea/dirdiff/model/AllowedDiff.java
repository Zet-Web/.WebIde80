/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import java.util.regex.Pattern;

/**
 * The description of a non-significant diff
 */
public class AllowedDiff {

    private Pattern nodeNamePattern;
    private String  originalText;
    private boolean regexp;

    public Pattern getNodeNamePattern() {
        return this.nodeNamePattern;
    }

    public void setNodeNamePattern(Pattern nodeNamePattern) {
        this.nodeNamePattern = nodeNamePattern;
    }

    public String getOriginalText() {
        return this.originalText;
    }

    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }

    public boolean isRegexp() {
        return this.regexp;
    }

    public void setRegexp(boolean regexp) {
        this.regexp = regexp;
    }

    public boolean match(ComparedTreeNode node, String left, String right)  {
        if (!this.isMatchable(node)) {
            return false;
        } else if (this.regexp) {
            return equalsIgnoreBlanks(left .replaceAll(this.originalText, ""),
                                      right.replaceAll(this.originalText, ""));
        } else {
            return equalsIgnoreBlanks(left .replace(this.originalText, ""),
                                      right.replace(this.originalText, ""));
        }
    }

    public boolean isMatchable(ComparedTreeNode node) {
        return (node instanceof FileTreeNode &&
                this.nodeNamePattern.matcher(node.getLeftFile().getPath()).matches());
    }

    private static boolean equalsIgnoreBlanks(CharSequence left, CharSequence right) {
        int leftIndex  = left.length()  - 1;
        int rightIndex = right.length() - 1;

        while (leftIndex >= 0 && rightIndex >= 0) {
            final char leftChar  = left .charAt(leftIndex);
            final char rightChar = right.charAt(rightIndex);

            if (leftChar == rightChar) {
                leftIndex--;
                rightIndex--;
            } else if (Character.isWhitespace(leftChar)) {
                leftIndex--;
            } else if (Character.isWhitespace(rightChar)) {
                rightIndex--;
            } else {
                return false;
            }
        }

        while (leftIndex >= 0) {
            if (!Character.isWhitespace(left.charAt(leftIndex))) {
                return false;
            }
            leftIndex--;
        }

        while (rightIndex >= 0) {
            if (Character.isWhitespace(right.charAt(rightIndex))) {
                return false;
            }
            rightIndex--;
        }

        return true;
    }
}