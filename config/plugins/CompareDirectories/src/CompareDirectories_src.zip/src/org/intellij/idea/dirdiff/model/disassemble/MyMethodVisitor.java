/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.intellij.openapi.Disposable;
import gnu.trove.THashMap;
import gnu.trove.TObjectIntHashMap;
import gnu.trove.TObjectIntProcedure;
import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.asm4.AnnotationVisitor;
import org.jetbrains.asm4.Attribute;
import org.jetbrains.asm4.Handle;
import org.jetbrains.asm4.Label;
import org.jetbrains.asm4.MethodVisitor;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

abstract class MyMethodVisitor extends MethodVisitor implements Disposable {

    protected final Printer                   printer;
    protected       List<String>              localVariables;
    protected       List<String>              localVariableTypes;
    protected       TObjectIntHashMap<String> lastVariableNameSuffix;
    protected final FullClassVisitor          classVisitor;
    protected       int                       startBufferIndex;
    protected       JavaClassMemberDesc       javaMethod;

    /**
     * The label names. This map associate String values to Label keys.
     */
    protected final Map<Label, String> labelNames;


    MyMethodVisitor(FullClassVisitor classVisitor, Printer bufferPrinter, JavaClassMemberDesc javaMethod) {
        super(Opcodes.ASM4);
        this.printer                = new Printer(bufferPrinter, classVisitor.getPrinter().getIndentLevel());
        this.classVisitor           = classVisitor;
        this.localVariables         = new ArrayList<String>();
        this.localVariableTypes     = new ArrayList<String>();
        this.lastVariableNameSuffix = new TObjectIntHashMap<String>();
        this.labelNames             = new THashMap<Label, String>();
        this.javaMethod             = javaMethod;

        if (!javaMethod.isStatic()) {
            this.localVariables.add("this");
            this.localVariableTypes.add(classVisitor.getClassName());
        }
    }

    public Printer getPrinter() {
        return this.printer;
    }

    @Override public AnnotationVisitor visitAnnotationDefault() {
        this.printer.append(" default ");
        return new MethodAnnotationPrinter();
    }

    private void visitAnnotationDefaultValue(Object value) {
        this.printer.append(this.classVisitor.getLiteral(value));
    }

    private void visitAnnotationDefaultEnumValue(String desc, String value) {
        final String qualifiedClassName = AsmUtil.getQualified(desc.substring(1, desc.length() - 1));

        this.printer.append(this.classVisitor.ensureClassImported(qualifiedClassName),
                            ".",
                            value);
    }

    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
        this.printer.insertIndented(this.printer.lastIndexOf('\n') + 1,
                                    "@", this.classVisitor.ensureClassImported(Type.getType(desc)), Printer.CR);
        return null;
    }

    @Override public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible) {
        int index = this.printer.lastIndexOf('(');

        while (parameter-- > 0) {
            index = this.printer.indexOf(index + 1, ',') + 1;
        }
        return new MyAnnotationVisitor(desc, this.classVisitor, this.printer, false, index + 1);
    }

    @Override public void visitAttribute(Attribute attr) {
    }

    public abstract void visitCode();

    @Override public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
    }

    public abstract void visitInsn(int opcode);

    public abstract void visitIntInsn(int opcode, int operand);

    public abstract void visitVarInsn(int opcode, int var);

    public final void setArguments(List<String> variableTypes, List<String> variableNames) {
        this.localVariableTypes.addAll(variableTypes);
        this.localVariables    .addAll(variableNames);
    }

    public final String generateVariableName(VarType varType, String typeName) {
        final int index;

        typeName = varType.getTypeName(typeName);
        if (this.lastVariableNameSuffix.containsKey(typeName)) {
            this.lastVariableNameSuffix.increment(typeName);
            index = this.lastVariableNameSuffix.get(typeName);
        } else {
            index = 0;
            this.lastVariableNameSuffix.put(typeName, 0);
        }

        final String variableName = varType.getVariableName(typeName, index,
                                                            this.classVisitor.getClassVisitorContext());

        this.localVariables    .add(variableName);
        this.localVariableTypes.add(typeName);

        return variableName;
    }

    protected final String getVariableName(VarType varType, int var, boolean printDeclaration) {
        if (var >= this.localVariables.size()) {
            final String variableName = this.generateVariableName(varType, null);

            if (printDeclaration) {
                this.printer.appendIndented(varType.getTypeName(), Printer.SPACE, variableName, ";", Printer.CR);
            }
            return variableName;
        }

        return (var < this.localVariables.size()) ? this.localVariables.get(var) : Integer.toString(var);
    }

    protected final void replaceAllOccurrences(String searchedVarName, String replacementName, String typeDesc) {
        final int searchedVarNameLength = searchedVarName.length();
        int       index                 = this.printer.lastIndexOf(searchedVarName);

        while (index >= this.startBufferIndex) {
            final char nextChar = this.printer.charAt(index + searchedVarNameLength);

            if (!(Character.isDigit(nextChar) || Character.isJavaIdentifierPart(nextChar))) {
                this.printer.replace(index, index + searchedVarNameLength, replacementName);
            }

            // If occurrence is declaration of type Object => change type name in declaration
            if (typeDesc != null && /*index >= 6 &&
                "Object".equals(this.printer.substring(index - 6, index)) &&
                this.printer.charAt(index + replacementName.length()) == ';'*/
                this.printer.endsWith  (index, "Object") &&
                this.printer.startsWith(index + replacementName.length(), ";")) {

                final String typeName = FieldSignatureVisitor.getTypeName(typeDesc, this.classVisitor.getClassVisitorContext());

                this.printer.replace(index - 6, index, typeName);
            }

            index = this.printer.lastIndexOf(searchedVarName, index - 1);
        }
    }

    protected final void normalizeGeneratedVariableNames() {
        this.lastVariableNameSuffix.forEachEntry(new TObjectIntProcedure<String>() {
            public boolean execute(String variableTypeName, int lastSuffix) {
                if (lastSuffix == 0 && !AsmUtil.isClassClass(variableTypeName)) {
                    final int index = MyMethodVisitor.this.localVariableTypes.indexOf(variableTypeName);

                    if (index >= 0) {
                        final String oldVarName    = MyMethodVisitor.this.localVariables.get(index);
                        final int    lastCharIndex = oldVarName.length() - 1;

                        if (oldVarName.charAt(lastCharIndex) == '0') {
                            MyMethodVisitor.this.replaceAllOccurrences(oldVarName, oldVarName.substring(0, lastCharIndex), null);
                        }
                    }
                }

                // Go on for-each loop
                return true;
            }
        });
    }

    public abstract void visitTypeInsn(int opcode, String type);

    public abstract void visitFieldInsn(int opcode, String owner, String name, String desc);

    public abstract void visitMethodInsn(int opcode, String owner, String name, String desc);

    public abstract void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs);

    public abstract void visitJumpInsn(int opcode, Label label);

    public abstract void visitLabel(Label label);

    public abstract void visitLdcInsn(Object cst);

    public abstract void visitIincInsn(int var, int increment);

    public abstract void visitTableSwitchInsn(int min, int max, Label defaultLabel, Label[] labels);

    public abstract void visitLookupSwitchInsn(Label defaultLabel, int[] keys, Label[] labels);

    public abstract void visitMultiANewArrayInsn(String desc, int dims);

    public abstract void visitTryCatchBlock(Label start, Label end, Label handler, String type);

    public abstract void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index);

    @Override public void visitLineNumber(int line, Label start) {}

    @Override public final void visitMaxs(int maxStack, int maxLocals) {}

    public abstract void visitEnd();

    public void dispose() {
        this.localVariables         = Collections.emptyList();
        this.localVariableTypes     = Collections.emptyList();
        this.lastVariableNameSuffix = null;
    }

    /**
     * Returns the name of this label ; creates a new
     * label name if this label does not yet have one.
     *
     * @param label the label
     * @return the name of the label
     */
    protected final String getLabelName(final Label label) {
        String name = this.labelNames.get(label);

        if (name == null) {
            name = "L".concat(Integer.toString(this.labelNames.size()));
            this.labelNames.put(label, name);
        }

        return name;
    }

    private class MethodAnnotationPrinter extends AnnotationVisitor {

        public MethodAnnotationPrinter() {
            super(Opcodes.ASM4);
        }

        @Override public void visit(String name, Object value) {
            MyMethodVisitor.this.visitAnnotationDefaultValue(value);
        }

        @Override public void visitEnum(String name, String desc, String value) {
            MyMethodVisitor.this.visitAnnotationDefaultEnumValue(desc, value);
        }

        @Override public AnnotationVisitor visitAnnotation(String name, String desc) { return null; }
        @Override public AnnotationVisitor visitArray     (String name)              { return null; }
        @Override public void              visitEnd()                                {}
    }
}