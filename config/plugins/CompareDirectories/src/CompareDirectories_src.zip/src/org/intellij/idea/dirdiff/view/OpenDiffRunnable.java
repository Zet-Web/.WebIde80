/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;
import org.intellij.idea.dirdiff.util.Util;
import org.intellij.idea.dirdiff.util.Commands;
import org.intellij.idea.dirdiff.model.ClassFileTreeNode;
import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.JavaFieldTreeNode;
import org.intellij.idea.dirdiff.model.ReadableFile;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;
import org.intellij.idea.dirdiff.model.disassemble.MyClassVisitorContext;
import org.jetbrains.annotations.NotNull;

import com.intellij.openapi.diff.DiffBundle;
import com.intellij.openapi.diff.DiffManager;
import com.intellij.openapi.diff.DiffTool;
import com.intellij.openapi.diff.SimpleDiffRequest;
import com.intellij.openapi.diff.ex.DiffContentFactory;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;

/**
 *
 */
class OpenDiffRunnable implements Runnable {
    private final Project                project;
    private final ICompareDirectoryPanel panel;
    private final ComparedTreeNode[]     nodes;
    private final ReadableFile           leftFile;
    private final ReadableFile           rightFile;

    public OpenDiffRunnable(@NotNull Project                project,
                            @NotNull ICompareDirectoryPanel panel,
                            @NotNull ComparedTreeNode[]     nodes,
                            @NotNull ReadableFile           leftFile,
                            @NotNull ReadableFile           rightFile) {
        this.project   = project;
        this.panel     = panel;
        this.nodes     = nodes;
        this.leftFile  = leftFile;
        this.rightFile = rightFile;
    }

    public void run() {
        try {
            final CompareDirectoryPlugin plugin              = CompareDirectoryPlugin.getInstance(this.project);
            final MyClassVisitorContext  classVisitorContext = this.panel.getManager().getClassVisitorContext();
            final String                 leftFileExtension   = this.leftFile .getExtension();
            final String                 rightFileExtension  = this.rightFile.getExtension();
            final VirtualFile            leftVirtualFile;
            final VirtualFile            rightVirtualFile;
            final File                   leftBinaryViewFile;
            final File                   rightBinaryViewFile;
            final ClassFileTreeNode[]    classNodes          = Util.ensureArrayType(this.nodes, ClassFileTreeNode.class);
            final JavaFieldTreeNode[]    fieldNodes          = Util.ensureArrayType(this.nodes, JavaFieldTreeNode.class);

            if (classNodes != null) {
                if (ensureClassTextExists(classNodes, null, classVisitorContext)) {
                    this.panel.refreshTree(false);
                }

                leftBinaryViewFile  = Files.getComparableJavaClassFile(classNodes[0].getLeftClassDesc() .getText());
                rightBinaryViewFile = Files.getComparableJavaClassFile(classNodes[1].getRightClassDesc().getText());
                leftVirtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(leftBinaryViewFile);
                rightVirtualFile    = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(rightBinaryViewFile);
            } else if (fieldNodes != null) {
                if (ensureClassTextExists(null, fieldNodes, classVisitorContext)) {
                    this.panel.refreshTree(false);
                }

                leftBinaryViewFile  = Files.getComparableJavaClassFile(fieldNodes[0].getLeftMember() .getText());
                rightBinaryViewFile = Files.getComparableJavaClassFile(fieldNodes[1].getRightMember().getText());
                leftVirtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(leftBinaryViewFile);
                rightVirtualFile    = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(rightBinaryViewFile);
            }
            // If files are binary, create a textual view of them on disk.
            else if (this.leftFile .getFileType().equals(StdFileTypes.CLASS) &&
                     this.rightFile.getFileType().equals(StdFileTypes.CLASS)) {
                leftBinaryViewFile  = Files.getComparableJavaClassFile(Files.getJavaClassDesc(this.leftFile,  true, false, classVisitorContext).getText());
                rightBinaryViewFile = Files.getComparableJavaClassFile(Files.getJavaClassDesc(this.rightFile, true, false, classVisitorContext).getText());
                leftVirtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(leftBinaryViewFile);
                rightVirtualFile    = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(rightBinaryViewFile);

            }/* else if (this.leftFile.isBinary() || this.rightFile.isBinary()) {
                leftBinaryViewFile  = Files.getComparableBinaryFile(this.leftFile);
                rightBinaryViewFile = Files.getComparableBinaryFile(this.rightFile);
                leftVirtualFile     = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(leftBinaryViewFile);
                rightVirtualFile    = LocalFileSystem.getInstance().refreshAndFindFileByIoFile(rightBinaryViewFile);

            }*/ else {
                leftBinaryViewFile  = null;
                rightBinaryViewFile = null;
                leftVirtualFile     = this.leftFile .getVirtualFile();
                rightVirtualFile    = this.rightFile.getVirtualFile();
            }

            // If the files to be compared do not exist on disk any more, stop now.
            if (fileDoesNotExist(this.project, leftVirtualFile,  this.leftFile) ||
                fileDoesNotExist(this.project, rightVirtualFile, this.rightFile)) {
                return;
            }

            // If IDEA file type is UNKNOWN, temporarily associate extension with the PLAIN_TEXT file type
            // so that the IDEA diff window can be opened.
            if (plugin != null) {
                plugin.registerUnknownExtension(this.leftFile,  leftFileExtension);
                plugin.registerUnknownExtension(this.rightFile, rightFileExtension);
            }

            // Open the diff window
            try {
                if (!openDiffWithDiffContentFactory(this.project, this.leftFile, this.rightFile, leftVirtualFile, rightVirtualFile)) {
                    openSimpleDiff(this.project, this.leftFile, this.rightFile, leftVirtualFile, rightVirtualFile);
                }
            } catch (OutOfMemoryError e) {
                // If the IDEA diff tool raises OutOfMemoryError, then diffs are too complex to be calculated.
                Commands.showErrorDialog(this.project,
                                         CompareDirectoryBundle.message("error.open-diff.out-of-mem", this.leftFile.getPath(),
                                                                        this.rightFile.getPath()),
                                         CompareDirectoryBundle.message("error.title"));
                return;
            } finally {
                // Remove the temporary file type association
                if (plugin != null) {
                    plugin.unregisterUnknownExtension(this.leftFile,  leftFileExtension);
                    plugin.unregisterUnknownExtension(this.rightFile, rightFileExtension);
                }
            }

            // Save modified files and update related nodes.
            final Runnable updateTask = new Runnable() {
                    public void run() {
                        OpenDiffRunnable.this.panel.getManager().saveFilesAndRefreshStates(OpenDiffRunnable.this.nodes);
                        deleteBinaryViewFile(leftBinaryViewFile);
                        deleteBinaryViewFile(rightBinaryViewFile);
                    }
                };

            Commands.runWriteCommand(OpenDiffRunnable.this.project, updateTask, OpenFileRunnable.UPDATE_COMPARED_NODE,
                                     CompareDirectoryPlugin.ACTION_GROUP_ID);
        } catch (Throwable t) {
            Commands.showErrorDialog(this.project,
                                     CompareDirectoryBundle.message("error.open-diff", this.leftFile.getPath(),
                                                                    this.rightFile.getPath()),
                                     CompareDirectoryBundle.message("error.title"));
            CompareDirectoryPlugin.getLogger().error(t);
        }
    }

    private static boolean ensureClassTextExists(ClassFileTreeNode[]   classNodes,
                                                 JavaFieldTreeNode[]   fieldNodes,
                                                 MyClassVisitorContext context) {
        boolean nodeUpdated = false;

        assert ((fieldNodes == null && classNodes != null && classNodes.length == 2) ||
                (classNodes == null && fieldNodes != null && fieldNodes.length == 2));

        // If fields are passed, get their class nodes.
        final boolean oneField = (fieldNodes != null && fieldNodes[0] == fieldNodes[1]);

        if (classNodes == null) {
            if (oneField) {
                final ClassFileTreeNode classNode = fieldNodes[0].getSelfOrAncestor(ClassFileTreeNode.class);

                classNodes = new ClassFileTreeNode[] { classNode, classNode };
            } else {
                classNodes = new ClassFileTreeNode[] { fieldNodes[0].getSelfOrAncestor(ClassFileTreeNode.class),
                                                       fieldNodes[1].getSelfOrAncestor(ClassFileTreeNode.class)};
            }
        }

        // Analyze classes and retrieve their textual representation.
        for (final ClassFileTreeNode classNode : classNodes) {
            if (classNode.getLeftClassDesc()  == null || classNode.getLeftClassDesc() .getText() == null ||
                classNode.getRightClassDesc() == null || classNode.getRightClassDesc().getText() == null) {
                classNode.analyze(context, true, true);
                classNode.getModel().reapplyNodeMerging(classNode);
                nodeUpdated = true;
            }
        }

        // Fields nodes under the analyzed class nodes have changed => replace the input field nodes accordingly.
        if (fieldNodes != null) {
            if (!oneField) {
                fieldNodes[1] = findRebuiltJavaField(fieldNodes[1].getRightMember(), classNodes[1]);
            }

            fieldNodes[0] = findRebuiltJavaField(fieldNodes[0].getLeftMember(), classNodes[0]);

            if (oneField) {
                fieldNodes[1] = fieldNodes[0];
            }
        }
        return nodeUpdated;
    }

    private static JavaFieldTreeNode findRebuiltJavaField(JavaClassMemberDesc oldMember,
                                                          ClassFileTreeNode   classNode) {
        if (!oldMember.isSynthetic()) {
            return (JavaFieldTreeNode) classNode.getChildAt(classNode.memberIndexOf(oldMember));
        }

        final JavaFieldTreeNode parentNode = (oldMember.isLambda() ? classNode.getLambdaParentNode()
                                                                   : classNode.getSyntheticParentNode());

        if (parentNode == null) {
            return null;
        }

        return (JavaFieldTreeNode) parentNode.getChildAt(parentNode.memberIndexOf(oldMember));
    }

    /**
     * Returns <tt>true></tt> and shows an error dialog if this file does not exist,
     * <tt>false</tt> otherwise.
     * @param project     the current IDEA project
     * @param virtualFile the IDEA virtual file whose existence is to be checked
     * @param file        the readable file whose existence is to be checked
     * @return <tt>true></tt> if this file does not exist, <tt>false</tt> otherwise.
     */
    private static boolean fileDoesNotExist(Project project, VirtualFile virtualFile, ReadableFile file) {
        if (virtualFile == null) {
            Commands.showErrorDialog(project,
                                     CompareDirectoryBundle.message("error.diff-no-more-file", file.getPath()),
                                     CompareDirectoryBundle.message("error.title"));
            return true;
        }
        return false;
    }

    /**
     * Opens a diff window using the way IDEA 7 and below does
     * @param project          the currrent IDEA project
     * @param leftFile         the first file to be compared
     * @param rightFile        the second file to be compared
     * @param leftVirtualFile  the first file to be compared as an IDEA virtual file
     * @param rightVirtualFile the second file to be compared as an IDEA virtual file
     */
    private static void openSimpleDiff(Project      project,
                                       ReadableFile leftFile,
                                       ReadableFile rightFile,
                                       VirtualFile  leftVirtualFile,
                                       VirtualFile  rightVirtualFile) {
        final SimpleDiffRequest diffRequest = SimpleDiffRequest.compareFiles(leftVirtualFile, rightVirtualFile, project);
        final DiffTool diffTool    = DiffManager.getInstance().getIdeaDiffTool();

        diffRequest.addHint(DiffTool.HINT_SHOW_MODAL_DIALOG);
        diffRequest.setContentTitles(getFileContentTitle(leftFile),
                                     getFileContentTitle(rightFile));
        if (diffTool.canShow(diffRequest)) {
            diffTool.show(diffRequest);
        }
    }

    /**
     * This method (which allows code completion) only exists in IDEA 8, so
     * To have the code compile with IDEA 7, we call it through reflection
     */
    private static Method compareVirtualFiles;

    static {
        try {
            compareVirtualFiles = DiffContentFactory.class.getMethod("compareVirtualFiles", Project.class,
                                                                     VirtualFile.class, VirtualFile.class, String.class);
        } catch (NoSuchMethodException e) {
            compareVirtualFiles = null;
        }
    }

    /**
     * Opens a diff window using the way IDEA 8 does.
     * @param project          the currrent IDEA project
     * @param leftFile         the first file to be compared
     * @param rightFile        the second file to be compared
     * @param leftVirtualFile  the first file to be compared as an IDEA virtual file
     * @param rightVirtualFile the second file to be compared as an IDEA virtual file
     * @return <code>true</code> if the diff window could be opened,
     *    <code>false</code> otherwise.
     */
    @SuppressWarnings({"UnresolvedPropertyKey"})
    private static boolean openDiffWithDiffContentFactory(Project      project,
                                                          ReadableFile leftFile,
                                                          ReadableFile rightFile,
                                                          VirtualFile  leftVirtualFile,
                                                          VirtualFile  rightVirtualFile) {
        if (compareVirtualFiles != null) {
            final String leftFileContentTitle  = getFileContentTitle(leftFile);
            final String rightFileContentTitle = getFileContentTitle(rightFile);

            final String title = DiffBundle.message("diff.element.qualified.name.vs.element.qualified.name.dialog.title",
                                                    leftFileContentTitle, rightFileContentTitle);

            try {
                // We call compareVirtualFiles() by reflection because it only exists from IntelliJ IDEA 8.
                // and this code must compile with IDEA 7 also.
                final SimpleDiffRequest diffRequest = (SimpleDiffRequest) compareVirtualFiles.invoke(null,
                        project, leftVirtualFile, rightVirtualFile, title);

                if (diffRequest != null) {
                    diffRequest.addHint(DiffTool.HINT_SHOW_MODAL_DIALOG);
                    diffRequest.setContentTitles(leftFileContentTitle, rightFileContentTitle);
                    DiffManager.getInstance().getDiffTool().show(diffRequest);
                    return true;
                }
            } catch (IllegalAccessException e) {
                // Ignore, should never happen
            } catch (InvocationTargetException e) {
                // Ignore, should never happen
            }
        }
        return false;
    }

    /**
     * Returns the file content title to be used in a diff window
     * @param file the file whose name is to be used as window title
     * @return the title of the window showing the contents of a file
     */
    private static String getFileContentTitle(ReadableFile file) {
        final String  fileName   = file.getName();
        final String  parentPath = file.getParentPath();

        return fileName + " (" + FileUtil.toSystemDependentName(parentPath) + ')';
    }

    private static void deleteBinaryViewFile(File binaryViewFile) {
        if (binaryViewFile != null && !binaryViewFile.delete()) {
            CompareDirectoryPlugin.getLogger().warn("Unable to delete file " + binaryViewFile.getAbsolutePath());
        }
    }
}
