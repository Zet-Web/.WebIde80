/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.CompareDirectoryPlugin;

import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.openapi.actionSystem.KeyboardShortcut;
import com.intellij.openapi.actionSystem.Shortcut;
import com.intellij.ui.TableUtil;
import com.intellij.util.PlatformIcons;
import com.intellij.util.ui.ItemRemovable;

public class SettingsDialog extends JDialog {

    private static final Shortcut ADD_ACTION_KEYSTROKE    = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 0), null);
    private static final Shortcut DELETE_ACTION_KEYSTROKE = new KeyboardShortcut(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), null);

    private JComponent        contentPane;
    private AbstractButton    okButton;
    private JButton           cancelButton;
    private JTabbedPane       tabbedPane;
    private JTable            ignoredFileTable;
    private JTable            allowedDiffTable;
    private JPanel            ignoredFileToolbarPanel;
    private JPanel            allowedDiffToolbarPanel;
    private Component         tipLabel;
    private JCheckBox         diffInCommentsCheckBox;
    private final TableData   ignoredFiles;
    private final TableData   allowedDiffs;
    private final TableData[] tableData;

    public SettingsDialog(List<String> ignoredFileList, List<String> allowedDiffList, boolean diffsInCommentsAreNonSignificant) {
        this.ignoredFiles = new TableData(ignoredFileList, this.ignoredFileTable, this.ignoredFileToolbarPanel, new IgnoredFileTableListModel(ignoredFileList)) {
                public Object[] getEmptyRowData() {
                    return new Object[] { "" };
                }
        };
        this.allowedDiffs = new TableData(allowedDiffList, this.allowedDiffTable, this.allowedDiffToolbarPanel, new AllowedDiffTableListModel(allowedDiffList)) {
                public Object[] getEmptyRowData() {
                    return new Object[] { "*", Boolean.FALSE, "" };
                }
            };
        this.tableData = new TableData[] { this.ignoredFiles, this.allowedDiffs };
        this.diffInCommentsCheckBox.setSelected(diffsInCommentsAreNonSignificant);
        this.initUI();
    }

    private void initUI() {
        this.setTitle(CompareDirectoryBundle.message("settings.title"));
        this.setContentPane(this.contentPane);
        this.setModal(true);
        this.getRootPane().setDefaultButton(this.cancelButton);

        // Parametrizes the tables
        this.ignoredFileTable.getTableHeader().setDefaultRenderer(new TableCellRenderer() {
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                    return new JPanel() {
                        final Dimension size = new Dimension(0, 0);
                        @Override public Dimension getPreferredSize() {
                            return this.size;
                        }
                        @Override public Dimension getMaximumSize() {
                            return this.size;
                        }
                    };
                }
            });

        this.okButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SettingsDialog.this.applyChanges();
                    SettingsDialog.this.onClose();
                }
            });

        // call onClose() when cross is clicked
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    SettingsDialog.this.onClose();
                }
            });

        // call onClose() on ESCAPE or when "Cancel" is clicked
        final ActionListener closeActionListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SettingsDialog.this.onClose();
                }
            };

        this.cancelButton.addActionListener    (closeActionListener);
        this.contentPane.registerKeyboardAction(closeActionListener,
                                                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                                                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        // call onAdd() on INSERT
        this.contentPane.registerKeyboardAction(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SettingsDialog.this.tableData[SettingsDialog.this.tabbedPane.getSelectedIndex()].onAdd();
                }
            },
                KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 0),
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        // call onRemove() on DELETE
        this.contentPane.registerKeyboardAction(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SettingsDialog.this.tableData[SettingsDialog.this.tabbedPane.getSelectedIndex()].onRemove();
                }
            },
                KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0),
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }


    /**
     * Returns the changed ignored file list. As long as it has not changed
     * and the user has clicked on the OK button, the returned list is the very
     * same List instance as the one used to initialise {@link #ignoredFiles}.
     * @return the changed ignored file list
     */
    public List<String> getIgnoredFileList() {
        return this.ignoredFiles.getList();
    }

    /**
     * Returns the changed allowed diff list. As long as it has not changed
     * and the user has clicked on the OK button, the returned list is the very
     * same List instance as the one used to initialise {@link #allowedDiffs}.
     * @return the changed allowed diff list
     */
    public List<String> getAllowedDiffList() {
        return this.allowedDiffs.getList();
    }

    public boolean areDiffsInCommentsNonSignificant() {
        return this.diffInCommentsCheckBox.isSelected();
    }

    private void onClose() {
        this.dispose();
    }

    private void applyChanges() {
        this.ignoredFiles.applyChanges();
        this.allowedDiffs.applyChanges();
    }

    private abstract class TableData {
        protected final JPanel        toolbarPanel;
        protected final JTable        table;
        protected final MyTableModel  tableModel;
        protected SimpleToolbarButton addButton;
        protected SimpleToolbarButton editButton;
        protected SimpleToolbarButton deleteButton;
        protected SimpleToolbarButton duplicateButton;
        protected List<String>        list;

        protected TableData(List<String> list, JTable table, JPanel toolbarPanel, MyTableModel tableModel) {
            this.list         = list;
            this.table        = table;
            this.toolbarPanel = toolbarPanel;
            this.tableModel   = tableModel;
            this.table.setModel(this.tableModel);

            this.initUI();
        }

        protected abstract Object[] getEmptyRowData();

        public void initUI() {
            this.table.setCellEditor(new DefaultCellEditor(new JTextField()));
            this.table.setColumnSelectionAllowed(false);
            this.table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            this.toolbarPanel.add(this.createToolbar());
            this.addButton.setEnabled(true);

            this.table.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent event) {
                        if (event.getClickCount() == 2 && event.getButton() == MouseEvent.BUTTON1) {
                            TableData.this.onEdit();
                        }
                    }
                });
            this.table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                    public void valueChanged(ListSelectionEvent e) {
                        TableData.this.onListLineSelect();
                    }
                });
        }

        public final void onAdd(){
            final int rowIndex = this.tableModel.getRowCount();

            this.tableModel.addRow(this.getEmptyRowData());
            this.table.getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
            this.onEdit();
            this.table.getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
        }

        public final void onEdit() {
            final int selectedIndex = this.table.getSelectionModel().getMinSelectionIndex();

            if (selectedIndex >= 0) {
                this.table.editCellAt(selectedIndex, this.tableModel.getFirstStringCellIndex());
            } else {
                this.onAdd();
            }
            SettingsDialog.this.tipLabel.setVisible(true);
        }

        public void onDuplicate() {
            final int maxIndex = this.table.getSelectionModel().getMaxSelectionIndex();

            for (int index = this.table.getSelectionModel().getMinSelectionIndex(); index <= maxIndex; index++) {
                this.tableModel.addRow((Vector) ((Vector) this.tableModel.getDataVector().get(index)).clone());
            }
            SettingsDialog.this.tipLabel.setVisible(true);
        }

        public final void onRemove() {
            int selectedIndex = this.table.getSelectionModel().getMinSelectionIndex();

            TableUtil.removeSelectedItems(this.table);
            selectedIndex = Math.min(selectedIndex, this.tableModel.getRowCount() - 1);
            if (selectedIndex >= 0) {
                this.table.getSelectionModel().setSelectionInterval(selectedIndex, selectedIndex);
            }
            SettingsDialog.this.tipLabel.setVisible(true);
        }

        public final void onListLineSelect() {
            final ListSelectionModel selectionModel = this.table.getSelectionModel();
            final int                minSelectedRow = selectionModel.getMinSelectionIndex();
            final int                maxSelectedRow = selectionModel.getMaxSelectionIndex();
            final boolean            removable      = (minSelectedRow >= 0);
            final boolean            editable       = (removable && minSelectedRow == maxSelectedRow);

            this.deleteButton   .setEnabled(removable);
            this.duplicateButton.setEnabled(removable);
            this.editButton     .setEnabled(editable);
        }

        /**
         * Returns the string list. As long as it has not changed and the
         * user has clicked on the OK button, the returned list is the very
         * same List instance as the one used to initialize the list.
         * @return the string list
         */
        public final List<String> getList() {
            return this.list;
        }

        protected Component createToolbar() {
            final DefaultActionGroup actionGroup = new DefaultActionGroup(CompareDirectoryPlugin.ACTION_GROUP_ID, false);

            this.addButton       = new SimpleToolbarButton(this.toolbarPanel, "button.add",       PlatformIcons.ADD_ICON,    ADD_ACTION_KEYSTROKE) {
                    public void actionPerformed(AnActionEvent e) {
                        TableData.this.onAdd();
                    }
                };
            this.deleteButton    = new SimpleToolbarButton(this.toolbarPanel, "button.delete",    PlatformIcons.DELETE_ICON, DELETE_ACTION_KEYSTROKE) {
                    public void actionPerformed(AnActionEvent e) {
                        TableData.this.onRemove();
                    }
                };
            this.duplicateButton = new SimpleToolbarButton(this.toolbarPanel, "button.duplicate", PlatformIcons.COPY_ICON) {
                    public void actionPerformed(AnActionEvent e) {
                        TableData.this.onDuplicate();
                    }
                };
            this.editButton      = new SimpleToolbarButton(this.toolbarPanel, "button.edit",      PlatformIcons.EDIT_IN_SECTION_ICON) {
                    public void actionPerformed(AnActionEvent e) {
                        TableData.this.onEdit();
                    }
                };

            actionGroup.add(this.addButton);
            actionGroup.add(this.deleteButton);
            actionGroup.add(this.duplicateButton);
            actionGroup.add(this.editButton);

            final ActionManager actionManager = ActionManager.getInstance();

            return actionManager.createActionToolbar(CompareDirectoryPlugin.ACTION_TOOLBAR_ID, actionGroup, true).getComponent();
        }

        public void applyChanges() {
            final List<String> newList = getModifiedMasks(this.tableModel);

            if (!listEqual(this.list, newList)) {
                this.list = newList;
            }
        }
    }

    private static List<String> getModifiedMasks(TableModel tableModel) {
        final int          numRows    = tableModel.getRowCount();
        final int          numColumns = tableModel.getColumnCount();
        final List<String> masks      = new ArrayList<String>(numRows * numColumns);

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numColumns; col++) {
                final Object rawValue = tableModel.getValueAt(row, col);
                final String value    = (rawValue instanceof Boolean) ? (((Boolean) rawValue) ? "R" : "S")
                                                                      : (String) rawValue;

                if (value != null && value.length() != 0) {
                    masks.add(value);
                }
            }
        }
        return masks;
    }

    /**
     * Checks the equality between two lists by sorting them.
     * Argument lists are kept unchanged (sort is performed on copies).
     * @param list1 the first  list to be compared
     * @param list2 the second list to be compared
     * @return <code>true</code> if lists are equal,
     *         <code>false</code> otherwise.
     */
    private static <T extends Comparable<? super T>> boolean listEqual(List<T> list1, List<T> list2) {
        if (list1 == list2) {
            return true;
        }
        if (list1 == null || list2 == null || list1.size() != list2.size()) {
            return false;
        }

        final List<T> sortedList1 = new ArrayList<T>(list1);
        final List<T> sortedList2 = new ArrayList<T>(list2);

        Collections.sort(sortedList1);
        Collections.sort(sortedList2);

        final Iterator<T> iterator1 = sortedList1.iterator();
        final Iterator<T> iterator2 = sortedList2.iterator();

        while (iterator1.hasNext()) {
            if (!iterator1.next().equals(iterator2.next())) {
                return false;
            }
        }

        return true;
    }

    private abstract static class MyTableModel extends DefaultTableModel implements ItemRemovable {
        public MyTableModel(String[] columnNames, int rowCount) {
            super(columnNames, rowCount);
        }

        public abstract int getFirstStringCellIndex();
    }

    private static class IgnoredFileTableListModel extends MyTableModel {
        public IgnoredFileTableListModel(List<?> values) {
            super(new String[] { "" }, values.size());

            for (int index = 0; index < values.size(); index++) {
                this.setValueAt(values.get(index), index, 0);
            }
        }

        public int getFirstStringCellIndex() {
            return 0;
        }
    }

    private static class AllowedDiffTableListModel extends MyTableModel {
        public AllowedDiffTableListModel(List<?> values) {
            super(getColumnNames(), values.size() / 3);

            final int rowCount    = this.getRowCount();
            final int columnCount = this.getColumnCount();

            for (int row = 0; row < rowCount; row++) {
                for (int column = 0; column < columnCount; column++) {
                    Object value = values.get(columnCount * row + column);

                    if (column == 1) {
                        value = ("R".equals(value));
                    }
                    this.setValueAt(value, row, column);
                }
            }
        }

        /** {@inheritDoc} */
        @Override public Class<?> getColumnClass(int columnIndex) {
            return (columnIndex == 1) ? Boolean.class : String.class;
        }

        public int getFirstStringCellIndex() {
            return 1;
        }

        private static String[] getColumnNames() {
            return new String[] { CompareDirectoryBundle.message("allowed-diffs.file-pattern.title"),
                                  CompareDirectoryBundle.message("allowed-diffs.regexp.title"),
                                  CompareDirectoryBundle.message("allowed-diffs.text-pattern.title") };
        }
    }
}