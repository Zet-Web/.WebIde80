/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.jetbrains.annotations.NonNls;

import com.intellij.openapi.actionSystem.ActionGroup;
import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.ActionPlaces;
import com.intellij.openapi.actionSystem.ActionToolbar;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.actionSystem.ex.CustomComponentAction;
import com.intellij.openapi.actionSystem.impl.ActionButton;
import com.intellij.openapi.actionSystem.impl.ActionToolbarImpl;
import com.intellij.openapi.ui.popup.ComponentPopupBuilder;
import com.intellij.openapi.ui.popup.JBPopupFactory;
import com.intellij.openapi.ui.popup.MouseChecker;
import com.intellij.ui.awt.RelativePoint;
import com.intellij.ui.awt.RelativeRectangle;

/**
 * This class allows a group of IDEA actions to be displayed as a button and an pop-up toolbar.
 * when the user clicks on this action
 */
@SuppressWarnings({"ComponentNotRegistered"})
public class PopupToolbarActionGroup extends AnAction implements CustomComponentAction {

    private final ActionToolbarImpl  actionToolbar;
    private JComponent               actionButton;

    /**
     * Creates an action group shown as a pop-up toolbar
     * @param actionKey   the property key used to get the text, title and icon of the
     * @param actionGroup the group of actions to be shown in the pop-up toolbar
     * @param horizontal  the orientation of the toolbar (true - horizontal, false - vertical)
     * @return An instance of <code>ActionToolbar</code>
     */
    public PopupToolbarActionGroup(@NonNls final String actionKey, ActionGroup actionGroup, boolean horizontal) {
        super(CompareDirectoryBundle.message("title." + actionKey),
              CompareDirectoryBundle.message("text."  + actionKey),
              IconUtil.createIconWithKey    ("icon."  + actionKey));

        this.actionToolbar = (ActionToolbarImpl) ActionManager.getInstance().createActionToolbar(ActionPlaces.UNKNOWN, actionGroup, horizontal);
    }

    /**
     * Creates the custom component that represents this popup toolbar.
     * @return the custom component that represents this popup toolbar.
     */
    public JComponent createCustomComponent(Presentation presentation) {
        if (this.actionButton == null) {
            this.actionButton = new PopupActionButton(presentation);
        }
        return this.actionButton;
    }

    public void actionPerformed(AnActionEvent event) {
        // Nothing to do
    }

    /**
     * Shows the popup toolbar.
     * @param popupToolbar the toolbar
     */
    private void createPopupComponent(final ActionToolbarImpl popupToolbar) {
        popupToolbar.setLayoutPolicy(ActionToolbar.NOWRAP_LAYOUT_POLICY);

        final ComponentPopupBuilder builder = JBPopupFactory.getInstance().createComponentPopupBuilder(popupToolbar, null);

        builder.setResizable(false)
               .setRequestFocus(false)
               .setTitle(null)
               .setCancelKeyEnabled(true)
               .setCancelOnClickOutside(true)
               .setCancelOnOtherWindowOpen(true)
               .setCancelOnMouseOutCallback(new MouseChecker() {
                        public boolean check(MouseEvent event) {
                            final RelativePoint eventPoint         = new RelativePoint(event);
                            final Rectangle     toolbarBounds      = getEnlargedBounds(popupToolbar,                              50, 50);
                            final Rectangle     actionButtonBounds = getEnlargedBounds(PopupToolbarActionGroup.this.actionButton, 50, 50);

                            return !((new RelativeRectangle(popupToolbar, toolbarBounds))     .contains(eventPoint) ||
                                     (new RelativeRectangle(popupToolbar, actionButtonBounds)).contains(eventPoint));
                        }
                    });

        builder.createPopup()
               .showUnderneathOf(this.actionButton);
    }

    /**
     * Handles the left-button click on the pop-up button
     */
    private void processMouseButton1Click() {
        if (this.actionButton != null) {
            this.createPopupComponent(this.actionToolbar);
            this.actionToolbar.updateActionsImmediately();
        }
    }

    /**
     * Creates a enlarged rectangle encompassing this component
     * @param component the component
     * @param deltaX    the enlargement on the X-axis
     * @param deltaY    the enlargement on the Y-axis
     * @return the enlarged rectangle
     */
    private static Rectangle getEnlargedBounds(Component component, int deltaX, int deltaY) {
        final Rectangle bounds = component.getBounds();

        return new Rectangle(bounds.x     -     deltaX, bounds.y      -     deltaY,
                             bounds.width + 2 * deltaX, bounds.height + 2 * deltaY);
    }

    /**
     * The pop-up button class.
     */
    private class PopupActionButton extends ActionButton {
        public PopupActionButton(Presentation presentation) {
            super(PopupToolbarActionGroup.this, presentation, ActionPlaces.UNKNOWN, new Dimension(24, 24));
            this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        }

        protected void processMouseEvent(MouseEvent event) {
            super.processMouseEvent(event);
            if (event.getButton() == MouseEvent.BUTTON1) {
                PopupToolbarActionGroup.this.processMouseButton1Click();
            }
        }
    }
}
