/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.util.TooManyListenersException;

import javax.swing.JComponent;
import javax.swing.event.ChangeListener;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import com.intellij.ide.ExporterToTextFile;
import com.intellij.util.SystemProperties;

/**
 */
public class TextFileExporter implements ExporterToTextFile {
    @NonNls private static final String INDENT_ELEMENT = "    ";

    private final CompareDirectoryPanel panel;

    public TextFileExporter(CompareDirectoryPanel panel) {
        this.panel = panel;
    }

    public JComponent getSettingsEditor() {
        return null;
    }

    public void addSettingsChangedListener(ChangeListener listener) throws TooManyListenersException {}
    public void removeSettingsChangedListener(ChangeListener listener) {}

    public String getReportText() {
        final ComparedTreeNode root   = this.panel.getTreeModel().getRoot();
        final StringBuilder    buffer = new StringBuilder();

        this.appendNode(buffer, root, SystemProperties.getLineSeparator(), 0);
        return buffer.toString();
    }

    private void appendNode(StringBuilder buffer, @NotNull ComparedTreeNode node, String lineSeparator, int indentLevel) {
        for (int index = indentLevel; --index >= 0; ) {
            buffer.append(INDENT_ELEMENT);
        }
        buffer.append(node.getState().getSymbol())
              .append(' ')
              .append(node)
              .append(lineSeparator);

        for (ComparedTreeNode childNode : node.getFilteredChildren()) {
            this.appendNode(buffer, childNode, lineSeparator, indentLevel + 1);
        }
    }

    public String getDefaultFilePath() {
        return this.panel.getView().getLastConfiguration().getExportFileName();
    }

    public void exportedTo(String filePath) {
        this.panel.getView().getLastConfiguration().setExportFileName(filePath);
    }

    public boolean canExport() {
        return (this.panel.isComparisonOver() && this.panel.getTreeModel().getRoot() != null);
    }
}
