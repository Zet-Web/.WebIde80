/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.util;

public final class Printer {

    public static final String INDENT = "    ";
    public static final String SPACE  = " ";
    public static final String CR     = "\n";

    private final StringBuilder buffer;
    private int                 indentLevel;

    public Printer(StringBuilder buffer) {
        this.buffer = buffer;
    }

    public Printer(Printer printer, int indentLevel) {
        this.buffer      = printer.buffer;
        this.indentLevel = indentLevel;
    }

    public int getIndentLevel() {
        return this.indentLevel;
    }

    public Printer indent() {
        this.indentLevel++;
        return this;
    }

    public Printer unindent() {
        this.indentLevel--;
        return this;
    }

    public int length() {
        return this.buffer.length();
    }

    public char charAt(int index) {
        return this.buffer.charAt(index);
    }

    public String substring(int start) {
        return this.buffer.substring(start);
    }

    public String substring(int start, int end) {
        return this.buffer.substring(start, end);
    }

    public int indexOf(int index, char c) {
        final int size = this.buffer.length();
        while (index < size) {
            if (this.buffer.charAt(index) == c) {
                return index;
            }
            index++;
        }
        return -1;
    }

    public int indexOf(String s) {
        return this.buffer.indexOf(s);
    }

    public int lastIndexOf(int index, char c) {
        while (--index >= 0 && this.buffer.charAt(index) != c) {}
        return index;
    }

    public int lastIndexOf(char c) {
        return this.lastIndexOf(this.buffer.length(), c);
    }

    public int lastIndexOf(String str) {
        return this.buffer.lastIndexOf(str);
    }

    public int lastIndexOf(String str, int fromIndex) {
        return this.buffer.lastIndexOf(str, fromIndex);
    }

    public boolean startsWith(CharSequence arg) {
        return this.startsWith(0, arg);
    }

    public boolean startsWith(int index, CharSequence arg) {
        return this.buffer.substring(index, index + arg.length()).contentEquals(arg);
    }

    public boolean endsWith(CharSequence arg) {
        return this.endsWith(this.buffer.length(), arg);
    }

    public boolean endsWith(int endIndex, CharSequence arg) {
        final int startIndex = endIndex - arg.length();
        return (startIndex >= 0 &&
                this.buffer.substring(startIndex, endIndex).contentEquals(arg));
    }

    public Printer append(char arg) {
        this.buffer.append(arg);
        return this;
    }

    public Printer append(CharSequence arg) {
        this.buffer.append(arg);
        return this;
    }

    public Printer appendRepeatedly(int count, CharSequence arg) {
        for (int index = count; --index >= 0; ) {
            this.buffer.append(arg);
        }
        return this;
    }

    public Printer appendIndentedRepeatedly(int count, CharSequence arg) {
        this.appendIndentation();
        return this.appendIndentedRepeatedly(count, arg);
    }

    public Printer append(CharSequence... args) {
        for (CharSequence arg : args) {
            this.buffer.append(arg);
        }
        return this;
    }

    public Printer appendIndented(char arg) {
        this.appendIndentation();
        this.buffer.append(arg);
        return this;
    }

    public Printer appendIndented(CharSequence arg) {
        this.appendIndentation();
        this.buffer.append(arg);
        return this;
    }

    public Printer appendIndented(CharSequence... args) {
        this.appendIndentation();
        for (CharSequence arg : args) {
            this.buffer.append(arg);
        }
        return this;
    }

    private void appendIndentation() {
        for (int index = this.indentLevel; --index >= 0; ) {
            this.buffer.append(INDENT);
        }
    }

    public Printer insert(int index, CharSequence arg) {
        this.buffer.insert(index, arg);
        return this;
    }

    public Printer insert(int index, CharSequence... args) {
        for (int i = args.length; --i >= 0; ) {
            this.buffer.insert(index, args[i]);
        }
        return this;
    }

    public Printer insertIndented(int index, CharSequence... args) {
        this.insert(index, args);
        for (int i = this.indentLevel; --i >= 0; ) {
            this.buffer.insert(index, INDENT);
        }
        return this;
    }

    public Printer delete(int start, int end) {
        this.buffer.delete(start, end);
        return this;
    }

    public Printer truncate(int newLength) {
        this.buffer.setLength(newLength);
        return this;
    }

    public Printer replace(int start, int end, String str) {
        this.buffer.replace(start, end, str);
        return this;
    }

    @Override public String toString() {
        return this.buffer.toString();
    }
}
