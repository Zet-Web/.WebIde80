/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import java.io.IOException;

import org.jetbrains.asm4.ClassReader;

public class AsmTest {
    public static void main(String[] args) throws Exception {
        final String[] classNames = { "java.lang.Runnable",
                                      "org.intellij.idea.dirdiff.CompareDirectoryBundle",
                                      "org.intellij.idea.dirdiff.model.FileStateEnum",
                                      "org.intellij.idea.dirdiff.model.disassemble.BytecodeMethodVisitor",
                                      "org.intellij.idea.dirdiff.CompareDirectoryPlugin",
                                      "org.intellij.idea.dirdiff.model.disassemble.AsmUtil",
                                      "org.jetbrains.annotations.NotNull",
                                      "java.lang.String",
                                      "org.intellij.idea.dirdiff.model.DescendentNodeIterator",
                                      "org.intellij.idea.dirdiff.model.ComparedTreeNode" };

        test (new MyClassVisitorContext(), classNames, false, true);
        bench(new MyClassVisitorContext(), classNames, true);
        bench(new MyClassVisitorContext(), classNames, false);
        bench(new MyClassVisitorContext(), classNames, true);
        bench(new MyClassVisitorContext(), classNames, false);
    }

    private static void test(MyClassVisitorContext context, String[] classNames, boolean simple, boolean printText) {
        for (String className : classNames) {
            final MyClassVisitor cp = (simple ? new SimpleClassVisitor(context, true)
                                              : new FullClassVisitor(context, false));

            try {
                new ClassReader(className).accept(cp, 0);
            } catch (IOException e) {
                System.out.println("Cannot read class " + className);
            } finally {
                if (printText) {
                    System.out.println(cp.getClassDesc().getText());
                }
            }
        }
    }

    private static void bench(MyClassVisitorContext context, String[] classNames, boolean simple) {
        final long debut = System.nanoTime();
        for (int i = 0; i < 20; i++) {
            System.out.print((i % 10) == 9 ? "+" : "."); System.out.flush();

            test(context, classNames, simple, false);
        }
        final long duree = (System.nanoTime() - debut) / 1000L;
        System.out.println("\nElapsed time: " + duree + " �s");
        System.out.println("Average time: " + (duree / 20) + " �s");
    }
}
