/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import org.jetbrains.annotations.NotNull;

/**
 * The <code>CompoundIcon</code> paints two or more {@link Icon}s as a single {@link Icon}.
 * {@link Icon}s are painted in the order in which they are added.
 * <p/>
 * {@link Icon}s are layed out on the specified axis:
 * <ul>
 * <li>X-Axis (horizontally)
 * <li>Y-Axis (vertically)
 * <li>Z-Axis (stacked)
 * </ul>
 */
public class CompoundIcon implements Icon {
    public enum Axis { X_AXIS, Y_AXIS, Z_AXIS }

    public static final float LEFT   = 0f;
    public static final float CENTER = 0.5f;
    public static final float RIGHT  = 1f;

    public static final float TOP    = 0f;
    public static final float MIDDLE = 0.5f;
    public static final float BOTTOM = 1f;

    private final Icon[] icons;
    private final Axis   axis;
    private final int    gap;
    private final float  alignmentX;
    private final float  alignmentY;

    /**
     * Creates a compound icon with icons layed out on the X-AXIS,
     * the gap set to 0 and the X/Y alignments default to CENTER/MIDDLE.
     *
     * @param icons the icons to be painted as part of the compound icon
     */
    public CompoundIcon(Icon... icons) {
        this(Axis.X_AXIS, icons);
    }

    /**
     * Creates a compound icon with a gap set to 0 and the
     * X/Y alignments default to CENTER/MIDDLE.
     *
     * @param axis   the axis used to lay out the icons for painting.
     * @param icons  the icons to be painted as part of the compound icon
     */
    public CompoundIcon(Axis axis, Icon... icons) {
        this(axis, 0, icons);
    }

    /**
     * Creates a compound icon with the X/Y alignments default to CENTER/MIDDLE.
     *
     * @param axis   the axis used to lay out the icons for painting
     * @param gap    the gap between the icons
     * @param icons  the icons to be painted as part of the compound icon
     */
    public CompoundIcon(Axis axis, int gap, Icon... icons) {
        this(axis, gap, CENTER, MIDDLE, icons);
    }

    /**
     * Creates a compound icon with this axis, gap and icons.
     *
     * @param axis        the axis used to lay out the icons for painting
     * @param gap         the gap between the icons
     * @param alignmentX  the X-alignment of the icons. Common values are
     *                    LEFT, CENTER, RIGHT. Can be any value between 0.0 and 1.0
     * @param alignmentY  the Y-alignment of the icons. Common values are
     *                    TOP, MIDDLE, BOTTOM. Can be any value between 0.0 and 1.0
     * @param icons       the icons to be painted as part of the compound icon
     */
    public CompoundIcon(@NotNull Axis axis, int gap, float alignmentX, float alignmentY, Icon... icons) {
        this.axis       = axis;
        this.gap        = gap;
        this.alignmentX = (alignmentX > 1.0f ? 1.0f :
                           alignmentX < 0.0f ? 0.0f
                                             : alignmentX);
        this.alignmentY = (alignmentY > 1.0f ? 1.0f :
                           alignmentY < 0.0f ? 0.0f
                                             : alignmentY);

        for (int index = 0; index < icons.length; index++) {
            if (icons[index] == null) {
                throw new IllegalArgumentException("Icon [" + index + "] cannot be null");
            }
        }

        this.icons = icons;
    }

    /**
     * Returns the direction along which every icon is painted.
     *
     * @return the direction along which every icon is painted.
     */
    public Axis getAxis() {
        return this.axis;
    }

    /**
     * Returns the gap between two icons
     *
     * @return the gap, in pixels
     */
    public int getGap() {
        return this.gap;
    }

    /**
     * Returns the alignment of the icon on the X-axis
     *
     * @return the X-alignment of the icon
     */
    public float getAlignmentX() {
        return this.alignmentX;
    }

    /**
     * Returns the alignment of the icon on the Y-axis
     *
     * @return the Y-alignment of the icon
     */
    public float getAlignmentY() {
        return this.alignmentY;
    }

    /**
     * Returns the number of icons contained in this compound icon.
     *
     * @return the number of icons in this compound icon.
     */
    public int getIconCount() {
        return this.icons.length;
    }

    /**
     * Returns the icon at this index.
     *
     * @param index  the index of the icon to be returned
     * @return  the icon at this index
     * @exception IndexOutOfBoundsException  if the index is out of range
     */
    public Icon getIcon(int index) {
        return this.icons[index];
    }

    /**
     * Returns the width of this icon.
     *
     * @return the width of the icon in pixels.
     */
    public int getIconWidth() {
        int width = 0;

        // Adds the width of every icon with the gap between them
        if (this.axis == Axis.X_AXIS) {
            width += (this.icons.length - 1) * this.gap;

            for (Icon icon : this.icons) {
                width += icon.getIconWidth();
            }
        } else {
            // Computes the maximum width
            for (Icon icon : this.icons) {
                width = Math.max(width, icon.getIconWidth());
            }
        }

        return width;
    }

    /**
     * Returns the height of this icon.
     *
     * @return the height of the icon in pixels.
     */
    public int getIconHeight() {
        int height = 0;

        // Adds the height of every icon with the gap between them
        if (this.axis == Axis.Y_AXIS) {
            height += (this.icons.length - 1) * this.gap;

            for (Icon icon : this.icons) {
                height += icon.getIconHeight();
            }
        } else {
            // Computes the maximum height
            for (Icon icon : this.icons) {
                height = Math.max(height, icon.getIconHeight());
            }
        }

        return height;
    }

   /**
    * Paints the icons of this compound icon at this location
    *
    * @param c The component on which the icon is painted
    * @param g the graphics context
    * @param x the X-coordinate of the icon top-left corner
    * @param y the Y-coordinate of the icon top-left corner
    */
    public void paintIcon(Component c, Graphics g, int x, int y) {
       switch (axis) {
           case X_AXIS: {
               final int height = this.getIconHeight();

               for (Icon icon : this.icons) {
                   final int iconY = this.getOffset(height, icon.getIconHeight(), this.alignmentY);

                   icon.paintIcon(c, g, x, y + iconY);
                   x += icon.getIconWidth() + this.gap;
               }
               break;
           }

           case Y_AXIS: {
               final int width = this.getIconWidth();

               for (Icon icon : this.icons) {
                   final int iconX = this.getOffset(width, icon.getIconWidth(), this.alignmentX);

                   icon.paintIcon(c, g, x + iconX, y);
                   y += icon.getIconHeight() + this.gap;
               }
               break;
           }

           case Z_AXIS: {
               final int width  = this.getIconWidth();
               final int height = this.getIconHeight();

               for (Icon icon : icons) {
                   final int iconX = this.getOffset(width,  icon.getIconWidth(),  this.alignmentX);
                   final int iconY = this.getOffset(height, icon.getIconHeight(), this.alignmentY);

                   icon.paintIcon(c, g, x + iconX, y + iconY);
               }
           }
       }
    }

    /**
     * Returns the offset to be used when painting the icon to achieve the proper alignment.
     * Note: When the icon value is smaller than the maximum value of all icons the
     * icon needs to be aligned appropriately.
     * @return the appropriate offset
     */
    private int getOffset(int maxValue, int iconValue, float alignment) {
        return Math.round((maxValue - iconValue) * alignment);
    }
}
