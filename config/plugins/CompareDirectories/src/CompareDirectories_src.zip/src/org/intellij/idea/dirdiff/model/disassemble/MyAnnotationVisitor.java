/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.disassemble;

import org.intellij.idea.dirdiff.util.Printer;
import org.jetbrains.asm4.AnnotationVisitor;
import org.jetbrains.asm4.Opcodes;
import org.jetbrains.asm4.Type;

/**
 * Parses an annotation and transforms it in to its source code.
 */
class MyAnnotationVisitor extends AnnotationVisitor {
    private final Printer          printer;
    private final FullClassVisitor classVisitor;
    private final Printer          parentPrinter;
    private       int              numParameters;
    private final int              parentPrinterInsertionIndex;

    public MyAnnotationVisitor(String desc, FullClassVisitor classVisitor, boolean classAnnotation) {
        this(desc, classVisitor, null, classAnnotation, -1);
    }

    public MyAnnotationVisitor(String           desc,
                               FullClassVisitor classVisitor,
                               Printer          parentPrinter,
                               boolean          classAnnotation,
                               int              parentPrinterInsertionIndex) {
        super(Opcodes.ASM4);
        this.printer       = new Printer(new StringBuilder());
        this.classVisitor  = classVisitor;
        this.parentPrinter = parentPrinter;
        this.parentPrinterInsertionIndex = parentPrinterInsertionIndex;
        if (desc != null) {
            this.printer.append((classAnnotation ? Printer.CR : ""),
                                "@", classVisitor.ensureClassImported(Type.getType(desc)));
        }
    }

    @Override public void visit(String name, Object value) {
        this.printer.append(((this.numParameters == 0) ? "(" : ", "),
                            name,
                            "=",
                            ((value == null) ? "" : this.classVisitor.getLiteral(value)));
        this.numParameters++;
    }

    @Override public void visitEnum(String name, String desc, String value) {
        final String qualifiedClassName = AsmUtil.getQualified(desc.substring(1, desc.length() - 1));

        this.printer.append(((this.numParameters == 0) ? "(" : ", "),
                            name,
                            "=",
                            this.classVisitor.ensureClassImported(qualifiedClassName),
                            ".",
                            value);
        this.numParameters++;
    }

    @Override public AnnotationVisitor visitAnnotation(String name, String desc) {
        return this;
    }

    @Override public AnnotationVisitor visitArray(String name) {
        this.visit(name, null);
        this.printer.append("{");
        return this.new ArrayAnnotationVisitor();
    }

    @Override public void visitEnd() {
        if (this.numParameters > 0) {
            this.printer.append(')');
        }
        this.printer.append(Printer.SPACE);

        if (this.numParameters == 1) {
            // Java spec says that in this case, the annotation parameter is named "value"
            // and its name can be omitted
            final int index = this.printer.indexOf("value=");
            if (index >= 0) {
                this.printer.delete(index, index + "value=".length());
            }
        }

        if (this.parentPrinter == null) {
            final int index = this.classVisitor.getPrinter().lastIndexOf('\n');
            this.classVisitor.getPrinter().insert(this.classVisitor.getPrinter().lastIndexOf(index, '\n'), this.printer.toString());
        } else if (this.parentPrinterInsertionIndex >= 0) {
            this.parentPrinter.insert(this.parentPrinterInsertionIndex, this.printer.toString());
        } else {
            this.parentPrinter.append(this.printer.toString());
        }
    }

    private class ArrayAnnotationVisitor extends AnnotationVisitor {
        private int numParameters;

        public ArrayAnnotationVisitor() {
            super(Opcodes.ASM4);
        }

        @Override public void visit(String name, Object value) {
            MyAnnotationVisitor.this.printer.append(((this.numParameters == 0) ? "" : ", "),
                                                    (value == null) ? "" : MyAnnotationVisitor.this.classVisitor.getLiteral(value));
            this.numParameters++;
        }

        @Override public void visitEnum(String name, String desc, String value) {
            final String qualifiedClassName = AsmUtil.getQualified(desc.substring(1, desc.length() - 1));

            MyAnnotationVisitor.this.printer.append((this.numParameters == 0) ? "" : ", ",
                                                    MyAnnotationVisitor.this.classVisitor.ensureClassImported(qualifiedClassName),
                                                    ".",
                                                    value);
            this.numParameters++;
        }

        @Override public AnnotationVisitor visitAnnotation(String name, String desc) {
            return new MyAnnotationVisitor(desc, MyAnnotationVisitor.this.classVisitor, MyAnnotationVisitor.this.printer, false, -1);
        }

        @Override public AnnotationVisitor visitArray(String name) {
            return MyAnnotationVisitor.this.new ArrayAnnotationVisitor();
        }

        @Override public void visitEnd() {
            MyAnnotationVisitor.this.printer.append('}');
        }
    }
}
