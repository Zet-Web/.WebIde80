/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model.fs;

/* Please add the ant.jar file to the IDEA JDK configuration to have every class properly imported. */

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.intellij.idea.dirdiff.CompareDirectoryPlugin;

/**
 * This class represents an archive file (ZIP, JAR, EAR, WAR, ...) to be compared.
 * Note that this class relies on classes defined in the ANT library files,
 * which should be added to the IDEA JDK configuration.
 */
public class ZipFile implements AbstractArchiveFile<ZipEntry> {
    private org.apache.tools.zip.ZipFile zipFile;

    public ZipFile(File file) throws IOException {
        this.zipFile = new org.apache.tools.zip.ZipFile(file);
    }

    public Iterable<ZipEntry> getEntries() {
        return new Iterable<ZipEntry>() {
                public Iterator<ZipEntry> iterator() {
                    return new ZipEntryIterator(ZipFile.this.zipFile, ZipFile.this.zipFile.getEntries());
                }
            };
    }

    public ZipEntry getEntry(String name) {
        return new ZipEntry(this.zipFile, this.zipFile.getEntry(name));
    }

    public InputStream getInputStream(ZipEntry zipEntry) throws IOException {
        return zipEntry.getInputStream();
    }

    public void close() throws IOException {
        if (this.zipFile != null) {
            this.zipFile.close();
        }
    }

    public void finalizeIt() {
        try {
            this.close();
        } catch (Exception e) {
            CompareDirectoryPlugin.getLogger().error(e);
        }
        this.zipFile = null;
    }

    private static class ZipEntryIterator implements Iterator<ZipEntry> {
        private final org.apache.tools.zip.ZipFile               zipFile;
        private final Enumeration<org.apache.tools.zip.ZipEntry> enumeration;

        public ZipEntryIterator(org.apache.tools.zip.ZipFile               zipFile,
                                Enumeration<org.apache.tools.zip.ZipEntry> enumeration) {
            this.zipFile     = zipFile;
            this.enumeration = enumeration;
        }

        public boolean hasNext() {
            return this.enumeration.hasMoreElements();
        }

        public ZipEntry next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            }

            return new ZipEntry(this.zipFile, this.enumeration.nextElement());
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}