/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.model;

import org.intellij.idea.dirdiff.CompareDirectoryBundle;
import org.intellij.idea.dirdiff.model.disassemble.JavaClassMemberDesc;
import org.jetbrains.annotations.NotNull;

/**
 */
public class JavaFieldTreeNode extends ComparedTreeNode implements Comparable<JavaFieldTreeNode> {

    private JavaClassMemberDesc leftMember;
    private JavaClassMemberDesc rightMember;

    public JavaFieldTreeNode(String name, ComparedTreeNode parent, FileTreeModel model, JavaClassMemberDesc leftMember, JavaClassMemberDesc rightMember, FileStateEnum state) {
        super(name, parent, model, state);
        this.leftMember    = leftMember;
        this.rightMember   = rightMember;
    }

    public JavaClassMemberDesc getLeftMember() {
        return this.leftMember;
    }

    public JavaClassMemberDesc getRightMember() {
        return this.rightMember;
    }

    public ReadableFile getLeftFile() {
        return this.getParent().getLeftFile();
    }

    public ReadableFile getRightFile() {
        return this.getParent().getRightFile();
    }

    public final int memberIndexOf(JavaClassMemberDesc member) {
        return this.indexOf(member, FileTreeModel.javaClassMemberComparator);
    }

    @NotNull
    public FileStateEnum computeState(Interruptible interruptible) {
        return this.getState();
    }

    public boolean isIgnored() {
        return false;
    }

    public FileStateEnum updateInitialState() {
        if (!this.hasChildren()) {
            return this.getState();
        }

        FileStateEnum state = null;

        for (ComparedTreeNode node : this.getChildren()) {
            final FileStateEnum nodeState = node.getState();

            if (state == null) {
                state = nodeState;
            } else if (state != nodeState) {
                return FileStateEnum.DIFFERENT;
            }
        }
        return state;
    }

    public ComparedTreeNode mergeWithNode(ComparedTreeNode rightNode) {
        if (this     .getState() != FileStateEnum.LEFT_ONLY  ||
            rightNode.getState() != FileStateEnum.RIGHT_ONLY ||
            !this.getClass().equals(rightNode.getClass())) {
            return null;
        }

        // Destroy every subnode of this and the right nodes but do not finalize this
        // and the right node, because future left and right files must not be closed.
        this     .removeAllChildren();
        rightNode.removeAllChildren();

        this.getParent().remove(rightNode);

        this.rightMember  = ((JavaFieldTreeNode) rightNode).rightMember;
        this.userObject   = CompareDirectoryBundle.message("node.vs", this.leftMember.getSignature(), this.rightMember.getSignature());

        // Set state
        final String leftText  = this.leftMember .getText();
        final String rightText = this.rightMember.getText();

        final int leftBodyIndex  = leftText .indexOf('{');
        final int rightBodyIndex = rightText.indexOf('{');

        final boolean similar = (leftBodyIndex  >= 0 &&
                                 rightBodyIndex >= 0 &&
                                 leftText.length() - leftBodyIndex == rightText.length() - rightBodyIndex &&
                                 leftText.regionMatches(leftBodyIndex, rightText, rightBodyIndex, rightText.length() - rightBodyIndex));

        this.setState(similar ? FileStateEnum.DIFFERENT_NON_SIGNIFICANT : FileStateEnum.DIFFERENT);

        return this;
    }

    public boolean isMerged() {
        return (!this.leftMember.getSignature().equals(this.rightMember.getSignature()));
    }

    public ComparedTreeNode[] split() {
        final ComparedTreeNode parentNode     = this.getParent();
        final String           rightSignature = this.rightMember.getSignature();

        if (this.leftMember.getSignature().equals(rightSignature) ||
            parentNode.indexOf(rightSignature) >= 0) {
            return new ComparedTreeNode[0];
        }

        return new ComparedTreeNode[] { this, this.split(parentNode) };
    }

    @Override
    @NotNull protected ComparedTreeNode split(ComparedTreeNode parentNode) {
        final ComparedTreeNode splitNode = super.split(parentNode);

        if (splitNode != null) {
            return splitNode;
        }

        final String           rightSignature = this.rightMember.getSignature();
        final ComparedTreeNode rightChildNode = new JavaFieldTreeNode(rightSignature, parentNode, this.getModel(),
                                                                      this.rightMember, this.rightMember, FileStateEnum.RIGHT_ONLY);

        //parentNode.addChildNode(rightChildNode, this.rightMember, FileTreeModel.javaClassMemberComparator);
        parentNode.addChildNode(rightChildNode, rightSignature, FileTreeModel.childNameComparator);
        this.rightMember = this.leftMember;
        this.userObject  = this.leftMember.getSignature();
        this.setState(FileStateEnum.LEFT_ONLY);

        this.splitChildrenNodes(rightChildNode);

        return rightChildNode;
    }

    @Override
    public void finalizeIt() {
        //Nothing to do.
    }

    public int compareTimestamps() {
        return this.getParent().compareTimestamps();
    }

    public int compareTo(@NotNull JavaFieldTreeNode other) {
        return (this.leftMember == null) ? this.rightMember.compareTo(other.rightMember)
                                         : this.leftMember .compareTo(other.leftMember);
    }
}