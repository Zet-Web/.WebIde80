/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.view;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import org.intellij.idea.dirdiff.model.AllowedDiff;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.Files;
import org.intellij.idea.dirdiff.model.TreeNodeFilter;
import org.intellij.idea.dirdiff.model.TreeNodeFilters;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;

import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.util.PatternUtil;

/**
 * The configuration state of a panel of the plugin.
 * Note: All the attributes need to be public for JDOM externalization,
 * though they are nowhere else directly accessed.
 */
public class PanelConfiguration implements JDOMExternalizable, Cloneable {

    @NonNls private static final String DEFAULT_EXPORT_FILE_NAME = "CompareDirectories.txt";
    private         static final int    MAX_LAST_PATH_COUNT      = 10;

    public static final AllowedDiff[] EMPTY_ALLOWED_DIFF_ARRAY = new AllowedDiff[0];
    public static final Pattern[]     EMPTY_PATTERN_ARRAY      = new Pattern[0];

    public  boolean                      identicalVisible;
    public  boolean                      differentVisible;
    public  boolean                      differentInBlanksVisible;
    public  boolean                      differentNonSignificantVisible;
    public  boolean                      leftOnlyVisible;
    public  boolean                      rightOnlyVisible;
    public  boolean                      mostProbablyIdenticalVisible;
    public  boolean                      probablyIdenticalLeftNewerVisible;
    public  boolean                      probablyIdenticalRightNewerVisible;
    public  boolean                      probablyDifferentLeftNewerVisible;
    public  boolean                      probablyDifferentRightNewerVisible;
    public  boolean                      javaStructureVisible;
    public  boolean                      autoExcludeHidden;
    public  boolean                      autoScrollFromSource;
    public  StringList                   lastLeftPaths;
    public  StringList                   lastRightPaths;
    public  StringList                   ignoredFileMasks;
    private transient Pattern[]          ignoredFileMaskPatterns;
    public  String                       exportFileName;
    public  StringList                   allowedDiffMasks;
    private transient AllowedDiff[]      allowedDiffPatterns;
    public  boolean                      diffsInCommentsNonSignificant;

    public PanelConfiguration() {
        this.identicalVisible                   = true;
        this.differentVisible                   = true;
        this.differentInBlanksVisible           = true;
        this.differentNonSignificantVisible     = true;
        this.leftOnlyVisible                    = true;
        this.rightOnlyVisible                   = true;
        this.mostProbablyIdenticalVisible       = true;
        this.probablyIdenticalLeftNewerVisible  = true;
        this.probablyIdenticalRightNewerVisible = true;
        this.probablyDifferentLeftNewerVisible  = true;
        this.probablyDifferentRightNewerVisible = true;
        this.lastLeftPaths                      = new StringList();
        this.lastRightPaths                     = new StringList();
        this.ignoredFileMasks                   = new StringList();
        this.ignoredFileMaskPatterns            = EMPTY_PATTERN_ARRAY;
        this.allowedDiffMasks                   = new StringList();
        this.allowedDiffPatterns                = EMPTY_ALLOWED_DIFF_ARRAY;
        this.exportFileName                     = DEFAULT_EXPORT_FILE_NAME;
    }

    @SuppressWarnings({ "CloneDoesntDeclareCloneNotSupportedException", "CloneDoesntCallSuperClone" })
    @Override public Object clone() {
        final PanelConfiguration configuration = new PanelConfiguration();

        configuration.identicalVisible                   = this.identicalVisible;
        configuration.differentVisible                   = this.differentVisible;
        configuration.differentInBlanksVisible           = this.differentInBlanksVisible;
        configuration.differentNonSignificantVisible     = this.differentNonSignificantVisible;
        configuration.leftOnlyVisible                    = this.leftOnlyVisible;
        configuration.rightOnlyVisible                   = this.rightOnlyVisible;
        configuration.mostProbablyIdenticalVisible       = this.mostProbablyIdenticalVisible;
        configuration.probablyIdenticalLeftNewerVisible  = this.probablyIdenticalLeftNewerVisible;
        configuration.probablyIdenticalRightNewerVisible = this.probablyIdenticalRightNewerVisible;
        configuration.probablyDifferentLeftNewerVisible  = this.probablyDifferentLeftNewerVisible;
        configuration.probablyDifferentRightNewerVisible = this.probablyDifferentRightNewerVisible;
        configuration.javaStructureVisible               = this.javaStructureVisible;
        configuration.autoExcludeHidden                  = this.autoExcludeHidden;
        configuration.autoScrollFromSource               = this.autoScrollFromSource;
        configuration.lastLeftPaths                      = this.lastLeftPaths;
        configuration.lastRightPaths                     = this.lastRightPaths;
        configuration.ignoredFileMasks                   = this.ignoredFileMasks;
        configuration.ignoredFileMaskPatterns            = this.ignoredFileMaskPatterns;
        configuration.allowedDiffMasks                   = this.allowedDiffMasks;
        configuration.allowedDiffPatterns                = this.allowedDiffPatterns;
        configuration.exportFileName                     = this.exportFileName;
        configuration.diffsInCommentsNonSignificant      = this.diffsInCommentsNonSignificant;

        return configuration;
    }

    public boolean isIdenticalVisible() {
        return this.identicalVisible;
    }

    public void setIdenticalVisible(boolean identicalVisible) {
        this.identicalVisible = identicalVisible;
    }

    public boolean isFilterVisible(TreeNodeFilter filter) {
        //noinspection SimplifiableConditionalExpression
        return (filter == TreeNodeFilters.identical                      ? this.isIdenticalVisible()                   :
                filter == TreeNodeFilters.different                      ? this.isDifferentVisible()                   :
                filter == TreeNodeFilters.differentInBlanks              ? this.isDifferentInBlanksVisible()           :
                filter == TreeNodeFilters.differentNonSignificant        ? this.isDifferentNonSignificantVisible()     :
                filter == TreeNodeFilters.leftOnly                       ? this.isLeftOnlyVisible()                    :
                filter == TreeNodeFilters.rightOnly                      ? this.isRightOnlyVisible()                   :
                filter == TreeNodeFilters.mostProbablyIdentical          ? this.isMostProbablyIdenticalVisible()       :
                filter == TreeNodeFilters.probablyIdenticalAndLeftNewer  ? this.isProbablyIdenticalLeftNewerVisible()  :
                filter == TreeNodeFilters.probablyIdenticalAndRightNewer ? this.isProbablyIdenticalRightNewerVisible() :
                filter == TreeNodeFilters.probablyDifferentAndLeftNewer  ? this.isProbablyDifferentLeftNewerVisible()  :
                filter == TreeNodeFilters.probablyDifferentAndRightNewer ? this.isProbablyDifferentRightNewerVisible() :
                filter == TreeNodeFilters.javaStructure                  ? this.isJavaStructureVisible()
                                                                         : false);
    }

    public void setFilterVisible(TreeNodeFilter filter, boolean visible) {
        if      (filter == TreeNodeFilters.identical                     ) { this.setIdenticalVisible                  (visible); }
        else if (filter == TreeNodeFilters.different                     ) { this.setDifferentVisible                  (visible); }
        else if (filter == TreeNodeFilters.differentInBlanks             ) { this.setDifferentInBlanksVisible          (visible); }
        else if (filter == TreeNodeFilters.differentNonSignificant       ) { this.setDifferentNonSignificantVisible    (visible); }
        else if (filter == TreeNodeFilters.leftOnly                      ) { this.setLeftOnlyVisible                   (visible); }
        else if (filter == TreeNodeFilters.rightOnly                     ) { this.setRightOnlyVisible                  (visible); }
        else if (filter == TreeNodeFilters.mostProbablyIdentical         ) { this.setMostProbablyIdenticalVisible      (visible); }
        else if (filter == TreeNodeFilters.probablyIdenticalAndLeftNewer ) { this.setProbablyIdenticalLeftNewerVisible (visible); }
        else if (filter == TreeNodeFilters.probablyIdenticalAndRightNewer) { this.setProbablyIdenticalRightNewerVisible(visible); }
        else if (filter == TreeNodeFilters.probablyDifferentAndLeftNewer ) { this.setProbablyDifferentLeftNewerVisible (visible); }
        else if (filter == TreeNodeFilters.probablyDifferentAndRightNewer) { this.setProbablyDifferentRightNewerVisible(visible); }
        else if (filter == TreeNodeFilters.javaStructure                 ) { this.setJavaStructureVisible              (visible); }
    }

    public boolean isDifferentVisible() {
        return this.differentVisible;
    }

    public void setDifferentVisible(boolean differentVisible) {
        this.differentVisible = differentVisible;
    }

    public boolean isDifferentInBlanksVisible() {
        return this.differentInBlanksVisible;
    }

    public void setDifferentInBlanksVisible(boolean differentInBlanksVisible) {
        this.differentInBlanksVisible = differentInBlanksVisible;
    }

    public boolean isDifferentNonSignificantVisible() {
        return this.differentNonSignificantVisible;
    }

    public void setDifferentNonSignificantVisible(boolean differentNonSignificantVisible) {
        this.differentNonSignificantVisible = differentNonSignificantVisible;
    }

    public boolean isLeftOnlyVisible() {
        return this.leftOnlyVisible;
    }

    public void setLeftOnlyVisible(boolean leftOnlyVisible) {
        this.leftOnlyVisible = leftOnlyVisible;
    }

    public boolean isRightOnlyVisible() {
        return this.rightOnlyVisible;
    }

    public void setRightOnlyVisible(boolean rightOnlyVisible) {
        this.rightOnlyVisible = rightOnlyVisible;
    }

    public boolean isMostProbablyIdenticalVisible() {
        return this.mostProbablyIdenticalVisible;
    }

    public void setMostProbablyIdenticalVisible(boolean mostProbablyIdenticalVisible) {
        this.mostProbablyIdenticalVisible = mostProbablyIdenticalVisible;
    }

    public boolean isProbablyIdenticalLeftNewerVisible() {
        return this.probablyIdenticalLeftNewerVisible;
    }

    public void setProbablyIdenticalLeftNewerVisible(boolean probablyIdenticalLeftNewerVisible) {
        this.probablyIdenticalLeftNewerVisible = probablyIdenticalLeftNewerVisible;
    }

    public boolean isProbablyIdenticalRightNewerVisible() {
        return this.probablyIdenticalRightNewerVisible;
    }

    public void setProbablyIdenticalRightNewerVisible(boolean probablyIdenticalRightNewerVisible) {
        this.probablyIdenticalRightNewerVisible = probablyIdenticalRightNewerVisible;
    }

    public boolean isProbablyDifferentLeftNewerVisible() {
        return this.probablyDifferentLeftNewerVisible;
    }

    public void setProbablyDifferentLeftNewerVisible(boolean probablyDifferentLeftNewerVisible) {
        this.probablyDifferentLeftNewerVisible = probablyDifferentLeftNewerVisible;
    }

    public boolean isProbablyDifferentRightNewerVisible() {
        return this.probablyDifferentRightNewerVisible;
    }

    public void setProbablyDifferentRightNewerVisible(boolean probablyDifferentRightNewerVisible) {
        this.probablyDifferentRightNewerVisible = probablyDifferentRightNewerVisible;
    }

    public boolean isJavaStructureVisible() {
        return this.javaStructureVisible;
    }

    public void setJavaStructureVisible(boolean javaStructureVisible) {
        this.javaStructureVisible = javaStructureVisible;
    }

    public boolean isVisible(FileStateEnum state) {
        switch (state) {
            case DIFFERENT:                 return this.differentVisible;
            case DIFFERENT_IN_BLANKS:       return this.differentInBlanksVisible;
            case DIFFERENT_NON_SIGNIFICANT: return this.differentNonSignificantVisible;
            case DIFFERENT_IN_COMMENTS:     return this.differentVisible;
            case IDENTICAL:                 return this.identicalVisible;
            case LEFT_ONLY:                 return this.leftOnlyVisible;
            case RIGHT_ONLY:                return this.rightOnlyVisible;
            case PSI_ELEMENT:               return this.javaStructureVisible;

            case MOST_PROBABLY_IDENTICAL:
            case PROBABLY_DIFFERENT:
            case PROBABLY_IDENTICAL:  return false;
        }

        return false;
    }

    public boolean isAutoExcludeHidden() {
        return this.autoExcludeHidden;
    }

    public void setAutoExcludeHidden(boolean autoExcludeHidden) {
        this.autoExcludeHidden = autoExcludeHidden;
    }

    public boolean isAutoScrollFromSource() {
        return this.autoScrollFromSource;
    }

    public void setAutoScrollFromSource(boolean autoScrollFromSource) {
        this.autoScrollFromSource = autoScrollFromSource;
    }

    public List<String> getLastLeftPaths() {
        return this.lastLeftPaths.getList();
    }

    public void addLastLeftPath(String path) {
        addLastPath(this.lastLeftPaths.getList(), path);
    }

    public List<String> getLastRightPaths() {
        return this.lastRightPaths.getList();
    }

    public void addLastRightPath(String path) {
        addLastPath(this.lastRightPaths.getList(), path);
    }

    private static void addLastPath(List<String> list, String path) {
        if (!list.remove(path) && list.size() >= MAX_LAST_PATH_COUNT) {
            list.remove(list.size() - 1);
        }
        list.add(0, path);
    }

    public List<String> getIgnoredFileMasks() {
        return this.ignoredFileMasks.getList();
    }

    public Pattern[] getIgnoredFileMaskPatterns() {
        return this.ignoredFileMaskPatterns;
    }

    public void setIgnoredFileMasks(List<String> ignoredFileMasks) {
        final List<String> ignoredFileList = this.ignoredFileMasks.getList();

        ignoredFileList.clear();
        ignoredFileList.addAll(ignoredFileMasks);
        this.setIgnoredFilePatterns();
    }

    private void setIgnoredFilePatterns() {
        final List<String> masks = this.ignoredFileMasks.getList();

        this.ignoredFileMaskPatterns = new Pattern[masks.size()];
        for (int index = 0; index < ignoredFileMaskPatterns.length; index++) {
            ignoredFileMaskPatterns[index] = getPatternFromFileMask(masks.get(index));
        }
    }

    public AllowedDiff[] getAllowedDiffPatterns() {
        return this.allowedDiffPatterns;
    }

    public List<String> getAllowedDiffMasks() {
        return this.allowedDiffMasks.getList();
    }

    public void setAllowedDiffMasks(List<String> allowedDiffMasks) {
        final List<String> allowedDiffList = this.allowedDiffMasks.getList();

        allowedDiffList.clear();
        allowedDiffList.addAll(allowedDiffMasks);
        this.setAllowedDiffPatterns();
    }

    private void setAllowedDiffPatterns() {
        final List<String> maskList = this.allowedDiffMasks.getList();
        final int          numMasks = maskList.size() / 3;
        int                i        = 0;

        this.allowedDiffPatterns = new AllowedDiff[numMasks];

        for (int index = 0; index < numMasks; index++) {
            final AllowedDiff allowedDiff = new AllowedDiff();

            allowedDiff.setNodeNamePattern(getPatternFromFileMask(maskList.get(i++)));
            allowedDiff.setRegexp         ("R".equals(maskList.get(i++)));
            allowedDiff.setOriginalText   (maskList.get(i++));

            this.allowedDiffPatterns[index] = allowedDiff;
        }
    }

    private static Pattern getPatternFromFileMask(String mask) {
        String pattern = Files.denormalizeFilePath(mask);

        if (pattern.charAt(0) != '*') {
            pattern = '*' + pattern;
        }
        if (pattern.charAt(pattern.length() - 1) != '*') {
            pattern += '*';
        }

        return PatternUtil.fromMask(pattern);
    }

    public String getExportFileName() {
        return this.exportFileName;
    }

    public void setExportFileName(String exportFileName) {
        this.exportFileName = exportFileName;
    }

    public boolean areDiffsInCommentsNonSignificant() {
        return this.diffsInCommentsNonSignificant;
    }

    public void setDiffsInCommentsNonSignificant(boolean diffsInCommentsNonSignificant) {
        this.diffsInCommentsNonSignificant = diffsInCommentsNonSignificant;
    }

    public void writeExternal(Element element) throws WriteExternalException {
        DefaultJDOMExternalizer.writeExternal(this, element);
    }

    public void readExternal(Element element) throws InvalidDataException {
        DefaultJDOMExternalizer.readExternal(this, element);
        this.setIgnoredFilePatterns();
        this.setAllowedDiffPatterns();
    }

    public static class StringList implements JDOMExternalizable {
        @NonNls private static final String LEN_STRING = "len";

        private final List<String> list;

        public StringList() {
            this.list = new LinkedList<String>();
        }

        public List<String> getList() {
            return this.list;
        }

        public void readExternal(Element element) throws InvalidDataException {
            // Read in list size
            final int size = Integer.parseInt(element.getAttributeValue(LEN_STRING));

            // Read in all elements in the proper order.
            for (int index = 0; index < size; index++) {
                this.list.add(element.getAttributeValue('s' + Integer.toString(index)));
            }
        }

        public void writeExternal(Element element) throws WriteExternalException {
            // Write out list size
            element.setAttribute(LEN_STRING, Integer.toString(this.list.size()));

            // Write out all elements in the proper order.
            int index = 0;
            for (final String value : this.list) {
                element.setAttribute('s' + Integer.toString(index), value);
                index++;
            }
        }
    }
}
