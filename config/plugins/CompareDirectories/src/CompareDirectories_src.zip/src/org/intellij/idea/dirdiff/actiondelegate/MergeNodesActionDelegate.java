/*
 * Copyright 2006-2015 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.dirdiff.actiondelegate;

import org.intellij.idea.dirdiff.model.ComparedTreeNode;
import org.intellij.idea.dirdiff.model.FileStateEnum;
import org.intellij.idea.dirdiff.model.FileTreeNode;
import org.intellij.idea.dirdiff.model.ICompareDirectoryPanel;
import org.intellij.idea.dirdiff.model.JavaFieldTreeNode;
import org.jetbrains.annotations.Nullable;

/**
 */
public class MergeNodesActionDelegate extends AbstractActionDelegate {
    @Override public boolean isVisible(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        return (selectedNodes != null && selectedNodes.length == 2);
    }

    @Override public boolean isEnabled(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        return (this.isVisible(panel, selectedNodes) &&
                selectedNodes[0].getParent() == selectedNodes[1].getParent() &&
                ((selectedNodes[0].getState() == FileStateEnum.LEFT_ONLY  && selectedNodes[1].getState() == FileStateEnum.RIGHT_ONLY) ||
                 (selectedNodes[0].getState() == FileStateEnum.RIGHT_ONLY && selectedNodes[1].getState() == FileStateEnum.LEFT_ONLY)));
    }

    public void apply(@Nullable ICompareDirectoryPanel panel, @Nullable ComparedTreeNode[] selectedNodes) {
        if (this.isVisible(panel, selectedNodes)) {
            final ComparedTreeNode leftNode;

            if (selectedNodes[0].getState() == FileStateEnum.LEFT_ONLY) {
                leftNode = selectedNodes[0].mergeWithNode(selectedNodes[1]);
            } else {
                leftNode = selectedNodes[1].mergeWithNode(selectedNodes[0]);
            }

            if (leftNode != null && panel != null) {
                leftNode.getModel().addMergedNode(leftNode);

                if (leftNode instanceof FileTreeNode) {
                    panel.refreshSubTree((FileTreeNode) leftNode, true, true,
                                         panel.getComparisonParameters());
                }

                panel.refreshTree(true);
            }
        }
    }
}